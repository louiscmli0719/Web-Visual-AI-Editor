const Ma="web-visual-ai-editor-overlay-root";function Ud(e={}){const t=document.getElementById(Ma);t&&t.remove();const n=document.createElement("div");n.id=Ma,document.documentElement.appendChild(n);const r=n.attachShadow({mode:"open"}),i=document.createElement("div");i.className="wvaie-status",i.textContent="Web Visual AI Editor";const l=document.createElement("div");l.className="wvaie-box wvaie-box-hover";const o=document.createElement("div");o.className="wvaie-box wvaie-box-selected";const s=document.createElement("button");s.className="wvaie-layout-handle",s.type="button",s.setAttribute("aria-label","拖动调整布局位置"),s.innerHTML='<span class="wvaie-layout-grip" aria-hidden="true"></span>';const u=document.createElement("div");u.className="wvaie-layout-guide-layer";const c=document.createElement("div");c.className="wvaie-box wvaie-layout-target";const d=document.createElement("div");d.className="wvaie-layout-guide-line";const f=document.createElement("div");f.className="wvaie-layout-guide-label";const m=document.createElement("div");m.className="wvaie-box wvaie-box-flash";const x=document.createElement("div");x.className="wvaie-similar-layer";const v=document.createElement("div");v.className="wvaie-comment-pin-layer";const w=document.createElement("div");w.className="wvaie-size-label";const _=document.createElement("div");_.className="wvaie-box wvaie-box-pair-a";const h=document.createElement("div");h.className="wvaie-box wvaie-box-pair-b";const p=document.createElement("div");p.className="wvaie-measurement-guide-layer";const g=document.createElement("div");g.className="wvaie-distance-line wvaie-distance-h";const y=document.createElement("div");y.className="wvaie-distance-line wvaie-distance-v";const k=document.createElement("div");k.className="wvaie-distance-label";const C=document.createElement("div");C.className="wvaie-distance-label";const E=document.createElement("style");E.textContent=`
    :host {
      all: initial;
      pointer-events: none;
      position: fixed;
      z-index: 2147483644;
    }

    .wvaie-box {
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      display: none;
      pointer-events: none;
    }

    .wvaie-box-hover {
      border: 1px solid rgba(255, 45, 85, 0.82);
      background: rgba(255, 45, 85, 0.1);
    }

    .wvaie-box-selected {
      border: 2px solid #ff2d55;
      background: rgba(255, 45, 85, 0.14);
    }

    .wvaie-box-selected.wvaie-box-layout {
      border-color: #a855f7;
      background: rgba(217, 70, 239, 0.04);
      box-shadow:
        0 0 0 1px rgba(236, 72, 153, 0.76),
        0 0 28px rgba(217, 70, 239, 0.24);
    }

    .wvaie-layout-handle {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 2;
      display: none;
      align-items: center;
      justify-content: center;
      height: 20px;
      min-width: 0;
      border: 0;
      border-radius: 999px;
      background: transparent;
      color: transparent;
      cursor: grab;
      font: 700 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      padding: 5px 0;
      pointer-events: auto;
      touch-action: none;
      user-select: none;
      box-shadow: none;
    }

    .wvaie-layout-handle:active {
      cursor: grabbing;
    }

    .wvaie-layout-grip {
      width: 100%;
      height: 9px;
      border-radius: 999px;
      background: #ff00d4;
      box-shadow:
        0 0 0 1px rgba(255, 255, 255, 0.5),
        0 0 18px rgba(255, 0, 212, 0.72),
        0 8px 22px rgba(0, 0, 0, 0.36);
    }

    .wvaie-layout-target {
      border: 2px dashed rgba(236, 72, 153, 0.96);
      background: rgba(217, 70, 239, 0.07);
      box-shadow:
        inset 0 0 0 1px rgba(244, 114, 182, 0.28),
        0 0 24px rgba(217, 70, 239, 0.18);
    }

    .wvaie-layout-guide-layer,
    .wvaie-measurement-guide-layer {
      pointer-events: none;
    }

    .wvaie-layout-alignment-line,
    .wvaie-measurement-guide-line {
      position: fixed;
      top: 0;
      left: 0;
      display: block;
      pointer-events: none;
    }

    .wvaie-layout-alignment-line {
      opacity: 0.92;
      filter: drop-shadow(0 0 5px rgba(217, 70, 239, 0.66));
    }

    .wvaie-measurement-guide-line {
      opacity: 0.74;
      filter: drop-shadow(0 0 4px rgba(217, 70, 239, 0.45));
    }

    .wvaie-guide-v {
      background-image: repeating-linear-gradient(
        to bottom,
        rgba(217, 70, 239, 0.98) 0,
        rgba(217, 70, 239, 0.98) 3px,
        transparent 3px,
        transparent 8px
      );
    }

    .wvaie-guide-h {
      background-image: repeating-linear-gradient(
        to right,
        rgba(217, 70, 239, 0.98) 0,
        rgba(217, 70, 239, 0.98) 3px,
        transparent 3px,
        transparent 8px
      );
    }

    .wvaie-layout-guide-line {
      position: fixed;
      top: 0;
      left: 0;
      display: none;
      border-radius: 999px;
      background: transparent;
      pointer-events: none;
      box-shadow: 0 0 10px rgba(217, 70, 239, 0.52);
    }

    .wvaie-layout-guide-label {
      position: fixed;
      top: 0;
      left: 0;
      display: none;
      padding: 4px 8px;
      border: 1px solid rgba(244, 114, 182, 0.74);
      border-radius: 999px;
      background: rgba(21, 18, 24, 0.94);
      color: #ffe4ff;
      font: 700 12px/1.2 ui-monospace, Menlo, monospace;
      font-variant-numeric: tabular-nums;
      pointer-events: none;
      white-space: nowrap;
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.28);
    }

    .wvaie-box-flash {
      border: 2px solid #ff4d6d;
      background: rgba(255, 77, 109, 0.14);
      opacity: 0;
      transition: opacity 120ms ease-out;
    }

    .wvaie-similar-layer {
      opacity: 1;
      transition: opacity 600ms ease-out;
    }

    .wvaie-similar-box {
      border: 1px dashed #fb7185;
      background: rgba(251, 113, 133, 0.12);
    }

    .wvaie-comment-pin-layer {
      pointer-events: none;
    }

    .wvaie-comment-pin {
      position: fixed;
      top: 0;
      left: 0;
      display: grid;
      width: 26px;
      height: 26px;
      place-items: center;
      border: 2px solid rgba(255, 255, 255, 0.94);
      border-radius: 50%;
      background: #ec35c8;
      color: #fff;
      font: 800 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      pointer-events: none;
      box-shadow:
        0 0 0 1px rgba(217, 70, 239, 0.3),
        0 0 18px rgba(236, 53, 200, 0.46),
        0 8px 18px rgba(0, 0, 0, 0.24);
    }

    .wvaie-box-pair-a {
      border: 2px dashed rgba(236, 72, 153, 0.9);
      background: rgba(236, 72, 153, 0.08);
    }

    .wvaie-box-pair-b {
      border: 2px dashed rgba(168, 85, 247, 0.9);
      background: rgba(168, 85, 247, 0.08);
    }

    .wvaie-status {
      position: fixed;
      top: 16px;
      left: 16px;
      padding: 8px 12px;
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 10px;
      background: rgba(14, 14, 14, 0.9);
      color: rgba(226, 232, 240, 0.86);
      font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }

    .wvaie-size-label {
      position: fixed;
      top: 0;
      left: 0;
      display: none;
      padding: 4px 8px;
      border: 1px solid rgba(255, 45, 85, 0.48);
      border-radius: 6px;
      background: rgba(14, 14, 14, 0.9);
      color: #ffe4e6;
      font: 600 12px/1.4 ui-monospace, Menlo, monospace;
      pointer-events: none;
      white-space: nowrap;
      box-shadow: 0 10px 22px rgba(0, 0, 0, 0.26), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }

    .wvaie-distance-line {
      position: fixed;
      top: 0;
      left: 0;
      display: none;
      background: transparent;
      pointer-events: none;
    }

    .wvaie-distance-h {
      height: 1px;
      background-image: repeating-linear-gradient(
        to right,
        rgba(217, 70, 239, 0.98) 0,
        rgba(217, 70, 239, 0.98) 4px,
        transparent 4px,
        transparent 9px
      );
    }

    .wvaie-distance-v {
      width: 1px;
      background-image: repeating-linear-gradient(
        to bottom,
        rgba(217, 70, 239, 0.98) 0,
        rgba(217, 70, 239, 0.98) 4px,
        transparent 4px,
        transparent 9px
      );
    }

    .wvaie-distance-label {
      position: fixed;
      top: 0;
      left: 0;
      display: none;
      padding: 2px 5px;
      border-radius: 4px;
      border: 1px solid rgba(217, 70, 239, 0.54);
      background: rgba(14, 14, 14, 0.9);
      color: #fce7ff;
      font: 600 11px/1.3 ui-monospace, Menlo, monospace;
      pointer-events: none;
      white-space: nowrap;
      box-shadow: 0 8px 18px rgba(0, 0, 0, 0.24);
    }

    @media (prefers-reduced-motion: reduce) {
      .wvaie-box-flash,
      .wvaie-similar-layer {
        transition: none;
      }
    }
  `,r.append(E,l,o,u,c,d,f,s,m,x,v,p,_,h,g,y,w,k,C,i);let M=null,O=null;s.addEventListener("pointerdown",T=>{var ce,J;!T.isPrimary||T.button!==0||((ce=s.setPointerCapture)==null||ce.call(s,T.pointerId),(J=e.onLayoutDragStart)==null||J.call(e,{pointerId:T.pointerId,clientX:T.clientX,clientY:T.clientY}),T.preventDefault(),T.stopPropagation())});function R(){M!==null&&(window.clearTimeout(M),M=null),O!==null&&(window.clearTimeout(O),O=null),x.replaceChildren(),x.style.opacity="1"}return{update(T){var ce,J;if(i.hidden=!T.enabled,pt(l,T.hoverRect),o.classList.toggle("wvaie-box-layout",T.layoutMode&&T.selectedRect!==null),pt(o,T.selectedRect),Gd(s,T.selectedRect,T.layoutMode),Qd(c,d,f,u,T.layoutGuide),Wd(v,T.commentPins),(ce=T.measurement)!=null&&ce.size&&T.selectedRect&&T.selectedElement){const Ie=T.selectedElement.tagName.toLowerCase();w.textContent=`<${Ie}> ${T.measurement.size.width} × ${T.measurement.size.height}`,Yd(w,T.selectedRect),w.style.display="block"}else w.style.display="none";if((J=T.measurement)!=null&&J.pair){const{a:Ie,b:st,horizontalDistance:zt,verticalDistance:It}=T.measurement.pair;pt(_,Ie),pt(h,st),Xd(p,Ie,st),Kd(g,y,k,C,Ie,st,zt,It)}else _.style.display="none",h.style.display="none",p.replaceChildren(),g.style.display="none",y.style.display="none",k.style.display="none",C.style.display="none"},flash(T){pt(m,T),m.style.opacity="1",window.setTimeout(()=>{m.style.opacity="0"},160)},highlightSimilar(T){R();for(const ce of T){const J=document.createElement("div");J.className="wvaie-box wvaie-similar-box",pt(J,ce),x.appendChild(J)}M=window.setTimeout(()=>{x.style.opacity="0"},3e3),O=window.setTimeout(()=>{R()},3600)},destroy(){R(),n.remove()}}}function Wd(e,t){e.replaceChildren();for(const n of t){if(n.rect.width<=0||n.rect.height<=0)continue;const r=document.createElement("div");r.className="wvaie-comment-pin",r.textContent=String(Math.min(n.count,99));const i=vn(n.rect.x+n.rect.width-13,4,window.innerWidth-26-4),l=vn(n.rect.y-13,4,window.innerHeight-26-4);r.style.transform=`translate(${Math.round(i)}px, ${Math.round(l)}px)`,e.appendChild(r)}}function pt(e,t){if(!t||t.width<=0||t.height<=0){e.style.display="none";return}e.style.display="block",e.style.transform=`translate(${t.x}px, ${t.y}px)`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`}function Gd(e,t,n){if(!n||!t||t.width<=0||t.height<=0){e.style.display="none";return}const r=Math.max(30,Math.min(180,t.width-12)),i=Math.min(44,r),l=vn(t.width*.58,i,r),o=vn(t.x+t.width/2-l/2,6,window.innerWidth-l-6),s=vn(t.y+t.height/2-10,6,window.innerHeight-26);e.style.display="inline-flex",e.style.width=`${Math.round(l)}px`,e.style.transform=`translate(${Math.round(o)}px, ${Math.round(s)}px)`}function Qd(e,t,n,r,i){if(pt(e,(i==null?void 0:i.targetRect)??null),Ks(r,(i==null?void 0:i.alignmentLines)??[],"wvaie-layout-alignment-line"),!(i!=null&&i.lineRect)){t.style.display="none",n.style.display="none";return}pt(t,i.lineRect),t.classList.toggle("wvaie-guide-v",i.lineRect.height>=i.lineRect.width),t.classList.toggle("wvaie-guide-h",i.lineRect.width>i.lineRect.height),n.textContent=i.label??"换位",n.style.display="block",n.style.transform=`translate(${Math.round(i.lineRect.x+i.lineRect.width+8)}px, ${Math.round(i.lineRect.y+i.lineRect.height/2-11)}px)`}function Yd(e,t){let r=t.x+t.width,i=t.y-20-2;i<0&&(i=t.y+t.height+2);const o=(e.textContent||"").length*8+12;r+o>window.innerWidth&&(r=t.x+t.width-o),r=Math.max(0,r),e.style.transform=`translate(${r}px, ${i}px)`}function vn(e,t,n){return Math.min(Math.max(e,t),Math.max(t,n))}function Ks(e,t,n){e.replaceChildren();for(const r of t){if(r.width<=0||r.height<=0)continue;const i=document.createElement("div"),l=r.height>=r.width;i.className=`${n} ${l?"wvaie-guide-v":"wvaie-guide-h"}`,i.style.transform=`translate(${Math.round(r.x)}px, ${Math.round(r.y)}px)`,i.style.width=`${Math.max(1,Math.round(r.width))}px`,i.style.height=`${Math.max(1,Math.round(r.height))}px`,e.appendChild(i)}}function Xd(e,t,n){const r=Na([t.x,t.x+t.width/2,t.x+t.width,n.x,n.x+n.width/2,n.x+n.width],window.innerWidth),i=Na([t.y,t.y+t.height/2,t.y+t.height,n.y,n.y+n.height/2,n.y+n.height],window.innerHeight);Ks(e,[...r.map(l=>({x:l,y:0,width:1,height:window.innerHeight})),...i.map(l=>({x:0,y:l,width:window.innerWidth,height:1}))],"wvaie-measurement-guide-line")}function Na(e,t){const n=[];for(const r of e){const i=Math.round(vn(r,0,t));n.some(l=>Math.abs(l-i)<=1)||n.push(i)}return n}function Kd(e,t,n,r,i,l,o,s){const u=i.x<l.x?i:l,c=i.x<l.x?l:i,d=u.x+u.width,f=(i.y+i.height/2+l.y+l.height/2)/2;o>0?(e.style.display="block",e.style.transform=`translate(${d}px, ${f}px)`,e.style.width=`${c.x-d}px`,e.style.height="1px",n.style.display="block",n.textContent=`↔ ${o}`,n.style.transform=`translate(${(d+c.x)/2-20}px, ${f-14}px)`):(e.style.display="none",n.style.display="none");const m=i.y<l.y?i:l,x=i.y<l.y?l:i,v=m.y+m.height,w=(i.x+i.width/2+l.x+l.width/2)/2;s>0?(t.style.display="block",t.style.transform=`translate(${w}px, ${v}px)`,t.style.width="1px",t.style.height=`${x.y-v}px`,r.style.display="block",r.textContent=`↕ ${s}`,r.style.transform=`translate(${w+4}px, ${(v+x.y)/2-8}px)`):(t.style.display="none",r.style.display="none")}var Zs={exports:{}},Pi={},qs={exports:{}},$={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var yr=Symbol.for("react.element"),Zd=Symbol.for("react.portal"),qd=Symbol.for("react.fragment"),Jd=Symbol.for("react.strict_mode"),ep=Symbol.for("react.profiler"),tp=Symbol.for("react.provider"),np=Symbol.for("react.context"),rp=Symbol.for("react.forward_ref"),ip=Symbol.for("react.suspense"),lp=Symbol.for("react.memo"),op=Symbol.for("react.lazy"),La=Symbol.iterator;function ap(e){return e===null||typeof e!="object"?null:(e=La&&e[La]||e["@@iterator"],typeof e=="function"?e:null)}var Js={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},eu=Object.assign,tu={};function _n(e,t,n){this.props=e,this.context=t,this.refs=tu,this.updater=n||Js}_n.prototype.isReactComponent={};_n.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};_n.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function nu(){}nu.prototype=_n.prototype;function Eo(e,t,n){this.props=e,this.context=t,this.refs=tu,this.updater=n||Js}var jo=Eo.prototype=new nu;jo.constructor=Eo;eu(jo,_n.prototype);jo.isPureReactComponent=!0;var Ta=Array.isArray,ru=Object.prototype.hasOwnProperty,bo={current:null},iu={key:!0,ref:!0,__self:!0,__source:!0};function lu(e,t,n){var r,i={},l=null,o=null;if(t!=null)for(r in t.ref!==void 0&&(o=t.ref),t.key!==void 0&&(l=""+t.key),t)ru.call(t,r)&&!iu.hasOwnProperty(r)&&(i[r]=t[r]);var s=arguments.length-2;if(s===1)i.children=n;else if(1<s){for(var u=Array(s),c=0;c<s;c++)u[c]=arguments[c+2];i.children=u}if(e&&e.defaultProps)for(r in s=e.defaultProps,s)i[r]===void 0&&(i[r]=s[r]);return{$$typeof:yr,type:e,key:l,ref:o,props:i,_owner:bo.current}}function sp(e,t){return{$$typeof:yr,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function Mo(e){return typeof e=="object"&&e!==null&&e.$$typeof===yr}function up(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var _a=/\/+/g;function Ji(e,t){return typeof e=="object"&&e!==null&&e.key!=null?up(""+e.key):t.toString(36)}function Xr(e,t,n,r,i){var l=typeof e;(l==="undefined"||l==="boolean")&&(e=null);var o=!1;if(e===null)o=!0;else switch(l){case"string":case"number":o=!0;break;case"object":switch(e.$$typeof){case yr:case Zd:o=!0}}if(o)return o=e,i=i(o),e=r===""?"."+Ji(o,0):r,Ta(i)?(n="",e!=null&&(n=e.replace(_a,"$&/")+"/"),Xr(i,t,n,"",function(c){return c})):i!=null&&(Mo(i)&&(i=sp(i,n+(!i.key||o&&o.key===i.key?"":(""+i.key).replace(_a,"$&/")+"/")+e)),t.push(i)),1;if(o=0,r=r===""?".":r+":",Ta(e))for(var s=0;s<e.length;s++){l=e[s];var u=r+Ji(l,s);o+=Xr(l,t,n,u,i)}else if(u=ap(e),typeof u=="function")for(e=u.call(e),s=0;!(l=e.next()).done;)l=l.value,u=r+Ji(l,s++),o+=Xr(l,t,n,u,i);else if(l==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return o}function Nr(e,t,n){if(e==null)return e;var r=[],i=0;return Xr(e,r,"","",function(l){return t.call(n,l,i++)}),r}function cp(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var fe={current:null},Kr={transition:null},dp={ReactCurrentDispatcher:fe,ReactCurrentBatchConfig:Kr,ReactCurrentOwner:bo};function ou(){throw Error("act(...) is not supported in production builds of React.")}$.Children={map:Nr,forEach:function(e,t,n){Nr(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return Nr(e,function(){t++}),t},toArray:function(e){return Nr(e,function(t){return t})||[]},only:function(e){if(!Mo(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};$.Component=_n;$.Fragment=qd;$.Profiler=ep;$.PureComponent=Eo;$.StrictMode=Jd;$.Suspense=ip;$.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=dp;$.act=ou;$.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var r=eu({},e.props),i=e.key,l=e.ref,o=e._owner;if(t!=null){if(t.ref!==void 0&&(l=t.ref,o=bo.current),t.key!==void 0&&(i=""+t.key),e.type&&e.type.defaultProps)var s=e.type.defaultProps;for(u in t)ru.call(t,u)&&!iu.hasOwnProperty(u)&&(r[u]=t[u]===void 0&&s!==void 0?s[u]:t[u])}var u=arguments.length-2;if(u===1)r.children=n;else if(1<u){s=Array(u);for(var c=0;c<u;c++)s[c]=arguments[c+2];r.children=s}return{$$typeof:yr,type:e.type,key:i,ref:l,props:r,_owner:o}};$.createContext=function(e){return e={$$typeof:np,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:tp,_context:e},e.Consumer=e};$.createElement=lu;$.createFactory=function(e){var t=lu.bind(null,e);return t.type=e,t};$.createRef=function(){return{current:null}};$.forwardRef=function(e){return{$$typeof:rp,render:e}};$.isValidElement=Mo;$.lazy=function(e){return{$$typeof:op,_payload:{_status:-1,_result:e},_init:cp}};$.memo=function(e,t){return{$$typeof:lp,type:e,compare:t===void 0?null:t}};$.startTransition=function(e){var t=Kr.transition;Kr.transition={};try{e()}finally{Kr.transition=t}};$.unstable_act=ou;$.useCallback=function(e,t){return fe.current.useCallback(e,t)};$.useContext=function(e){return fe.current.useContext(e)};$.useDebugValue=function(){};$.useDeferredValue=function(e){return fe.current.useDeferredValue(e)};$.useEffect=function(e,t){return fe.current.useEffect(e,t)};$.useId=function(){return fe.current.useId()};$.useImperativeHandle=function(e,t,n){return fe.current.useImperativeHandle(e,t,n)};$.useInsertionEffect=function(e,t){return fe.current.useInsertionEffect(e,t)};$.useLayoutEffect=function(e,t){return fe.current.useLayoutEffect(e,t)};$.useMemo=function(e,t){return fe.current.useMemo(e,t)};$.useReducer=function(e,t,n){return fe.current.useReducer(e,t,n)};$.useRef=function(e){return fe.current.useRef(e)};$.useState=function(e){return fe.current.useState(e)};$.useSyncExternalStore=function(e,t,n){return fe.current.useSyncExternalStore(e,t,n)};$.useTransition=function(){return fe.current.useTransition()};$.version="18.3.1";qs.exports=$;var I=qs.exports;/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var pp=I,fp=Symbol.for("react.element"),hp=Symbol.for("react.fragment"),mp=Object.prototype.hasOwnProperty,gp=pp.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,vp={key:!0,ref:!0,__self:!0,__source:!0};function au(e,t,n){var r,i={},l=null,o=null;n!==void 0&&(l=""+n),t.key!==void 0&&(l=""+t.key),t.ref!==void 0&&(o=t.ref);for(r in t)mp.call(t,r)&&!vp.hasOwnProperty(r)&&(i[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps,t)i[r]===void 0&&(i[r]=t[r]);return{$$typeof:fp,type:e,key:l,ref:o,props:i,_owner:gp.current}}Pi.Fragment=hp;Pi.jsx=au;Pi.jsxs=au;Zs.exports=Pi;var a=Zs.exports,su={exports:{}},Me={},uu={exports:{}},cu={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(j,P){var z=j.length;j.push(P);e:for(;0<z;){var L=z-1>>>1,X=j[L];if(0<i(X,P))j[L]=P,j[z]=X,z=L;else break e}}function n(j){return j.length===0?null:j[0]}function r(j){if(j.length===0)return null;var P=j[0],z=j.pop();if(z!==P){j[0]=z;e:for(var L=0,X=j.length,br=X>>>1;L<br;){var $t=2*(L+1)-1,qi=j[$t],Dt=$t+1,Mr=j[Dt];if(0>i(qi,z))Dt<X&&0>i(Mr,qi)?(j[L]=Mr,j[Dt]=z,L=Dt):(j[L]=qi,j[$t]=z,L=$t);else if(Dt<X&&0>i(Mr,z))j[L]=Mr,j[Dt]=z,L=Dt;else break e}}return P}function i(j,P){var z=j.sortIndex-P.sortIndex;return z!==0?z:j.id-P.id}if(typeof performance=="object"&&typeof performance.now=="function"){var l=performance;e.unstable_now=function(){return l.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var u=[],c=[],d=1,f=null,m=3,x=!1,v=!1,w=!1,_=typeof setTimeout=="function"?setTimeout:null,h=typeof clearTimeout=="function"?clearTimeout:null,p=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function g(j){for(var P=n(c);P!==null;){if(P.callback===null)r(c);else if(P.startTime<=j)r(c),P.sortIndex=P.expirationTime,t(u,P);else break;P=n(c)}}function y(j){if(w=!1,g(j),!v)if(n(u)!==null)v=!0,zt(k);else{var P=n(c);P!==null&&It(y,P.startTime-j)}}function k(j,P){v=!1,w&&(w=!1,h(M),M=-1),x=!0;var z=m;try{for(g(P),f=n(u);f!==null&&(!(f.expirationTime>P)||j&&!T());){var L=f.callback;if(typeof L=="function"){f.callback=null,m=f.priorityLevel;var X=L(f.expirationTime<=P);P=e.unstable_now(),typeof X=="function"?f.callback=X:f===n(u)&&r(u),g(P)}else r(u);f=n(u)}if(f!==null)var br=!0;else{var $t=n(c);$t!==null&&It(y,$t.startTime-P),br=!1}return br}finally{f=null,m=z,x=!1}}var C=!1,E=null,M=-1,O=5,R=-1;function T(){return!(e.unstable_now()-R<O)}function ce(){if(E!==null){var j=e.unstable_now();R=j;var P=!0;try{P=E(!0,j)}finally{P?J():(C=!1,E=null)}}else C=!1}var J;if(typeof p=="function")J=function(){p(ce)};else if(typeof MessageChannel<"u"){var Ie=new MessageChannel,st=Ie.port2;Ie.port1.onmessage=ce,J=function(){st.postMessage(null)}}else J=function(){_(ce,0)};function zt(j){E=j,C||(C=!0,J())}function It(j,P){M=_(function(){j(e.unstable_now())},P)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(j){j.callback=null},e.unstable_continueExecution=function(){v||x||(v=!0,zt(k))},e.unstable_forceFrameRate=function(j){0>j||125<j?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):O=0<j?Math.floor(1e3/j):5},e.unstable_getCurrentPriorityLevel=function(){return m},e.unstable_getFirstCallbackNode=function(){return n(u)},e.unstable_next=function(j){switch(m){case 1:case 2:case 3:var P=3;break;default:P=m}var z=m;m=P;try{return j()}finally{m=z}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(j,P){switch(j){case 1:case 2:case 3:case 4:case 5:break;default:j=3}var z=m;m=j;try{return P()}finally{m=z}},e.unstable_scheduleCallback=function(j,P,z){var L=e.unstable_now();switch(typeof z=="object"&&z!==null?(z=z.delay,z=typeof z=="number"&&0<z?L+z:L):z=L,j){case 1:var X=-1;break;case 2:X=250;break;case 5:X=1073741823;break;case 4:X=1e4;break;default:X=5e3}return X=z+X,j={id:d++,callback:P,priorityLevel:j,startTime:z,expirationTime:X,sortIndex:-1},z>L?(j.sortIndex=z,t(c,j),n(u)===null&&j===n(c)&&(w?(h(M),M=-1):w=!0,It(y,z-L))):(j.sortIndex=X,t(u,j),v||x||(v=!0,zt(k))),j},e.unstable_shouldYield=T,e.unstable_wrapCallback=function(j){var P=m;return function(){var z=m;m=P;try{return j.apply(this,arguments)}finally{m=z}}}})(cu);uu.exports=cu;var yp=uu.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var xp=I,be=yp;function S(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var du=new Set,tr={};function Zt(e,t){En(e,t),En(e+"Capture",t)}function En(e,t){for(tr[e]=t,e=0;e<t.length;e++)du.add(t[e])}var rt=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),_l=Object.prototype.hasOwnProperty,wp=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Ra={},Pa={};function Sp(e){return _l.call(Pa,e)?!0:_l.call(Ra,e)?!1:wp.test(e)?Pa[e]=!0:(Ra[e]=!0,!1)}function kp(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function Cp(e,t,n,r){if(t===null||typeof t>"u"||kp(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function he(e,t,n,r,i,l,o){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=i,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=l,this.removeEmptyString=o}var ie={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){ie[e]=new he(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];ie[t]=new he(t,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){ie[e]=new he(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){ie[e]=new he(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){ie[e]=new he(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){ie[e]=new he(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){ie[e]=new he(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){ie[e]=new he(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){ie[e]=new he(e,5,!1,e.toLowerCase(),null,!1,!1)});var No=/[\-:]([a-z])/g;function Lo(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(No,Lo);ie[t]=new he(t,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(No,Lo);ie[t]=new he(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(No,Lo);ie[t]=new he(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){ie[e]=new he(e,1,!1,e.toLowerCase(),null,!1,!1)});ie.xlinkHref=new he("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){ie[e]=new he(e,1,!1,e.toLowerCase(),null,!0,!0)});function To(e,t,n,r){var i=ie.hasOwnProperty(t)?ie[t]:null;(i!==null?i.type!==0:r||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(Cp(t,n,i,r)&&(n=null),r||i===null?Sp(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,""+n)):i.mustUseProperty?e[i.propertyName]=n===null?i.type===3?!1:"":n:(t=i.attributeName,r=i.attributeNamespace,n===null?e.removeAttribute(t):(i=i.type,n=i===3||i===4&&n===!0?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var at=xp.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,Lr=Symbol.for("react.element"),ln=Symbol.for("react.portal"),on=Symbol.for("react.fragment"),_o=Symbol.for("react.strict_mode"),Rl=Symbol.for("react.profiler"),pu=Symbol.for("react.provider"),fu=Symbol.for("react.context"),Ro=Symbol.for("react.forward_ref"),Pl=Symbol.for("react.suspense"),zl=Symbol.for("react.suspense_list"),Po=Symbol.for("react.memo"),ft=Symbol.for("react.lazy"),hu=Symbol.for("react.offscreen"),za=Symbol.iterator;function zn(e){return e===null||typeof e!="object"?null:(e=za&&e[za]||e["@@iterator"],typeof e=="function"?e:null)}var G=Object.assign,el;function Hn(e){if(el===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);el=t&&t[1]||""}return`
`+el+e}var tl=!1;function nl(e,t){if(!e||tl)return"";tl=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(c){var r=c}Reflect.construct(e,[],t)}else{try{t.call()}catch(c){r=c}e.call(t.prototype)}else{try{throw Error()}catch(c){r=c}e()}}catch(c){if(c&&r&&typeof c.stack=="string"){for(var i=c.stack.split(`
`),l=r.stack.split(`
`),o=i.length-1,s=l.length-1;1<=o&&0<=s&&i[o]!==l[s];)s--;for(;1<=o&&0<=s;o--,s--)if(i[o]!==l[s]){if(o!==1||s!==1)do if(o--,s--,0>s||i[o]!==l[s]){var u=`
`+i[o].replace(" at new "," at ");return e.displayName&&u.includes("<anonymous>")&&(u=u.replace("<anonymous>",e.displayName)),u}while(1<=o&&0<=s);break}}}finally{tl=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?Hn(e):""}function Ep(e){switch(e.tag){case 5:return Hn(e.type);case 16:return Hn("Lazy");case 13:return Hn("Suspense");case 19:return Hn("SuspenseList");case 0:case 2:case 15:return e=nl(e.type,!1),e;case 11:return e=nl(e.type.render,!1),e;case 1:return e=nl(e.type,!0),e;default:return""}}function Il(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case on:return"Fragment";case ln:return"Portal";case Rl:return"Profiler";case _o:return"StrictMode";case Pl:return"Suspense";case zl:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case fu:return(e.displayName||"Context")+".Consumer";case pu:return(e._context.displayName||"Context")+".Provider";case Ro:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Po:return t=e.displayName||null,t!==null?t:Il(e.type)||"Memo";case ft:t=e._payload,e=e._init;try{return Il(e(t))}catch{}}return null}function jp(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Il(t);case 8:return t===_o?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function Mt(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function mu(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function bp(e){var t=mu(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var i=n.get,l=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(o){r=""+o,l.call(this,o)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(o){r=""+o},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Tr(e){e._valueTracker||(e._valueTracker=bp(e))}function gu(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=mu(e)?e.checked?"true":"false":e.value),e=r,e!==n?(t.setValue(e),!0):!1}function ai(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function $l(e,t){var n=t.checked;return G({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function Ia(e,t){var n=t.defaultValue==null?"":t.defaultValue,r=t.checked!=null?t.checked:t.defaultChecked;n=Mt(t.value!=null?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function vu(e,t){t=t.checked,t!=null&&To(e,"checked",t,!1)}function Dl(e,t){vu(e,t);var n=Mt(t.value),r=t.type;if(n!=null)r==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if(r==="submit"||r==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?Ol(e,t.type,n):t.hasOwnProperty("defaultValue")&&Ol(e,t.type,Mt(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function $a(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!(r!=="submit"&&r!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,n!==""&&(e.name=n)}function Ol(e,t,n){(t!=="number"||ai(e.ownerDocument)!==e)&&(n==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}var Bn=Array.isArray;function yn(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t["$"+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty("$"+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=""+Mt(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Fl(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(S(91));return G({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function Da(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(S(92));if(Bn(n)){if(1<n.length)throw Error(S(93));n=n[0]}t=n}t==null&&(t=""),n=t}e._wrapperState={initialValue:Mt(n)}}function yu(e,t){var n=Mt(t.value),r=Mt(t.defaultValue);n!=null&&(n=""+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=""+r)}function Oa(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function xu(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function Al(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?xu(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var _r,wu=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,n,r,i){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,i)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(_r=_r||document.createElement("div"),_r.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=_r.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function nr(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Gn={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Mp=["Webkit","ms","Moz","O"];Object.keys(Gn).forEach(function(e){Mp.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),Gn[t]=Gn[e]})});function Su(e,t,n){return t==null||typeof t=="boolean"||t===""?"":n||typeof t!="number"||t===0||Gn.hasOwnProperty(e)&&Gn[e]?(""+t).trim():t+"px"}function ku(e,t){e=e.style;for(var n in t)if(t.hasOwnProperty(n)){var r=n.indexOf("--")===0,i=Su(n,t[n],r);n==="float"&&(n="cssFloat"),r?e.setProperty(n,i):e[n]=i}}var Np=G({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Vl(e,t){if(t){if(Np[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(S(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(S(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(S(61))}if(t.style!=null&&typeof t.style!="object")throw Error(S(62))}}function Hl(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Bl=null;function zo(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Ul=null,xn=null,wn=null;function Fa(e){if(e=Sr(e)){if(typeof Ul!="function")throw Error(S(280));var t=e.stateNode;t&&(t=Oi(t),Ul(e.stateNode,e.type,t))}}function Cu(e){xn?wn?wn.push(e):wn=[e]:xn=e}function Eu(){if(xn){var e=xn,t=wn;if(wn=xn=null,Fa(e),t)for(e=0;e<t.length;e++)Fa(t[e])}}function ju(e,t){return e(t)}function bu(){}var rl=!1;function Mu(e,t,n){if(rl)return e(t,n);rl=!0;try{return ju(e,t,n)}finally{rl=!1,(xn!==null||wn!==null)&&(bu(),Eu())}}function rr(e,t){var n=e.stateNode;if(n===null)return null;var r=Oi(n);if(r===null)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(e=e.type,r=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!r;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(S(231,t,typeof n));return n}var Wl=!1;if(rt)try{var In={};Object.defineProperty(In,"passive",{get:function(){Wl=!0}}),window.addEventListener("test",In,In),window.removeEventListener("test",In,In)}catch{Wl=!1}function Lp(e,t,n,r,i,l,o,s,u){var c=Array.prototype.slice.call(arguments,3);try{t.apply(n,c)}catch(d){this.onError(d)}}var Qn=!1,si=null,ui=!1,Gl=null,Tp={onError:function(e){Qn=!0,si=e}};function _p(e,t,n,r,i,l,o,s,u){Qn=!1,si=null,Lp.apply(Tp,arguments)}function Rp(e,t,n,r,i,l,o,s,u){if(_p.apply(this,arguments),Qn){if(Qn){var c=si;Qn=!1,si=null}else throw Error(S(198));ui||(ui=!0,Gl=c)}}function qt(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function Nu(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Aa(e){if(qt(e)!==e)throw Error(S(188))}function Pp(e){var t=e.alternate;if(!t){if(t=qt(e),t===null)throw Error(S(188));return t!==e?null:e}for(var n=e,r=t;;){var i=n.return;if(i===null)break;var l=i.alternate;if(l===null){if(r=i.return,r!==null){n=r;continue}break}if(i.child===l.child){for(l=i.child;l;){if(l===n)return Aa(i),e;if(l===r)return Aa(i),t;l=l.sibling}throw Error(S(188))}if(n.return!==r.return)n=i,r=l;else{for(var o=!1,s=i.child;s;){if(s===n){o=!0,n=i,r=l;break}if(s===r){o=!0,r=i,n=l;break}s=s.sibling}if(!o){for(s=l.child;s;){if(s===n){o=!0,n=l,r=i;break}if(s===r){o=!0,r=l,n=i;break}s=s.sibling}if(!o)throw Error(S(189))}}if(n.alternate!==r)throw Error(S(190))}if(n.tag!==3)throw Error(S(188));return n.stateNode.current===n?e:t}function Lu(e){return e=Pp(e),e!==null?Tu(e):null}function Tu(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=Tu(e);if(t!==null)return t;e=e.sibling}return null}var _u=be.unstable_scheduleCallback,Va=be.unstable_cancelCallback,zp=be.unstable_shouldYield,Ip=be.unstable_requestPaint,Y=be.unstable_now,$p=be.unstable_getCurrentPriorityLevel,Io=be.unstable_ImmediatePriority,Ru=be.unstable_UserBlockingPriority,ci=be.unstable_NormalPriority,Dp=be.unstable_LowPriority,Pu=be.unstable_IdlePriority,zi=null,Xe=null;function Op(e){if(Xe&&typeof Xe.onCommitFiberRoot=="function")try{Xe.onCommitFiberRoot(zi,e,void 0,(e.current.flags&128)===128)}catch{}}var Ve=Math.clz32?Math.clz32:Vp,Fp=Math.log,Ap=Math.LN2;function Vp(e){return e>>>=0,e===0?32:31-(Fp(e)/Ap|0)|0}var Rr=64,Pr=4194304;function Un(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function di(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,i=e.suspendedLanes,l=e.pingedLanes,o=n&268435455;if(o!==0){var s=o&~i;s!==0?r=Un(s):(l&=o,l!==0&&(r=Un(l)))}else o=n&~i,o!==0?r=Un(o):l!==0&&(r=Un(l));if(r===0)return 0;if(t!==0&&t!==r&&!(t&i)&&(i=r&-r,l=t&-t,i>=l||i===16&&(l&4194240)!==0))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Ve(t),i=1<<n,r|=e[n],t&=~i;return r}function Hp(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Bp(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,l=e.pendingLanes;0<l;){var o=31-Ve(l),s=1<<o,u=i[o];u===-1?(!(s&n)||s&r)&&(i[o]=Hp(s,t)):u<=t&&(e.expiredLanes|=s),l&=~s}}function Ql(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function zu(){var e=Rr;return Rr<<=1,!(Rr&4194240)&&(Rr=64),e}function il(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function xr(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Ve(t),e[t]=n}function Up(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var i=31-Ve(n),l=1<<i;t[i]=0,r[i]=-1,e[i]=-1,n&=~l}}function $o(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Ve(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}var F=0;function Iu(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var $u,Do,Du,Ou,Fu,Yl=!1,zr=[],xt=null,wt=null,St=null,ir=new Map,lr=new Map,mt=[],Wp="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Ha(e,t){switch(e){case"focusin":case"focusout":xt=null;break;case"dragenter":case"dragleave":wt=null;break;case"mouseover":case"mouseout":St=null;break;case"pointerover":case"pointerout":ir.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":lr.delete(t.pointerId)}}function $n(e,t,n,r,i,l){return e===null||e.nativeEvent!==l?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:l,targetContainers:[i]},t!==null&&(t=Sr(t),t!==null&&Do(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function Gp(e,t,n,r,i){switch(t){case"focusin":return xt=$n(xt,e,t,n,r,i),!0;case"dragenter":return wt=$n(wt,e,t,n,r,i),!0;case"mouseover":return St=$n(St,e,t,n,r,i),!0;case"pointerover":var l=i.pointerId;return ir.set(l,$n(ir.get(l)||null,e,t,n,r,i)),!0;case"gotpointercapture":return l=i.pointerId,lr.set(l,$n(lr.get(l)||null,e,t,n,r,i)),!0}return!1}function Au(e){var t=Vt(e.target);if(t!==null){var n=qt(t);if(n!==null){if(t=n.tag,t===13){if(t=Nu(n),t!==null){e.blockedOn=t,Fu(e.priority,function(){Du(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Zr(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Xl(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);Bl=r,n.target.dispatchEvent(r),Bl=null}else return t=Sr(n),t!==null&&Do(t),e.blockedOn=n,!1;t.shift()}return!0}function Ba(e,t,n){Zr(e)&&n.delete(t)}function Qp(){Yl=!1,xt!==null&&Zr(xt)&&(xt=null),wt!==null&&Zr(wt)&&(wt=null),St!==null&&Zr(St)&&(St=null),ir.forEach(Ba),lr.forEach(Ba)}function Dn(e,t){e.blockedOn===t&&(e.blockedOn=null,Yl||(Yl=!0,be.unstable_scheduleCallback(be.unstable_NormalPriority,Qp)))}function or(e){function t(i){return Dn(i,e)}if(0<zr.length){Dn(zr[0],e);for(var n=1;n<zr.length;n++){var r=zr[n];r.blockedOn===e&&(r.blockedOn=null)}}for(xt!==null&&Dn(xt,e),wt!==null&&Dn(wt,e),St!==null&&Dn(St,e),ir.forEach(t),lr.forEach(t),n=0;n<mt.length;n++)r=mt[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<mt.length&&(n=mt[0],n.blockedOn===null);)Au(n),n.blockedOn===null&&mt.shift()}var Sn=at.ReactCurrentBatchConfig,pi=!0;function Yp(e,t,n,r){var i=F,l=Sn.transition;Sn.transition=null;try{F=1,Oo(e,t,n,r)}finally{F=i,Sn.transition=l}}function Xp(e,t,n,r){var i=F,l=Sn.transition;Sn.transition=null;try{F=4,Oo(e,t,n,r)}finally{F=i,Sn.transition=l}}function Oo(e,t,n,r){if(pi){var i=Xl(e,t,n,r);if(i===null)hl(e,t,r,fi,n),Ha(e,r);else if(Gp(i,e,t,n,r))r.stopPropagation();else if(Ha(e,r),t&4&&-1<Wp.indexOf(e)){for(;i!==null;){var l=Sr(i);if(l!==null&&$u(l),l=Xl(e,t,n,r),l===null&&hl(e,t,r,fi,n),l===i)break;i=l}i!==null&&r.stopPropagation()}else hl(e,t,r,null,n)}}var fi=null;function Xl(e,t,n,r){if(fi=null,e=zo(r),e=Vt(e),e!==null)if(t=qt(e),t===null)e=null;else if(n=t.tag,n===13){if(e=Nu(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return fi=e,null}function Vu(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch($p()){case Io:return 1;case Ru:return 4;case ci:case Dp:return 16;case Pu:return 536870912;default:return 16}default:return 16}}var vt=null,Fo=null,qr=null;function Hu(){if(qr)return qr;var e,t=Fo,n=t.length,r,i="value"in vt?vt.value:vt.textContent,l=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[l-r];r++);return qr=i.slice(e,1<r?1-r:void 0)}function Jr(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Ir(){return!0}function Ua(){return!1}function Ne(e){function t(n,r,i,l,o){this._reactName=n,this._targetInst=i,this.type=r,this.nativeEvent=l,this.target=o,this.currentTarget=null;for(var s in e)e.hasOwnProperty(s)&&(n=e[s],this[s]=n?n(l):l[s]);return this.isDefaultPrevented=(l.defaultPrevented!=null?l.defaultPrevented:l.returnValue===!1)?Ir:Ua,this.isPropagationStopped=Ua,this}return G(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Ir)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Ir)},persist:function(){},isPersistent:Ir}),t}var Rn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Ao=Ne(Rn),wr=G({},Rn,{view:0,detail:0}),Kp=Ne(wr),ll,ol,On,Ii=G({},wr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Vo,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==On&&(On&&e.type==="mousemove"?(ll=e.screenX-On.screenX,ol=e.screenY-On.screenY):ol=ll=0,On=e),ll)},movementY:function(e){return"movementY"in e?e.movementY:ol}}),Wa=Ne(Ii),Zp=G({},Ii,{dataTransfer:0}),qp=Ne(Zp),Jp=G({},wr,{relatedTarget:0}),al=Ne(Jp),ef=G({},Rn,{animationName:0,elapsedTime:0,pseudoElement:0}),tf=Ne(ef),nf=G({},Rn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),rf=Ne(nf),lf=G({},Rn,{data:0}),Ga=Ne(lf),of={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},af={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},sf={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function uf(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=sf[e])?!!t[e]:!1}function Vo(){return uf}var cf=G({},wr,{key:function(e){if(e.key){var t=of[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Jr(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?af[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Vo,charCode:function(e){return e.type==="keypress"?Jr(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Jr(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),df=Ne(cf),pf=G({},Ii,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Qa=Ne(pf),ff=G({},wr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Vo}),hf=Ne(ff),mf=G({},Rn,{propertyName:0,elapsedTime:0,pseudoElement:0}),gf=Ne(mf),vf=G({},Ii,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),yf=Ne(vf),xf=[9,13,27,32],Ho=rt&&"CompositionEvent"in window,Yn=null;rt&&"documentMode"in document&&(Yn=document.documentMode);var wf=rt&&"TextEvent"in window&&!Yn,Bu=rt&&(!Ho||Yn&&8<Yn&&11>=Yn),Ya=" ",Xa=!1;function Uu(e,t){switch(e){case"keyup":return xf.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Wu(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var an=!1;function Sf(e,t){switch(e){case"compositionend":return Wu(t);case"keypress":return t.which!==32?null:(Xa=!0,Ya);case"textInput":return e=t.data,e===Ya&&Xa?null:e;default:return null}}function kf(e,t){if(an)return e==="compositionend"||!Ho&&Uu(e,t)?(e=Hu(),qr=Fo=vt=null,an=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Bu&&t.locale!=="ko"?null:t.data;default:return null}}var Cf={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Ka(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Cf[e.type]:t==="textarea"}function Gu(e,t,n,r){Cu(r),t=hi(t,"onChange"),0<t.length&&(n=new Ao("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var Xn=null,ar=null;function Ef(e){rc(e,0)}function $i(e){var t=cn(e);if(gu(t))return e}function jf(e,t){if(e==="change")return t}var Qu=!1;if(rt){var sl;if(rt){var ul="oninput"in document;if(!ul){var Za=document.createElement("div");Za.setAttribute("oninput","return;"),ul=typeof Za.oninput=="function"}sl=ul}else sl=!1;Qu=sl&&(!document.documentMode||9<document.documentMode)}function qa(){Xn&&(Xn.detachEvent("onpropertychange",Yu),ar=Xn=null)}function Yu(e){if(e.propertyName==="value"&&$i(ar)){var t=[];Gu(t,ar,e,zo(e)),Mu(Ef,t)}}function bf(e,t,n){e==="focusin"?(qa(),Xn=t,ar=n,Xn.attachEvent("onpropertychange",Yu)):e==="focusout"&&qa()}function Mf(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return $i(ar)}function Nf(e,t){if(e==="click")return $i(t)}function Lf(e,t){if(e==="input"||e==="change")return $i(t)}function Tf(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Be=typeof Object.is=="function"?Object.is:Tf;function sr(e,t){if(Be(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!_l.call(t,i)||!Be(e[i],t[i]))return!1}return!0}function Ja(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function es(e,t){var n=Ja(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=Ja(n)}}function Xu(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Xu(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Ku(){for(var e=window,t=ai();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=ai(e.document)}return t}function Bo(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function _f(e){var t=Ku(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Xu(n.ownerDocument.documentElement,n)){if(r!==null&&Bo(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),"selectionStart"in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var i=n.textContent.length,l=Math.min(r.start,i);r=r.end===void 0?l:Math.min(r.end,i),!e.extend&&l>r&&(i=r,r=l,l=i),i=es(n,l);var o=es(n,r);i&&o&&(e.rangeCount!==1||e.anchorNode!==i.node||e.anchorOffset!==i.offset||e.focusNode!==o.node||e.focusOffset!==o.offset)&&(t=t.createRange(),t.setStart(i.node,i.offset),e.removeAllRanges(),l>r?(e.addRange(t),e.extend(o.node,o.offset)):(t.setEnd(o.node,o.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Rf=rt&&"documentMode"in document&&11>=document.documentMode,sn=null,Kl=null,Kn=null,Zl=!1;function ts(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Zl||sn==null||sn!==ai(r)||(r=sn,"selectionStart"in r&&Bo(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Kn&&sr(Kn,r)||(Kn=r,r=hi(Kl,"onSelect"),0<r.length&&(t=new Ao("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=sn)))}function $r(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var un={animationend:$r("Animation","AnimationEnd"),animationiteration:$r("Animation","AnimationIteration"),animationstart:$r("Animation","AnimationStart"),transitionend:$r("Transition","TransitionEnd")},cl={},Zu={};rt&&(Zu=document.createElement("div").style,"AnimationEvent"in window||(delete un.animationend.animation,delete un.animationiteration.animation,delete un.animationstart.animation),"TransitionEvent"in window||delete un.transitionend.transition);function Di(e){if(cl[e])return cl[e];if(!un[e])return e;var t=un[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Zu)return cl[e]=t[n];return e}var qu=Di("animationend"),Ju=Di("animationiteration"),ec=Di("animationstart"),tc=Di("transitionend"),nc=new Map,ns="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Tt(e,t){nc.set(e,t),Zt(t,[e])}for(var dl=0;dl<ns.length;dl++){var pl=ns[dl],Pf=pl.toLowerCase(),zf=pl[0].toUpperCase()+pl.slice(1);Tt(Pf,"on"+zf)}Tt(qu,"onAnimationEnd");Tt(Ju,"onAnimationIteration");Tt(ec,"onAnimationStart");Tt("dblclick","onDoubleClick");Tt("focusin","onFocus");Tt("focusout","onBlur");Tt(tc,"onTransitionEnd");En("onMouseEnter",["mouseout","mouseover"]);En("onMouseLeave",["mouseout","mouseover"]);En("onPointerEnter",["pointerout","pointerover"]);En("onPointerLeave",["pointerout","pointerover"]);Zt("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Zt("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Zt("onBeforeInput",["compositionend","keypress","textInput","paste"]);Zt("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Zt("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Zt("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Wn="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),If=new Set("cancel close invalid load scroll toggle".split(" ").concat(Wn));function rs(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,Rp(r,t,void 0,e),e.currentTarget=null}function rc(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;e:{var l=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],u=s.instance,c=s.currentTarget;if(s=s.listener,u!==l&&i.isPropagationStopped())break e;rs(i,s,c),l=u}else for(o=0;o<r.length;o++){if(s=r[o],u=s.instance,c=s.currentTarget,s=s.listener,u!==l&&i.isPropagationStopped())break e;rs(i,s,c),l=u}}}if(ui)throw e=Gl,ui=!1,Gl=null,e}function V(e,t){var n=t[no];n===void 0&&(n=t[no]=new Set);var r=e+"__bubble";n.has(r)||(ic(t,e,2,!1),n.add(r))}function fl(e,t,n){var r=0;t&&(r|=4),ic(n,e,r,t)}var Dr="_reactListening"+Math.random().toString(36).slice(2);function ur(e){if(!e[Dr]){e[Dr]=!0,du.forEach(function(n){n!=="selectionchange"&&(If.has(n)||fl(n,!1,e),fl(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Dr]||(t[Dr]=!0,fl("selectionchange",!1,t))}}function ic(e,t,n,r){switch(Vu(t)){case 1:var i=Yp;break;case 4:i=Xp;break;default:i=Oo}n=i.bind(null,t,n,e),i=void 0,!Wl||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(i=!0),r?i!==void 0?e.addEventListener(t,n,{capture:!0,passive:i}):e.addEventListener(t,n,!0):i!==void 0?e.addEventListener(t,n,{passive:i}):e.addEventListener(t,n,!1)}function hl(e,t,n,r,i){var l=r;if(!(t&1)&&!(t&2)&&r!==null)e:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var s=r.stateNode.containerInfo;if(s===i||s.nodeType===8&&s.parentNode===i)break;if(o===4)for(o=r.return;o!==null;){var u=o.tag;if((u===3||u===4)&&(u=o.stateNode.containerInfo,u===i||u.nodeType===8&&u.parentNode===i))return;o=o.return}for(;s!==null;){if(o=Vt(s),o===null)return;if(u=o.tag,u===5||u===6){r=l=o;continue e}s=s.parentNode}}r=r.return}Mu(function(){var c=l,d=zo(n),f=[];e:{var m=nc.get(e);if(m!==void 0){var x=Ao,v=e;switch(e){case"keypress":if(Jr(n)===0)break e;case"keydown":case"keyup":x=df;break;case"focusin":v="focus",x=al;break;case"focusout":v="blur",x=al;break;case"beforeblur":case"afterblur":x=al;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":x=Wa;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":x=qp;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":x=hf;break;case qu:case Ju:case ec:x=tf;break;case tc:x=gf;break;case"scroll":x=Kp;break;case"wheel":x=yf;break;case"copy":case"cut":case"paste":x=rf;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":x=Qa}var w=(t&4)!==0,_=!w&&e==="scroll",h=w?m!==null?m+"Capture":null:m;w=[];for(var p=c,g;p!==null;){g=p;var y=g.stateNode;if(g.tag===5&&y!==null&&(g=y,h!==null&&(y=rr(p,h),y!=null&&w.push(cr(p,y,g)))),_)break;p=p.return}0<w.length&&(m=new x(m,v,null,n,d),f.push({event:m,listeners:w}))}}if(!(t&7)){e:{if(m=e==="mouseover"||e==="pointerover",x=e==="mouseout"||e==="pointerout",m&&n!==Bl&&(v=n.relatedTarget||n.fromElement)&&(Vt(v)||v[it]))break e;if((x||m)&&(m=d.window===d?d:(m=d.ownerDocument)?m.defaultView||m.parentWindow:window,x?(v=n.relatedTarget||n.toElement,x=c,v=v?Vt(v):null,v!==null&&(_=qt(v),v!==_||v.tag!==5&&v.tag!==6)&&(v=null)):(x=null,v=c),x!==v)){if(w=Wa,y="onMouseLeave",h="onMouseEnter",p="mouse",(e==="pointerout"||e==="pointerover")&&(w=Qa,y="onPointerLeave",h="onPointerEnter",p="pointer"),_=x==null?m:cn(x),g=v==null?m:cn(v),m=new w(y,p+"leave",x,n,d),m.target=_,m.relatedTarget=g,y=null,Vt(d)===c&&(w=new w(h,p+"enter",v,n,d),w.target=g,w.relatedTarget=_,y=w),_=y,x&&v)t:{for(w=x,h=v,p=0,g=w;g;g=tn(g))p++;for(g=0,y=h;y;y=tn(y))g++;for(;0<p-g;)w=tn(w),p--;for(;0<g-p;)h=tn(h),g--;for(;p--;){if(w===h||h!==null&&w===h.alternate)break t;w=tn(w),h=tn(h)}w=null}else w=null;x!==null&&is(f,m,x,w,!1),v!==null&&_!==null&&is(f,_,v,w,!0)}}e:{if(m=c?cn(c):window,x=m.nodeName&&m.nodeName.toLowerCase(),x==="select"||x==="input"&&m.type==="file")var k=jf;else if(Ka(m))if(Qu)k=Lf;else{k=Mf;var C=bf}else(x=m.nodeName)&&x.toLowerCase()==="input"&&(m.type==="checkbox"||m.type==="radio")&&(k=Nf);if(k&&(k=k(e,c))){Gu(f,k,n,d);break e}C&&C(e,m,c),e==="focusout"&&(C=m._wrapperState)&&C.controlled&&m.type==="number"&&Ol(m,"number",m.value)}switch(C=c?cn(c):window,e){case"focusin":(Ka(C)||C.contentEditable==="true")&&(sn=C,Kl=c,Kn=null);break;case"focusout":Kn=Kl=sn=null;break;case"mousedown":Zl=!0;break;case"contextmenu":case"mouseup":case"dragend":Zl=!1,ts(f,n,d);break;case"selectionchange":if(Rf)break;case"keydown":case"keyup":ts(f,n,d)}var E;if(Ho)e:{switch(e){case"compositionstart":var M="onCompositionStart";break e;case"compositionend":M="onCompositionEnd";break e;case"compositionupdate":M="onCompositionUpdate";break e}M=void 0}else an?Uu(e,n)&&(M="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(M="onCompositionStart");M&&(Bu&&n.locale!=="ko"&&(an||M!=="onCompositionStart"?M==="onCompositionEnd"&&an&&(E=Hu()):(vt=d,Fo="value"in vt?vt.value:vt.textContent,an=!0)),C=hi(c,M),0<C.length&&(M=new Ga(M,e,null,n,d),f.push({event:M,listeners:C}),E?M.data=E:(E=Wu(n),E!==null&&(M.data=E)))),(E=wf?Sf(e,n):kf(e,n))&&(c=hi(c,"onBeforeInput"),0<c.length&&(d=new Ga("onBeforeInput","beforeinput",null,n,d),f.push({event:d,listeners:c}),d.data=E))}rc(f,t)})}function cr(e,t,n){return{instance:e,listener:t,currentTarget:n}}function hi(e,t){for(var n=t+"Capture",r=[];e!==null;){var i=e,l=i.stateNode;i.tag===5&&l!==null&&(i=l,l=rr(e,n),l!=null&&r.unshift(cr(e,l,i)),l=rr(e,t),l!=null&&r.push(cr(e,l,i))),e=e.return}return r}function tn(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function is(e,t,n,r,i){for(var l=t._reactName,o=[];n!==null&&n!==r;){var s=n,u=s.alternate,c=s.stateNode;if(u!==null&&u===r)break;s.tag===5&&c!==null&&(s=c,i?(u=rr(n,l),u!=null&&o.unshift(cr(n,u,s))):i||(u=rr(n,l),u!=null&&o.push(cr(n,u,s)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var $f=/\r\n?/g,Df=/\u0000|\uFFFD/g;function ls(e){return(typeof e=="string"?e:""+e).replace($f,`
`).replace(Df,"")}function Or(e,t,n){if(t=ls(t),ls(e)!==t&&n)throw Error(S(425))}function mi(){}var ql=null,Jl=null;function eo(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var to=typeof setTimeout=="function"?setTimeout:void 0,Of=typeof clearTimeout=="function"?clearTimeout:void 0,os=typeof Promise=="function"?Promise:void 0,Ff=typeof queueMicrotask=="function"?queueMicrotask:typeof os<"u"?function(e){return os.resolve(null).then(e).catch(Af)}:to;function Af(e){setTimeout(function(){throw e})}function ml(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8)if(n=i.data,n==="/$"){if(r===0){e.removeChild(i),or(t);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=i}while(n);or(t)}function kt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function as(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"){if(t===0)return e;t--}else n==="/$"&&t++}e=e.previousSibling}return null}var Pn=Math.random().toString(36).slice(2),Ye="__reactFiber$"+Pn,dr="__reactProps$"+Pn,it="__reactContainer$"+Pn,no="__reactEvents$"+Pn,Vf="__reactListeners$"+Pn,Hf="__reactHandles$"+Pn;function Vt(e){var t=e[Ye];if(t)return t;for(var n=e.parentNode;n;){if(t=n[it]||n[Ye]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=as(e);e!==null;){if(n=e[Ye])return n;e=as(e)}return t}e=n,n=e.parentNode}return null}function Sr(e){return e=e[Ye]||e[it],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function cn(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(S(33))}function Oi(e){return e[dr]||null}var ro=[],dn=-1;function _t(e){return{current:e}}function H(e){0>dn||(e.current=ro[dn],ro[dn]=null,dn--)}function A(e,t){dn++,ro[dn]=e.current,e.current=t}var Nt={},ue=_t(Nt),ve=_t(!1),Gt=Nt;function jn(e,t){var n=e.type.contextTypes;if(!n)return Nt;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var i={},l;for(l in n)i[l]=t[l];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=i),i}function ye(e){return e=e.childContextTypes,e!=null}function gi(){H(ve),H(ue)}function ss(e,t,n){if(ue.current!==Nt)throw Error(S(168));A(ue,t),A(ve,n)}function lc(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var i in r)if(!(i in t))throw Error(S(108,jp(e)||"Unknown",i));return G({},n,r)}function vi(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||Nt,Gt=ue.current,A(ue,e),A(ve,ve.current),!0}function us(e,t,n){var r=e.stateNode;if(!r)throw Error(S(169));n?(e=lc(e,t,Gt),r.__reactInternalMemoizedMergedChildContext=e,H(ve),H(ue),A(ue,e)):H(ve),A(ve,n)}var Je=null,Fi=!1,gl=!1;function oc(e){Je===null?Je=[e]:Je.push(e)}function Bf(e){Fi=!0,oc(e)}function Rt(){if(!gl&&Je!==null){gl=!0;var e=0,t=F;try{var n=Je;for(F=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}Je=null,Fi=!1}catch(i){throw Je!==null&&(Je=Je.slice(e+1)),_u(Io,Rt),i}finally{F=t,gl=!1}}return null}var pn=[],fn=0,yi=null,xi=0,Le=[],Te=0,Qt=null,et=1,tt="";function Ft(e,t){pn[fn++]=xi,pn[fn++]=yi,yi=e,xi=t}function ac(e,t,n){Le[Te++]=et,Le[Te++]=tt,Le[Te++]=Qt,Qt=e;var r=et;e=tt;var i=32-Ve(r)-1;r&=~(1<<i),n+=1;var l=32-Ve(t)+i;if(30<l){var o=i-i%5;l=(r&(1<<o)-1).toString(32),r>>=o,i-=o,et=1<<32-Ve(t)+i|n<<i|r,tt=l+e}else et=1<<l|n<<i|r,tt=e}function Uo(e){e.return!==null&&(Ft(e,1),ac(e,1,0))}function Wo(e){for(;e===yi;)yi=pn[--fn],pn[fn]=null,xi=pn[--fn],pn[fn]=null;for(;e===Qt;)Qt=Le[--Te],Le[Te]=null,tt=Le[--Te],Le[Te]=null,et=Le[--Te],Le[Te]=null}var je=null,Ee=null,B=!1,Ae=null;function sc(e,t){var n=_e(5,null,null,0);n.elementType="DELETED",n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function cs(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,je=e,Ee=kt(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,je=e,Ee=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(n=Qt!==null?{id:et,overflow:tt}:null,e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=_e(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,je=e,Ee=null,!0):!1;default:return!1}}function io(e){return(e.mode&1)!==0&&(e.flags&128)===0}function lo(e){if(B){var t=Ee;if(t){var n=t;if(!cs(e,t)){if(io(e))throw Error(S(418));t=kt(n.nextSibling);var r=je;t&&cs(e,t)?sc(r,n):(e.flags=e.flags&-4097|2,B=!1,je=e)}}else{if(io(e))throw Error(S(418));e.flags=e.flags&-4097|2,B=!1,je=e}}}function ds(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;je=e}function Fr(e){if(e!==je)return!1;if(!B)return ds(e),B=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!eo(e.type,e.memoizedProps)),t&&(t=Ee)){if(io(e))throw uc(),Error(S(418));for(;t;)sc(e,t),t=kt(t.nextSibling)}if(ds(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(S(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"){if(t===0){Ee=kt(e.nextSibling);break e}t--}else n!=="$"&&n!=="$!"&&n!=="$?"||t++}e=e.nextSibling}Ee=null}}else Ee=je?kt(e.stateNode.nextSibling):null;return!0}function uc(){for(var e=Ee;e;)e=kt(e.nextSibling)}function bn(){Ee=je=null,B=!1}function Go(e){Ae===null?Ae=[e]:Ae.push(e)}var Uf=at.ReactCurrentBatchConfig;function Fn(e,t,n){if(e=n.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(S(309));var r=n.stateNode}if(!r)throw Error(S(147,e));var i=r,l=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===l?t.ref:(t=function(o){var s=i.refs;o===null?delete s[l]:s[l]=o},t._stringRef=l,t)}if(typeof e!="string")throw Error(S(284));if(!n._owner)throw Error(S(290,e))}return e}function Ar(e,t){throw e=Object.prototype.toString.call(t),Error(S(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function ps(e){var t=e._init;return t(e._payload)}function cc(e){function t(h,p){if(e){var g=h.deletions;g===null?(h.deletions=[p],h.flags|=16):g.push(p)}}function n(h,p){if(!e)return null;for(;p!==null;)t(h,p),p=p.sibling;return null}function r(h,p){for(h=new Map;p!==null;)p.key!==null?h.set(p.key,p):h.set(p.index,p),p=p.sibling;return h}function i(h,p){return h=bt(h,p),h.index=0,h.sibling=null,h}function l(h,p,g){return h.index=g,e?(g=h.alternate,g!==null?(g=g.index,g<p?(h.flags|=2,p):g):(h.flags|=2,p)):(h.flags|=1048576,p)}function o(h){return e&&h.alternate===null&&(h.flags|=2),h}function s(h,p,g,y){return p===null||p.tag!==6?(p=Cl(g,h.mode,y),p.return=h,p):(p=i(p,g),p.return=h,p)}function u(h,p,g,y){var k=g.type;return k===on?d(h,p,g.props.children,y,g.key):p!==null&&(p.elementType===k||typeof k=="object"&&k!==null&&k.$$typeof===ft&&ps(k)===p.type)?(y=i(p,g.props),y.ref=Fn(h,p,g),y.return=h,y):(y=oi(g.type,g.key,g.props,null,h.mode,y),y.ref=Fn(h,p,g),y.return=h,y)}function c(h,p,g,y){return p===null||p.tag!==4||p.stateNode.containerInfo!==g.containerInfo||p.stateNode.implementation!==g.implementation?(p=El(g,h.mode,y),p.return=h,p):(p=i(p,g.children||[]),p.return=h,p)}function d(h,p,g,y,k){return p===null||p.tag!==7?(p=Wt(g,h.mode,y,k),p.return=h,p):(p=i(p,g),p.return=h,p)}function f(h,p,g){if(typeof p=="string"&&p!==""||typeof p=="number")return p=Cl(""+p,h.mode,g),p.return=h,p;if(typeof p=="object"&&p!==null){switch(p.$$typeof){case Lr:return g=oi(p.type,p.key,p.props,null,h.mode,g),g.ref=Fn(h,null,p),g.return=h,g;case ln:return p=El(p,h.mode,g),p.return=h,p;case ft:var y=p._init;return f(h,y(p._payload),g)}if(Bn(p)||zn(p))return p=Wt(p,h.mode,g,null),p.return=h,p;Ar(h,p)}return null}function m(h,p,g,y){var k=p!==null?p.key:null;if(typeof g=="string"&&g!==""||typeof g=="number")return k!==null?null:s(h,p,""+g,y);if(typeof g=="object"&&g!==null){switch(g.$$typeof){case Lr:return g.key===k?u(h,p,g,y):null;case ln:return g.key===k?c(h,p,g,y):null;case ft:return k=g._init,m(h,p,k(g._payload),y)}if(Bn(g)||zn(g))return k!==null?null:d(h,p,g,y,null);Ar(h,g)}return null}function x(h,p,g,y,k){if(typeof y=="string"&&y!==""||typeof y=="number")return h=h.get(g)||null,s(p,h,""+y,k);if(typeof y=="object"&&y!==null){switch(y.$$typeof){case Lr:return h=h.get(y.key===null?g:y.key)||null,u(p,h,y,k);case ln:return h=h.get(y.key===null?g:y.key)||null,c(p,h,y,k);case ft:var C=y._init;return x(h,p,g,C(y._payload),k)}if(Bn(y)||zn(y))return h=h.get(g)||null,d(p,h,y,k,null);Ar(p,y)}return null}function v(h,p,g,y){for(var k=null,C=null,E=p,M=p=0,O=null;E!==null&&M<g.length;M++){E.index>M?(O=E,E=null):O=E.sibling;var R=m(h,E,g[M],y);if(R===null){E===null&&(E=O);break}e&&E&&R.alternate===null&&t(h,E),p=l(R,p,M),C===null?k=R:C.sibling=R,C=R,E=O}if(M===g.length)return n(h,E),B&&Ft(h,M),k;if(E===null){for(;M<g.length;M++)E=f(h,g[M],y),E!==null&&(p=l(E,p,M),C===null?k=E:C.sibling=E,C=E);return B&&Ft(h,M),k}for(E=r(h,E);M<g.length;M++)O=x(E,h,M,g[M],y),O!==null&&(e&&O.alternate!==null&&E.delete(O.key===null?M:O.key),p=l(O,p,M),C===null?k=O:C.sibling=O,C=O);return e&&E.forEach(function(T){return t(h,T)}),B&&Ft(h,M),k}function w(h,p,g,y){var k=zn(g);if(typeof k!="function")throw Error(S(150));if(g=k.call(g),g==null)throw Error(S(151));for(var C=k=null,E=p,M=p=0,O=null,R=g.next();E!==null&&!R.done;M++,R=g.next()){E.index>M?(O=E,E=null):O=E.sibling;var T=m(h,E,R.value,y);if(T===null){E===null&&(E=O);break}e&&E&&T.alternate===null&&t(h,E),p=l(T,p,M),C===null?k=T:C.sibling=T,C=T,E=O}if(R.done)return n(h,E),B&&Ft(h,M),k;if(E===null){for(;!R.done;M++,R=g.next())R=f(h,R.value,y),R!==null&&(p=l(R,p,M),C===null?k=R:C.sibling=R,C=R);return B&&Ft(h,M),k}for(E=r(h,E);!R.done;M++,R=g.next())R=x(E,h,M,R.value,y),R!==null&&(e&&R.alternate!==null&&E.delete(R.key===null?M:R.key),p=l(R,p,M),C===null?k=R:C.sibling=R,C=R);return e&&E.forEach(function(ce){return t(h,ce)}),B&&Ft(h,M),k}function _(h,p,g,y){if(typeof g=="object"&&g!==null&&g.type===on&&g.key===null&&(g=g.props.children),typeof g=="object"&&g!==null){switch(g.$$typeof){case Lr:e:{for(var k=g.key,C=p;C!==null;){if(C.key===k){if(k=g.type,k===on){if(C.tag===7){n(h,C.sibling),p=i(C,g.props.children),p.return=h,h=p;break e}}else if(C.elementType===k||typeof k=="object"&&k!==null&&k.$$typeof===ft&&ps(k)===C.type){n(h,C.sibling),p=i(C,g.props),p.ref=Fn(h,C,g),p.return=h,h=p;break e}n(h,C);break}else t(h,C);C=C.sibling}g.type===on?(p=Wt(g.props.children,h.mode,y,g.key),p.return=h,h=p):(y=oi(g.type,g.key,g.props,null,h.mode,y),y.ref=Fn(h,p,g),y.return=h,h=y)}return o(h);case ln:e:{for(C=g.key;p!==null;){if(p.key===C)if(p.tag===4&&p.stateNode.containerInfo===g.containerInfo&&p.stateNode.implementation===g.implementation){n(h,p.sibling),p=i(p,g.children||[]),p.return=h,h=p;break e}else{n(h,p);break}else t(h,p);p=p.sibling}p=El(g,h.mode,y),p.return=h,h=p}return o(h);case ft:return C=g._init,_(h,p,C(g._payload),y)}if(Bn(g))return v(h,p,g,y);if(zn(g))return w(h,p,g,y);Ar(h,g)}return typeof g=="string"&&g!==""||typeof g=="number"?(g=""+g,p!==null&&p.tag===6?(n(h,p.sibling),p=i(p,g),p.return=h,h=p):(n(h,p),p=Cl(g,h.mode,y),p.return=h,h=p),o(h)):n(h,p)}return _}var Mn=cc(!0),dc=cc(!1),wi=_t(null),Si=null,hn=null,Qo=null;function Yo(){Qo=hn=Si=null}function Xo(e){var t=wi.current;H(wi),e._currentValue=t}function oo(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,r!==null&&(r.childLanes|=t)):r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function kn(e,t){Si=e,Qo=hn=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(ge=!0),e.firstContext=null)}function Pe(e){var t=e._currentValue;if(Qo!==e)if(e={context:e,memoizedValue:t,next:null},hn===null){if(Si===null)throw Error(S(308));hn=e,Si.dependencies={lanes:0,firstContext:e}}else hn=hn.next=e;return t}var Ht=null;function Ko(e){Ht===null?Ht=[e]:Ht.push(e)}function pc(e,t,n,r){var i=t.interleaved;return i===null?(n.next=n,Ko(t)):(n.next=i.next,i.next=n),t.interleaved=n,lt(e,r)}function lt(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var ht=!1;function Zo(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function fc(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function nt(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function Ct(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,D&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,lt(e,n)}return i=r.interleaved,i===null?(t.next=t,Ko(r)):(t.next=i.next,i.next=t),r.interleaved=t,lt(e,n)}function ei(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194240)!==0)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,$o(e,n)}}function fs(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,l=null;if(n=n.firstBaseUpdate,n!==null){do{var o={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};l===null?i=l=o:l=l.next=o,n=n.next}while(n!==null);l===null?i=l=t:l=l.next=t}else i=l=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:l,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function ki(e,t,n,r){var i=e.updateQueue;ht=!1;var l=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var u=s,c=u.next;u.next=null,o===null?l=c:o.next=c,o=u;var d=e.alternate;d!==null&&(d=d.updateQueue,s=d.lastBaseUpdate,s!==o&&(s===null?d.firstBaseUpdate=c:s.next=c,d.lastBaseUpdate=u))}if(l!==null){var f=i.baseState;o=0,d=c=u=null,s=l;do{var m=s.lane,x=s.eventTime;if((r&m)===m){d!==null&&(d=d.next={eventTime:x,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});e:{var v=e,w=s;switch(m=t,x=n,w.tag){case 1:if(v=w.payload,typeof v=="function"){f=v.call(x,f,m);break e}f=v;break e;case 3:v.flags=v.flags&-65537|128;case 0:if(v=w.payload,m=typeof v=="function"?v.call(x,f,m):v,m==null)break e;f=G({},f,m);break e;case 2:ht=!0}}s.callback!==null&&s.lane!==0&&(e.flags|=64,m=i.effects,m===null?i.effects=[s]:m.push(s))}else x={eventTime:x,lane:m,tag:s.tag,payload:s.payload,callback:s.callback,next:null},d===null?(c=d=x,u=f):d=d.next=x,o|=m;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;m=s,s=m.next,m.next=null,i.lastBaseUpdate=m,i.shared.pending=null}}while(!0);if(d===null&&(u=f),i.baseState=u,i.firstBaseUpdate=c,i.lastBaseUpdate=d,t=i.shared.interleaved,t!==null){i=t;do o|=i.lane,i=i.next;while(i!==t)}else l===null&&(i.shared.lanes=0);Xt|=o,e.lanes=o,e.memoizedState=f}}function hs(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],i=r.callback;if(i!==null){if(r.callback=null,r=n,typeof i!="function")throw Error(S(191,i));i.call(r)}}}var kr={},Ke=_t(kr),pr=_t(kr),fr=_t(kr);function Bt(e){if(e===kr)throw Error(S(174));return e}function qo(e,t){switch(A(fr,t),A(pr,e),A(Ke,kr),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:Al(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=Al(t,e)}H(Ke),A(Ke,t)}function Nn(){H(Ke),H(pr),H(fr)}function hc(e){Bt(fr.current);var t=Bt(Ke.current),n=Al(t,e.type);t!==n&&(A(pr,e),A(Ke,n))}function Jo(e){pr.current===e&&(H(Ke),H(pr))}var U=_t(0);function Ci(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var vl=[];function ea(){for(var e=0;e<vl.length;e++)vl[e]._workInProgressVersionPrimary=null;vl.length=0}var ti=at.ReactCurrentDispatcher,yl=at.ReactCurrentBatchConfig,Yt=0,W=null,Z=null,ee=null,Ei=!1,Zn=!1,hr=0,Wf=0;function le(){throw Error(S(321))}function ta(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Be(e[n],t[n]))return!1;return!0}function na(e,t,n,r,i,l){if(Yt=l,W=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,ti.current=e===null||e.memoizedState===null?Xf:Kf,e=n(r,i),Zn){l=0;do{if(Zn=!1,hr=0,25<=l)throw Error(S(301));l+=1,ee=Z=null,t.updateQueue=null,ti.current=Zf,e=n(r,i)}while(Zn)}if(ti.current=ji,t=Z!==null&&Z.next!==null,Yt=0,ee=Z=W=null,Ei=!1,t)throw Error(S(300));return e}function ra(){var e=hr!==0;return hr=0,e}function Qe(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return ee===null?W.memoizedState=ee=e:ee=ee.next=e,ee}function ze(){if(Z===null){var e=W.alternate;e=e!==null?e.memoizedState:null}else e=Z.next;var t=ee===null?W.memoizedState:ee.next;if(t!==null)ee=t,Z=e;else{if(e===null)throw Error(S(310));Z=e,e={memoizedState:Z.memoizedState,baseState:Z.baseState,baseQueue:Z.baseQueue,queue:Z.queue,next:null},ee===null?W.memoizedState=ee=e:ee=ee.next=e}return ee}function mr(e,t){return typeof t=="function"?t(e):t}function xl(e){var t=ze(),n=t.queue;if(n===null)throw Error(S(311));n.lastRenderedReducer=e;var r=Z,i=r.baseQueue,l=n.pending;if(l!==null){if(i!==null){var o=i.next;i.next=l.next,l.next=o}r.baseQueue=i=l,n.pending=null}if(i!==null){l=i.next,r=r.baseState;var s=o=null,u=null,c=l;do{var d=c.lane;if((Yt&d)===d)u!==null&&(u=u.next={lane:0,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),r=c.hasEagerState?c.eagerState:e(r,c.action);else{var f={lane:d,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null};u===null?(s=u=f,o=r):u=u.next=f,W.lanes|=d,Xt|=d}c=c.next}while(c!==null&&c!==l);u===null?o=r:u.next=s,Be(r,t.memoizedState)||(ge=!0),t.memoizedState=r,t.baseState=o,t.baseQueue=u,n.lastRenderedState=r}if(e=n.interleaved,e!==null){i=e;do l=i.lane,W.lanes|=l,Xt|=l,i=i.next;while(i!==e)}else i===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function wl(e){var t=ze(),n=t.queue;if(n===null)throw Error(S(311));n.lastRenderedReducer=e;var r=n.dispatch,i=n.pending,l=t.memoizedState;if(i!==null){n.pending=null;var o=i=i.next;do l=e(l,o.action),o=o.next;while(o!==i);Be(l,t.memoizedState)||(ge=!0),t.memoizedState=l,t.baseQueue===null&&(t.baseState=l),n.lastRenderedState=l}return[l,r]}function mc(){}function gc(e,t){var n=W,r=ze(),i=t(),l=!Be(r.memoizedState,i);if(l&&(r.memoizedState=i,ge=!0),r=r.queue,ia(xc.bind(null,n,r,e),[e]),r.getSnapshot!==t||l||ee!==null&&ee.memoizedState.tag&1){if(n.flags|=2048,gr(9,yc.bind(null,n,r,i,t),void 0,null),te===null)throw Error(S(349));Yt&30||vc(n,t,i)}return i}function vc(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=W.updateQueue,t===null?(t={lastEffect:null,stores:null},W.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function yc(e,t,n,r){t.value=n,t.getSnapshot=r,wc(t)&&Sc(e)}function xc(e,t,n){return n(function(){wc(t)&&Sc(e)})}function wc(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Be(e,n)}catch{return!0}}function Sc(e){var t=lt(e,1);t!==null&&He(t,e,1,-1)}function ms(e){var t=Qe();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:mr,lastRenderedState:e},t.queue=e,e=e.dispatch=Yf.bind(null,W,e),[t.memoizedState,e]}function gr(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=W.updateQueue,t===null?(t={lastEffect:null,stores:null},W.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function kc(){return ze().memoizedState}function ni(e,t,n,r){var i=Qe();W.flags|=e,i.memoizedState=gr(1|t,n,void 0,r===void 0?null:r)}function Ai(e,t,n,r){var i=ze();r=r===void 0?null:r;var l=void 0;if(Z!==null){var o=Z.memoizedState;if(l=o.destroy,r!==null&&ta(r,o.deps)){i.memoizedState=gr(t,n,l,r);return}}W.flags|=e,i.memoizedState=gr(1|t,n,l,r)}function gs(e,t){return ni(8390656,8,e,t)}function ia(e,t){return Ai(2048,8,e,t)}function Cc(e,t){return Ai(4,2,e,t)}function Ec(e,t){return Ai(4,4,e,t)}function jc(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function bc(e,t,n){return n=n!=null?n.concat([e]):null,Ai(4,4,jc.bind(null,t,e),n)}function la(){}function Mc(e,t){var n=ze();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&ta(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function Nc(e,t){var n=ze();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&ta(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function Lc(e,t,n){return Yt&21?(Be(n,t)||(n=zu(),W.lanes|=n,Xt|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,ge=!0),e.memoizedState=n)}function Gf(e,t){var n=F;F=n!==0&&4>n?n:4,e(!0);var r=yl.transition;yl.transition={};try{e(!1),t()}finally{F=n,yl.transition=r}}function Tc(){return ze().memoizedState}function Qf(e,t,n){var r=jt(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},_c(e))Rc(t,n);else if(n=pc(e,t,n,r),n!==null){var i=pe();He(n,e,r,i),Pc(n,t,r)}}function Yf(e,t,n){var r=jt(e),i={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(_c(e))Rc(t,i);else{var l=e.alternate;if(e.lanes===0&&(l===null||l.lanes===0)&&(l=t.lastRenderedReducer,l!==null))try{var o=t.lastRenderedState,s=l(o,n);if(i.hasEagerState=!0,i.eagerState=s,Be(s,o)){var u=t.interleaved;u===null?(i.next=i,Ko(t)):(i.next=u.next,u.next=i),t.interleaved=i;return}}catch{}finally{}n=pc(e,t,i,r),n!==null&&(i=pe(),He(n,e,r,i),Pc(n,t,r))}}function _c(e){var t=e.alternate;return e===W||t!==null&&t===W}function Rc(e,t){Zn=Ei=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Pc(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,$o(e,n)}}var ji={readContext:Pe,useCallback:le,useContext:le,useEffect:le,useImperativeHandle:le,useInsertionEffect:le,useLayoutEffect:le,useMemo:le,useReducer:le,useRef:le,useState:le,useDebugValue:le,useDeferredValue:le,useTransition:le,useMutableSource:le,useSyncExternalStore:le,useId:le,unstable_isNewReconciler:!1},Xf={readContext:Pe,useCallback:function(e,t){return Qe().memoizedState=[e,t===void 0?null:t],e},useContext:Pe,useEffect:gs,useImperativeHandle:function(e,t,n){return n=n!=null?n.concat([e]):null,ni(4194308,4,jc.bind(null,t,e),n)},useLayoutEffect:function(e,t){return ni(4194308,4,e,t)},useInsertionEffect:function(e,t){return ni(4,2,e,t)},useMemo:function(e,t){var n=Qe();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=Qe();return t=n!==void 0?n(t):t,r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=Qf.bind(null,W,e),[r.memoizedState,e]},useRef:function(e){var t=Qe();return e={current:e},t.memoizedState=e},useState:ms,useDebugValue:la,useDeferredValue:function(e){return Qe().memoizedState=e},useTransition:function(){var e=ms(!1),t=e[0];return e=Gf.bind(null,e[1]),Qe().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=W,i=Qe();if(B){if(n===void 0)throw Error(S(407));n=n()}else{if(n=t(),te===null)throw Error(S(349));Yt&30||vc(r,t,n)}i.memoizedState=n;var l={value:n,getSnapshot:t};return i.queue=l,gs(xc.bind(null,r,l,e),[e]),r.flags|=2048,gr(9,yc.bind(null,r,l,n,t),void 0,null),n},useId:function(){var e=Qe(),t=te.identifierPrefix;if(B){var n=tt,r=et;n=(r&~(1<<32-Ve(r)-1)).toString(32)+n,t=":"+t+"R"+n,n=hr++,0<n&&(t+="H"+n.toString(32)),t+=":"}else n=Wf++,t=":"+t+"r"+n.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},Kf={readContext:Pe,useCallback:Mc,useContext:Pe,useEffect:ia,useImperativeHandle:bc,useInsertionEffect:Cc,useLayoutEffect:Ec,useMemo:Nc,useReducer:xl,useRef:kc,useState:function(){return xl(mr)},useDebugValue:la,useDeferredValue:function(e){var t=ze();return Lc(t,Z.memoizedState,e)},useTransition:function(){var e=xl(mr)[0],t=ze().memoizedState;return[e,t]},useMutableSource:mc,useSyncExternalStore:gc,useId:Tc,unstable_isNewReconciler:!1},Zf={readContext:Pe,useCallback:Mc,useContext:Pe,useEffect:ia,useImperativeHandle:bc,useInsertionEffect:Cc,useLayoutEffect:Ec,useMemo:Nc,useReducer:wl,useRef:kc,useState:function(){return wl(mr)},useDebugValue:la,useDeferredValue:function(e){var t=ze();return Z===null?t.memoizedState=e:Lc(t,Z.memoizedState,e)},useTransition:function(){var e=wl(mr)[0],t=ze().memoizedState;return[e,t]},useMutableSource:mc,useSyncExternalStore:gc,useId:Tc,unstable_isNewReconciler:!1};function Oe(e,t){if(e&&e.defaultProps){t=G({},t),e=e.defaultProps;for(var n in e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function ao(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:G({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Vi={isMounted:function(e){return(e=e._reactInternals)?qt(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=pe(),i=jt(e),l=nt(r,i);l.payload=t,n!=null&&(l.callback=n),t=Ct(e,l,i),t!==null&&(He(t,e,i,r),ei(t,e,i))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=pe(),i=jt(e),l=nt(r,i);l.tag=1,l.payload=t,n!=null&&(l.callback=n),t=Ct(e,l,i),t!==null&&(He(t,e,i,r),ei(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=pe(),r=jt(e),i=nt(n,r);i.tag=2,t!=null&&(i.callback=t),t=Ct(e,i,r),t!==null&&(He(t,e,r,n),ei(t,e,r))}};function vs(e,t,n,r,i,l,o){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(r,l,o):t.prototype&&t.prototype.isPureReactComponent?!sr(n,r)||!sr(i,l):!0}function zc(e,t,n){var r=!1,i=Nt,l=t.contextType;return typeof l=="object"&&l!==null?l=Pe(l):(i=ye(t)?Gt:ue.current,r=t.contextTypes,l=(r=r!=null)?jn(e,i):Nt),t=new t(n,l),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=Vi,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=i,e.__reactInternalMemoizedMaskedChildContext=l),t}function ys(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&Vi.enqueueReplaceState(t,t.state,null)}function so(e,t,n,r){var i=e.stateNode;i.props=n,i.state=e.memoizedState,i.refs={},Zo(e);var l=t.contextType;typeof l=="object"&&l!==null?i.context=Pe(l):(l=ye(t)?Gt:ue.current,i.context=jn(e,l)),i.state=e.memoizedState,l=t.getDerivedStateFromProps,typeof l=="function"&&(ao(e,t,l,n),i.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(t=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),t!==i.state&&Vi.enqueueReplaceState(i,i.state,null),ki(e,n,i,r),i.state=e.memoizedState),typeof i.componentDidMount=="function"&&(e.flags|=4194308)}function Ln(e,t){try{var n="",r=t;do n+=Ep(r),r=r.return;while(r);var i=n}catch(l){i=`
Error generating stack: `+l.message+`
`+l.stack}return{value:e,source:t,stack:i,digest:null}}function Sl(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function uo(e,t){try{console.error(t.value)}catch(n){setTimeout(function(){throw n})}}var qf=typeof WeakMap=="function"?WeakMap:Map;function Ic(e,t,n){n=nt(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){Mi||(Mi=!0,wo=r),uo(e,t)},n}function $c(e,t,n){n=nt(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r=="function"){var i=t.value;n.payload=function(){return r(i)},n.callback=function(){uo(e,t)}}var l=e.stateNode;return l!==null&&typeof l.componentDidCatch=="function"&&(n.callback=function(){uo(e,t),typeof r!="function"&&(Et===null?Et=new Set([this]):Et.add(this));var o=t.stack;this.componentDidCatch(t.value,{componentStack:o!==null?o:""})}),n}function xs(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new qf;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(i.add(n),e=ph.bind(null,e,t,n),t.then(e,e))}function ws(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function Ss(e,t,n,r,i){return e.mode&1?(e.flags|=65536,e.lanes=i,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=nt(-1,1),t.tag=2,Ct(n,t,1))),n.lanes|=1),e)}var Jf=at.ReactCurrentOwner,ge=!1;function de(e,t,n,r){t.child=e===null?dc(t,null,n,r):Mn(t,e.child,n,r)}function ks(e,t,n,r,i){n=n.render;var l=t.ref;return kn(t,i),r=na(e,t,n,r,l,i),n=ra(),e!==null&&!ge?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,ot(e,t,i)):(B&&n&&Uo(t),t.flags|=1,de(e,t,r,i),t.child)}function Cs(e,t,n,r,i){if(e===null){var l=n.type;return typeof l=="function"&&!fa(l)&&l.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=l,Dc(e,t,l,r,i)):(e=oi(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(l=e.child,!(e.lanes&i)){var o=l.memoizedProps;if(n=n.compare,n=n!==null?n:sr,n(o,r)&&e.ref===t.ref)return ot(e,t,i)}return t.flags|=1,e=bt(l,r),e.ref=t.ref,e.return=t,t.child=e}function Dc(e,t,n,r,i){if(e!==null){var l=e.memoizedProps;if(sr(l,r)&&e.ref===t.ref)if(ge=!1,t.pendingProps=r=l,(e.lanes&i)!==0)e.flags&131072&&(ge=!0);else return t.lanes=e.lanes,ot(e,t,i)}return co(e,t,n,r,i)}function Oc(e,t,n){var r=t.pendingProps,i=r.children,l=e!==null?e.memoizedState:null;if(r.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},A(gn,ke),ke|=n;else{if(!(n&1073741824))return e=l!==null?l.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,A(gn,ke),ke|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=l!==null?l.baseLanes:n,A(gn,ke),ke|=r}else l!==null?(r=l.baseLanes|n,t.memoizedState=null):r=n,A(gn,ke),ke|=r;return de(e,t,i,n),t.child}function Fc(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function co(e,t,n,r,i){var l=ye(n)?Gt:ue.current;return l=jn(t,l),kn(t,i),n=na(e,t,n,r,l,i),r=ra(),e!==null&&!ge?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,ot(e,t,i)):(B&&r&&Uo(t),t.flags|=1,de(e,t,n,i),t.child)}function Es(e,t,n,r,i){if(ye(n)){var l=!0;vi(t)}else l=!1;if(kn(t,i),t.stateNode===null)ri(e,t),zc(t,n,r),so(t,n,r,i),r=!0;else if(e===null){var o=t.stateNode,s=t.memoizedProps;o.props=s;var u=o.context,c=n.contextType;typeof c=="object"&&c!==null?c=Pe(c):(c=ye(n)?Gt:ue.current,c=jn(t,c));var d=n.getDerivedStateFromProps,f=typeof d=="function"||typeof o.getSnapshotBeforeUpdate=="function";f||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(s!==r||u!==c)&&ys(t,o,r,c),ht=!1;var m=t.memoizedState;o.state=m,ki(t,r,o,i),u=t.memoizedState,s!==r||m!==u||ve.current||ht?(typeof d=="function"&&(ao(t,n,d,r),u=t.memoizedState),(s=ht||vs(t,n,s,r,m,u,c))?(f||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(t.flags|=4194308)):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=u),o.props=r,o.state=u,o.context=c,r=s):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),r=!1)}else{o=t.stateNode,fc(e,t),s=t.memoizedProps,c=t.type===t.elementType?s:Oe(t.type,s),o.props=c,f=t.pendingProps,m=o.context,u=n.contextType,typeof u=="object"&&u!==null?u=Pe(u):(u=ye(n)?Gt:ue.current,u=jn(t,u));var x=n.getDerivedStateFromProps;(d=typeof x=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(s!==f||m!==u)&&ys(t,o,r,u),ht=!1,m=t.memoizedState,o.state=m,ki(t,r,o,i);var v=t.memoizedState;s!==f||m!==v||ve.current||ht?(typeof x=="function"&&(ao(t,n,x,r),v=t.memoizedState),(c=ht||vs(t,n,c,r,m,v,u)||!1)?(d||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(r,v,u),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(r,v,u)),typeof o.componentDidUpdate=="function"&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof o.componentDidUpdate!="function"||s===e.memoizedProps&&m===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||s===e.memoizedProps&&m===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=v),o.props=r,o.state=v,o.context=u,r=c):(typeof o.componentDidUpdate!="function"||s===e.memoizedProps&&m===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||s===e.memoizedProps&&m===e.memoizedState||(t.flags|=1024),r=!1)}return po(e,t,n,r,l,i)}function po(e,t,n,r,i,l){Fc(e,t);var o=(t.flags&128)!==0;if(!r&&!o)return i&&us(t,n,!1),ot(e,t,l);r=t.stateNode,Jf.current=t;var s=o&&typeof n.getDerivedStateFromError!="function"?null:r.render();return t.flags|=1,e!==null&&o?(t.child=Mn(t,e.child,null,l),t.child=Mn(t,null,s,l)):de(e,t,s,l),t.memoizedState=r.state,i&&us(t,n,!0),t.child}function Ac(e){var t=e.stateNode;t.pendingContext?ss(e,t.pendingContext,t.pendingContext!==t.context):t.context&&ss(e,t.context,!1),qo(e,t.containerInfo)}function js(e,t,n,r,i){return bn(),Go(i),t.flags|=256,de(e,t,n,r),t.child}var fo={dehydrated:null,treeContext:null,retryLane:0};function ho(e){return{baseLanes:e,cachePool:null,transitions:null}}function Vc(e,t,n){var r=t.pendingProps,i=U.current,l=!1,o=(t.flags&128)!==0,s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:(i&2)!==0),s?(l=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(i|=1),A(U,i&1),e===null)return lo(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(o=r.children,e=r.fallback,l?(r=t.mode,l=t.child,o={mode:"hidden",children:o},!(r&1)&&l!==null?(l.childLanes=0,l.pendingProps=o):l=Ui(o,r,0,null),e=Wt(e,r,n,null),l.return=t,e.return=t,l.sibling=e,t.child=l,t.child.memoizedState=ho(n),t.memoizedState=fo,e):oa(t,o));if(i=e.memoizedState,i!==null&&(s=i.dehydrated,s!==null))return eh(e,t,o,r,s,i,n);if(l){l=r.fallback,o=t.mode,i=e.child,s=i.sibling;var u={mode:"hidden",children:r.children};return!(o&1)&&t.child!==i?(r=t.child,r.childLanes=0,r.pendingProps=u,t.deletions=null):(r=bt(i,u),r.subtreeFlags=i.subtreeFlags&14680064),s!==null?l=bt(s,l):(l=Wt(l,o,n,null),l.flags|=2),l.return=t,r.return=t,r.sibling=l,t.child=r,r=l,l=t.child,o=e.child.memoizedState,o=o===null?ho(n):{baseLanes:o.baseLanes|n,cachePool:null,transitions:o.transitions},l.memoizedState=o,l.childLanes=e.childLanes&~n,t.memoizedState=fo,r}return l=e.child,e=l.sibling,r=bt(l,{mode:"visible",children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function oa(e,t){return t=Ui({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function Vr(e,t,n,r){return r!==null&&Go(r),Mn(t,e.child,null,n),e=oa(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function eh(e,t,n,r,i,l,o){if(n)return t.flags&256?(t.flags&=-257,r=Sl(Error(S(422))),Vr(e,t,o,r)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(l=r.fallback,i=t.mode,r=Ui({mode:"visible",children:r.children},i,0,null),l=Wt(l,i,o,null),l.flags|=2,r.return=t,l.return=t,r.sibling=l,t.child=r,t.mode&1&&Mn(t,e.child,null,o),t.child.memoizedState=ho(o),t.memoizedState=fo,l);if(!(t.mode&1))return Vr(e,t,o,null);if(i.data==="$!"){if(r=i.nextSibling&&i.nextSibling.dataset,r)var s=r.dgst;return r=s,l=Error(S(419)),r=Sl(l,r,void 0),Vr(e,t,o,r)}if(s=(o&e.childLanes)!==0,ge||s){if(r=te,r!==null){switch(o&-o){case 4:i=2;break;case 16:i=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:i=32;break;case 536870912:i=268435456;break;default:i=0}i=i&(r.suspendedLanes|o)?0:i,i!==0&&i!==l.retryLane&&(l.retryLane=i,lt(e,i),He(r,e,i,-1))}return pa(),r=Sl(Error(S(421))),Vr(e,t,o,r)}return i.data==="$?"?(t.flags|=128,t.child=e.child,t=fh.bind(null,e),i._reactRetry=t,null):(e=l.treeContext,Ee=kt(i.nextSibling),je=t,B=!0,Ae=null,e!==null&&(Le[Te++]=et,Le[Te++]=tt,Le[Te++]=Qt,et=e.id,tt=e.overflow,Qt=t),t=oa(t,r.children),t.flags|=4096,t)}function bs(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),oo(e.return,t,n)}function kl(e,t,n,r,i){var l=e.memoizedState;l===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i}:(l.isBackwards=t,l.rendering=null,l.renderingStartTime=0,l.last=r,l.tail=n,l.tailMode=i)}function Hc(e,t,n){var r=t.pendingProps,i=r.revealOrder,l=r.tail;if(de(e,t,r.children,n),r=U.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&bs(e,n,t);else if(e.tag===19)bs(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(A(U,r),!(t.mode&1))t.memoizedState=null;else switch(i){case"forwards":for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&Ci(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),kl(t,!1,i,n,l);break;case"backwards":for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&Ci(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}kl(t,!0,n,null,l);break;case"together":kl(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function ri(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function ot(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Xt|=t.lanes,!(n&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(S(153));if(t.child!==null){for(e=t.child,n=bt(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=bt(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function th(e,t,n){switch(t.tag){case 3:Ac(t),bn();break;case 5:hc(t);break;case 1:ye(t.type)&&vi(t);break;case 4:qo(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,i=t.memoizedProps.value;A(wi,r._currentValue),r._currentValue=i;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated!==null?(A(U,U.current&1),t.flags|=128,null):n&t.child.childLanes?Vc(e,t,n):(A(U,U.current&1),e=ot(e,t,n),e!==null?e.sibling:null);A(U,U.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return Hc(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),A(U,U.current),r)break;return null;case 22:case 23:return t.lanes=0,Oc(e,t,n)}return ot(e,t,n)}var Bc,mo,Uc,Wc;Bc=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};mo=function(){};Uc=function(e,t,n,r){var i=e.memoizedProps;if(i!==r){e=t.stateNode,Bt(Ke.current);var l=null;switch(n){case"input":i=$l(e,i),r=$l(e,r),l=[];break;case"select":i=G({},i,{value:void 0}),r=G({},r,{value:void 0}),l=[];break;case"textarea":i=Fl(e,i),r=Fl(e,r),l=[];break;default:typeof i.onClick!="function"&&typeof r.onClick=="function"&&(e.onclick=mi)}Vl(n,r);var o;n=null;for(c in i)if(!r.hasOwnProperty(c)&&i.hasOwnProperty(c)&&i[c]!=null)if(c==="style"){var s=i[c];for(o in s)s.hasOwnProperty(o)&&(n||(n={}),n[o]="")}else c!=="dangerouslySetInnerHTML"&&c!=="children"&&c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&c!=="autoFocus"&&(tr.hasOwnProperty(c)?l||(l=[]):(l=l||[]).push(c,null));for(c in r){var u=r[c];if(s=i!=null?i[c]:void 0,r.hasOwnProperty(c)&&u!==s&&(u!=null||s!=null))if(c==="style")if(s){for(o in s)!s.hasOwnProperty(o)||u&&u.hasOwnProperty(o)||(n||(n={}),n[o]="");for(o in u)u.hasOwnProperty(o)&&s[o]!==u[o]&&(n||(n={}),n[o]=u[o])}else n||(l||(l=[]),l.push(c,n)),n=u;else c==="dangerouslySetInnerHTML"?(u=u?u.__html:void 0,s=s?s.__html:void 0,u!=null&&s!==u&&(l=l||[]).push(c,u)):c==="children"?typeof u!="string"&&typeof u!="number"||(l=l||[]).push(c,""+u):c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&(tr.hasOwnProperty(c)?(u!=null&&c==="onScroll"&&V("scroll",e),l||s===u||(l=[])):(l=l||[]).push(c,u))}n&&(l=l||[]).push("style",n);var c=l;(t.updateQueue=c)&&(t.flags|=4)}};Wc=function(e,t,n,r){n!==r&&(t.flags|=4)};function An(e,t){if(!B)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function oe(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&14680064,r|=i.flags&14680064,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function nh(e,t,n){var r=t.pendingProps;switch(Wo(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return oe(t),null;case 1:return ye(t.type)&&gi(),oe(t),null;case 3:return r=t.stateNode,Nn(),H(ve),H(ue),ea(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Fr(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Ae!==null&&(Co(Ae),Ae=null))),mo(e,t),oe(t),null;case 5:Jo(t);var i=Bt(fr.current);if(n=t.type,e!==null&&t.stateNode!=null)Uc(e,t,n,r,i),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(S(166));return oe(t),null}if(e=Bt(Ke.current),Fr(t)){r=t.stateNode,n=t.type;var l=t.memoizedProps;switch(r[Ye]=t,r[dr]=l,e=(t.mode&1)!==0,n){case"dialog":V("cancel",r),V("close",r);break;case"iframe":case"object":case"embed":V("load",r);break;case"video":case"audio":for(i=0;i<Wn.length;i++)V(Wn[i],r);break;case"source":V("error",r);break;case"img":case"image":case"link":V("error",r),V("load",r);break;case"details":V("toggle",r);break;case"input":Ia(r,l),V("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!l.multiple},V("invalid",r);break;case"textarea":Da(r,l),V("invalid",r)}Vl(n,l),i=null;for(var o in l)if(l.hasOwnProperty(o)){var s=l[o];o==="children"?typeof s=="string"?r.textContent!==s&&(l.suppressHydrationWarning!==!0&&Or(r.textContent,s,e),i=["children",s]):typeof s=="number"&&r.textContent!==""+s&&(l.suppressHydrationWarning!==!0&&Or(r.textContent,s,e),i=["children",""+s]):tr.hasOwnProperty(o)&&s!=null&&o==="onScroll"&&V("scroll",r)}switch(n){case"input":Tr(r),$a(r,l,!0);break;case"textarea":Tr(r),Oa(r);break;case"select":case"option":break;default:typeof l.onClick=="function"&&(r.onclick=mi)}r=i,t.updateQueue=r,r!==null&&(t.flags|=4)}else{o=i.nodeType===9?i:i.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=xu(n)),e==="http://www.w3.org/1999/xhtml"?n==="script"?(e=o.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof r.is=="string"?e=o.createElement(n,{is:r.is}):(e=o.createElement(n),n==="select"&&(o=e,r.multiple?o.multiple=!0:r.size&&(o.size=r.size))):e=o.createElementNS(e,n),e[Ye]=t,e[dr]=r,Bc(e,t,!1,!1),t.stateNode=e;e:{switch(o=Hl(n,r),n){case"dialog":V("cancel",e),V("close",e),i=r;break;case"iframe":case"object":case"embed":V("load",e),i=r;break;case"video":case"audio":for(i=0;i<Wn.length;i++)V(Wn[i],e);i=r;break;case"source":V("error",e),i=r;break;case"img":case"image":case"link":V("error",e),V("load",e),i=r;break;case"details":V("toggle",e),i=r;break;case"input":Ia(e,r),i=$l(e,r),V("invalid",e);break;case"option":i=r;break;case"select":e._wrapperState={wasMultiple:!!r.multiple},i=G({},r,{value:void 0}),V("invalid",e);break;case"textarea":Da(e,r),i=Fl(e,r),V("invalid",e);break;default:i=r}Vl(n,i),s=i;for(l in s)if(s.hasOwnProperty(l)){var u=s[l];l==="style"?ku(e,u):l==="dangerouslySetInnerHTML"?(u=u?u.__html:void 0,u!=null&&wu(e,u)):l==="children"?typeof u=="string"?(n!=="textarea"||u!=="")&&nr(e,u):typeof u=="number"&&nr(e,""+u):l!=="suppressContentEditableWarning"&&l!=="suppressHydrationWarning"&&l!=="autoFocus"&&(tr.hasOwnProperty(l)?u!=null&&l==="onScroll"&&V("scroll",e):u!=null&&To(e,l,u,o))}switch(n){case"input":Tr(e),$a(e,r,!1);break;case"textarea":Tr(e),Oa(e);break;case"option":r.value!=null&&e.setAttribute("value",""+Mt(r.value));break;case"select":e.multiple=!!r.multiple,l=r.value,l!=null?yn(e,!!r.multiple,l,!1):r.defaultValue!=null&&yn(e,!!r.multiple,r.defaultValue,!0);break;default:typeof i.onClick=="function"&&(e.onclick=mi)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return oe(t),null;case 6:if(e&&t.stateNode!=null)Wc(e,t,e.memoizedProps,r);else{if(typeof r!="string"&&t.stateNode===null)throw Error(S(166));if(n=Bt(fr.current),Bt(Ke.current),Fr(t)){if(r=t.stateNode,n=t.memoizedProps,r[Ye]=t,(l=r.nodeValue!==n)&&(e=je,e!==null))switch(e.tag){case 3:Or(r.nodeValue,n,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&Or(r.nodeValue,n,(e.mode&1)!==0)}l&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Ye]=t,t.stateNode=r}return oe(t),null;case 13:if(H(U),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(B&&Ee!==null&&t.mode&1&&!(t.flags&128))uc(),bn(),t.flags|=98560,l=!1;else if(l=Fr(t),r!==null&&r.dehydrated!==null){if(e===null){if(!l)throw Error(S(318));if(l=t.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(S(317));l[Ye]=t}else bn(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;oe(t),l=!1}else Ae!==null&&(Co(Ae),Ae=null),l=!0;if(!l)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||U.current&1?q===0&&(q=3):pa())),t.updateQueue!==null&&(t.flags|=4),oe(t),null);case 4:return Nn(),mo(e,t),e===null&&ur(t.stateNode.containerInfo),oe(t),null;case 10:return Xo(t.type._context),oe(t),null;case 17:return ye(t.type)&&gi(),oe(t),null;case 19:if(H(U),l=t.memoizedState,l===null)return oe(t),null;if(r=(t.flags&128)!==0,o=l.rendering,o===null)if(r)An(l,!1);else{if(q!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(o=Ci(e),o!==null){for(t.flags|=128,An(l,!1),r=o.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)l=n,e=r,l.flags&=14680066,o=l.alternate,o===null?(l.childLanes=0,l.lanes=e,l.child=null,l.subtreeFlags=0,l.memoizedProps=null,l.memoizedState=null,l.updateQueue=null,l.dependencies=null,l.stateNode=null):(l.childLanes=o.childLanes,l.lanes=o.lanes,l.child=o.child,l.subtreeFlags=0,l.deletions=null,l.memoizedProps=o.memoizedProps,l.memoizedState=o.memoizedState,l.updateQueue=o.updateQueue,l.type=o.type,e=o.dependencies,l.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return A(U,U.current&1|2),t.child}e=e.sibling}l.tail!==null&&Y()>Tn&&(t.flags|=128,r=!0,An(l,!1),t.lanes=4194304)}else{if(!r)if(e=Ci(o),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),An(l,!0),l.tail===null&&l.tailMode==="hidden"&&!o.alternate&&!B)return oe(t),null}else 2*Y()-l.renderingStartTime>Tn&&n!==1073741824&&(t.flags|=128,r=!0,An(l,!1),t.lanes=4194304);l.isBackwards?(o.sibling=t.child,t.child=o):(n=l.last,n!==null?n.sibling=o:t.child=o,l.last=o)}return l.tail!==null?(t=l.tail,l.rendering=t,l.tail=t.sibling,l.renderingStartTime=Y(),t.sibling=null,n=U.current,A(U,r?n&1|2:n&1),t):(oe(t),null);case 22:case 23:return da(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?ke&1073741824&&(oe(t),t.subtreeFlags&6&&(t.flags|=8192)):oe(t),null;case 24:return null;case 25:return null}throw Error(S(156,t.tag))}function rh(e,t){switch(Wo(t),t.tag){case 1:return ye(t.type)&&gi(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Nn(),H(ve),H(ue),ea(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return Jo(t),null;case 13:if(H(U),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(S(340));bn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return H(U),null;case 4:return Nn(),null;case 10:return Xo(t.type._context),null;case 22:case 23:return da(),null;case 24:return null;default:return null}}var Hr=!1,ae=!1,ih=typeof WeakSet=="function"?WeakSet:Set,b=null;function mn(e,t){var n=e.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){Q(e,t,r)}else n.current=null}function go(e,t,n){try{n()}catch(r){Q(e,t,r)}}var Ms=!1;function lh(e,t){if(ql=pi,e=Ku(),Bo(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var i=r.anchorOffset,l=r.focusNode;r=r.focusOffset;try{n.nodeType,l.nodeType}catch{n=null;break e}var o=0,s=-1,u=-1,c=0,d=0,f=e,m=null;t:for(;;){for(var x;f!==n||i!==0&&f.nodeType!==3||(s=o+i),f!==l||r!==0&&f.nodeType!==3||(u=o+r),f.nodeType===3&&(o+=f.nodeValue.length),(x=f.firstChild)!==null;)m=f,f=x;for(;;){if(f===e)break t;if(m===n&&++c===i&&(s=o),m===l&&++d===r&&(u=o),(x=f.nextSibling)!==null)break;f=m,m=f.parentNode}f=x}n=s===-1||u===-1?null:{start:s,end:u}}else n=null}n=n||{start:0,end:0}}else n=null;for(Jl={focusedElem:e,selectionRange:n},pi=!1,b=t;b!==null;)if(t=b,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,b=e;else for(;b!==null;){t=b;try{var v=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(v!==null){var w=v.memoizedProps,_=v.memoizedState,h=t.stateNode,p=h.getSnapshotBeforeUpdate(t.elementType===t.type?w:Oe(t.type,w),_);h.__reactInternalSnapshotBeforeUpdate=p}break;case 3:var g=t.stateNode.containerInfo;g.nodeType===1?g.textContent="":g.nodeType===9&&g.documentElement&&g.removeChild(g.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(S(163))}}catch(y){Q(t,t.return,y)}if(e=t.sibling,e!==null){e.return=t.return,b=e;break}b=t.return}return v=Ms,Ms=!1,v}function qn(e,t,n){var r=t.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var i=r=r.next;do{if((i.tag&e)===e){var l=i.destroy;i.destroy=void 0,l!==void 0&&go(t,n,l)}i=i.next}while(i!==r)}}function Hi(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function vo(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t=="function"?t(e):t.current=e}}function Gc(e){var t=e.alternate;t!==null&&(e.alternate=null,Gc(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[Ye],delete t[dr],delete t[no],delete t[Vf],delete t[Hf])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function Qc(e){return e.tag===5||e.tag===3||e.tag===4}function Ns(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Qc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function yo(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=mi));else if(r!==4&&(e=e.child,e!==null))for(yo(e,t,n),e=e.sibling;e!==null;)yo(e,t,n),e=e.sibling}function xo(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(xo(e,t,n),e=e.sibling;e!==null;)xo(e,t,n),e=e.sibling}var ne=null,Fe=!1;function ut(e,t,n){for(n=n.child;n!==null;)Yc(e,t,n),n=n.sibling}function Yc(e,t,n){if(Xe&&typeof Xe.onCommitFiberUnmount=="function")try{Xe.onCommitFiberUnmount(zi,n)}catch{}switch(n.tag){case 5:ae||mn(n,t);case 6:var r=ne,i=Fe;ne=null,ut(e,t,n),ne=r,Fe=i,ne!==null&&(Fe?(e=ne,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):ne.removeChild(n.stateNode));break;case 18:ne!==null&&(Fe?(e=ne,n=n.stateNode,e.nodeType===8?ml(e.parentNode,n):e.nodeType===1&&ml(e,n),or(e)):ml(ne,n.stateNode));break;case 4:r=ne,i=Fe,ne=n.stateNode.containerInfo,Fe=!0,ut(e,t,n),ne=r,Fe=i;break;case 0:case 11:case 14:case 15:if(!ae&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){i=r=r.next;do{var l=i,o=l.destroy;l=l.tag,o!==void 0&&(l&2||l&4)&&go(n,t,o),i=i.next}while(i!==r)}ut(e,t,n);break;case 1:if(!ae&&(mn(n,t),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(s){Q(n,t,s)}ut(e,t,n);break;case 21:ut(e,t,n);break;case 22:n.mode&1?(ae=(r=ae)||n.memoizedState!==null,ut(e,t,n),ae=r):ut(e,t,n);break;default:ut(e,t,n)}}function Ls(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new ih),t.forEach(function(r){var i=hh.bind(null,e,r);n.has(r)||(n.add(r),r.then(i,i))})}}function $e(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var i=n[r];try{var l=e,o=t,s=o;e:for(;s!==null;){switch(s.tag){case 5:ne=s.stateNode,Fe=!1;break e;case 3:ne=s.stateNode.containerInfo,Fe=!0;break e;case 4:ne=s.stateNode.containerInfo,Fe=!0;break e}s=s.return}if(ne===null)throw Error(S(160));Yc(l,o,i),ne=null,Fe=!1;var u=i.alternate;u!==null&&(u.return=null),i.return=null}catch(c){Q(i,t,c)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Xc(t,e),t=t.sibling}function Xc(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if($e(t,e),Ge(e),r&4){try{qn(3,e,e.return),Hi(3,e)}catch(w){Q(e,e.return,w)}try{qn(5,e,e.return)}catch(w){Q(e,e.return,w)}}break;case 1:$e(t,e),Ge(e),r&512&&n!==null&&mn(n,n.return);break;case 5:if($e(t,e),Ge(e),r&512&&n!==null&&mn(n,n.return),e.flags&32){var i=e.stateNode;try{nr(i,"")}catch(w){Q(e,e.return,w)}}if(r&4&&(i=e.stateNode,i!=null)){var l=e.memoizedProps,o=n!==null?n.memoizedProps:l,s=e.type,u=e.updateQueue;if(e.updateQueue=null,u!==null)try{s==="input"&&l.type==="radio"&&l.name!=null&&vu(i,l),Hl(s,o);var c=Hl(s,l);for(o=0;o<u.length;o+=2){var d=u[o],f=u[o+1];d==="style"?ku(i,f):d==="dangerouslySetInnerHTML"?wu(i,f):d==="children"?nr(i,f):To(i,d,f,c)}switch(s){case"input":Dl(i,l);break;case"textarea":yu(i,l);break;case"select":var m=i._wrapperState.wasMultiple;i._wrapperState.wasMultiple=!!l.multiple;var x=l.value;x!=null?yn(i,!!l.multiple,x,!1):m!==!!l.multiple&&(l.defaultValue!=null?yn(i,!!l.multiple,l.defaultValue,!0):yn(i,!!l.multiple,l.multiple?[]:"",!1))}i[dr]=l}catch(w){Q(e,e.return,w)}}break;case 6:if($e(t,e),Ge(e),r&4){if(e.stateNode===null)throw Error(S(162));i=e.stateNode,l=e.memoizedProps;try{i.nodeValue=l}catch(w){Q(e,e.return,w)}}break;case 3:if($e(t,e),Ge(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{or(t.containerInfo)}catch(w){Q(e,e.return,w)}break;case 4:$e(t,e),Ge(e);break;case 13:$e(t,e),Ge(e),i=e.child,i.flags&8192&&(l=i.memoizedState!==null,i.stateNode.isHidden=l,!l||i.alternate!==null&&i.alternate.memoizedState!==null||(ua=Y())),r&4&&Ls(e);break;case 22:if(d=n!==null&&n.memoizedState!==null,e.mode&1?(ae=(c=ae)||d,$e(t,e),ae=c):$e(t,e),Ge(e),r&8192){if(c=e.memoizedState!==null,(e.stateNode.isHidden=c)&&!d&&e.mode&1)for(b=e,d=e.child;d!==null;){for(f=b=d;b!==null;){switch(m=b,x=m.child,m.tag){case 0:case 11:case 14:case 15:qn(4,m,m.return);break;case 1:mn(m,m.return);var v=m.stateNode;if(typeof v.componentWillUnmount=="function"){r=m,n=m.return;try{t=r,v.props=t.memoizedProps,v.state=t.memoizedState,v.componentWillUnmount()}catch(w){Q(r,n,w)}}break;case 5:mn(m,m.return);break;case 22:if(m.memoizedState!==null){_s(f);continue}}x!==null?(x.return=m,b=x):_s(f)}d=d.sibling}e:for(d=null,f=e;;){if(f.tag===5){if(d===null){d=f;try{i=f.stateNode,c?(l=i.style,typeof l.setProperty=="function"?l.setProperty("display","none","important"):l.display="none"):(s=f.stateNode,u=f.memoizedProps.style,o=u!=null&&u.hasOwnProperty("display")?u.display:null,s.style.display=Su("display",o))}catch(w){Q(e,e.return,w)}}}else if(f.tag===6){if(d===null)try{f.stateNode.nodeValue=c?"":f.memoizedProps}catch(w){Q(e,e.return,w)}}else if((f.tag!==22&&f.tag!==23||f.memoizedState===null||f===e)&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===e)break e;for(;f.sibling===null;){if(f.return===null||f.return===e)break e;d===f&&(d=null),f=f.return}d===f&&(d=null),f.sibling.return=f.return,f=f.sibling}}break;case 19:$e(t,e),Ge(e),r&4&&Ls(e);break;case 21:break;default:$e(t,e),Ge(e)}}function Ge(e){var t=e.flags;if(t&2){try{e:{for(var n=e.return;n!==null;){if(Qc(n)){var r=n;break e}n=n.return}throw Error(S(160))}switch(r.tag){case 5:var i=r.stateNode;r.flags&32&&(nr(i,""),r.flags&=-33);var l=Ns(e);xo(e,l,i);break;case 3:case 4:var o=r.stateNode.containerInfo,s=Ns(e);yo(e,s,o);break;default:throw Error(S(161))}}catch(u){Q(e,e.return,u)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function oh(e,t,n){b=e,Kc(e)}function Kc(e,t,n){for(var r=(e.mode&1)!==0;b!==null;){var i=b,l=i.child;if(i.tag===22&&r){var o=i.memoizedState!==null||Hr;if(!o){var s=i.alternate,u=s!==null&&s.memoizedState!==null||ae;s=Hr;var c=ae;if(Hr=o,(ae=u)&&!c)for(b=i;b!==null;)o=b,u=o.child,o.tag===22&&o.memoizedState!==null?Rs(i):u!==null?(u.return=o,b=u):Rs(i);for(;l!==null;)b=l,Kc(l),l=l.sibling;b=i,Hr=s,ae=c}Ts(e)}else i.subtreeFlags&8772&&l!==null?(l.return=i,b=l):Ts(e)}}function Ts(e){for(;b!==null;){var t=b;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:ae||Hi(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!ae)if(n===null)r.componentDidMount();else{var i=t.elementType===t.type?n.memoizedProps:Oe(t.type,n.memoizedProps);r.componentDidUpdate(i,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var l=t.updateQueue;l!==null&&hs(t,l,r);break;case 3:var o=t.updateQueue;if(o!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}hs(t,o,n)}break;case 5:var s=t.stateNode;if(n===null&&t.flags&4){n=s;var u=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":u.autoFocus&&n.focus();break;case"img":u.src&&(n.src=u.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var c=t.alternate;if(c!==null){var d=c.memoizedState;if(d!==null){var f=d.dehydrated;f!==null&&or(f)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(S(163))}ae||t.flags&512&&vo(t)}catch(m){Q(t,t.return,m)}}if(t===e){b=null;break}if(n=t.sibling,n!==null){n.return=t.return,b=n;break}b=t.return}}function _s(e){for(;b!==null;){var t=b;if(t===e){b=null;break}var n=t.sibling;if(n!==null){n.return=t.return,b=n;break}b=t.return}}function Rs(e){for(;b!==null;){var t=b;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{Hi(4,t)}catch(u){Q(t,n,u)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount=="function"){var i=t.return;try{r.componentDidMount()}catch(u){Q(t,i,u)}}var l=t.return;try{vo(t)}catch(u){Q(t,l,u)}break;case 5:var o=t.return;try{vo(t)}catch(u){Q(t,o,u)}}}catch(u){Q(t,t.return,u)}if(t===e){b=null;break}var s=t.sibling;if(s!==null){s.return=t.return,b=s;break}b=t.return}}var ah=Math.ceil,bi=at.ReactCurrentDispatcher,aa=at.ReactCurrentOwner,Re=at.ReactCurrentBatchConfig,D=0,te=null,K=null,re=0,ke=0,gn=_t(0),q=0,vr=null,Xt=0,Bi=0,sa=0,Jn=null,me=null,ua=0,Tn=1/0,qe=null,Mi=!1,wo=null,Et=null,Br=!1,yt=null,Ni=0,er=0,So=null,ii=-1,li=0;function pe(){return D&6?Y():ii!==-1?ii:ii=Y()}function jt(e){return e.mode&1?D&2&&re!==0?re&-re:Uf.transition!==null?(li===0&&(li=zu()),li):(e=F,e!==0||(e=window.event,e=e===void 0?16:Vu(e.type)),e):1}function He(e,t,n,r){if(50<er)throw er=0,So=null,Error(S(185));xr(e,n,r),(!(D&2)||e!==te)&&(e===te&&(!(D&2)&&(Bi|=n),q===4&&gt(e,re)),xe(e,r),n===1&&D===0&&!(t.mode&1)&&(Tn=Y()+500,Fi&&Rt()))}function xe(e,t){var n=e.callbackNode;Bp(e,t);var r=di(e,e===te?re:0);if(r===0)n!==null&&Va(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&Va(n),t===1)e.tag===0?Bf(Ps.bind(null,e)):oc(Ps.bind(null,e)),Ff(function(){!(D&6)&&Rt()}),n=null;else{switch(Iu(r)){case 1:n=Io;break;case 4:n=Ru;break;case 16:n=ci;break;case 536870912:n=Pu;break;default:n=ci}n=id(n,Zc.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function Zc(e,t){if(ii=-1,li=0,D&6)throw Error(S(327));var n=e.callbackNode;if(Cn()&&e.callbackNode!==n)return null;var r=di(e,e===te?re:0);if(r===0)return null;if(r&30||r&e.expiredLanes||t)t=Li(e,r);else{t=r;var i=D;D|=2;var l=Jc();(te!==e||re!==t)&&(qe=null,Tn=Y()+500,Ut(e,t));do try{ch();break}catch(s){qc(e,s)}while(!0);Yo(),bi.current=l,D=i,K!==null?t=0:(te=null,re=0,t=q)}if(t!==0){if(t===2&&(i=Ql(e),i!==0&&(r=i,t=ko(e,i))),t===1)throw n=vr,Ut(e,0),gt(e,r),xe(e,Y()),n;if(t===6)gt(e,r);else{if(i=e.current.alternate,!(r&30)&&!sh(i)&&(t=Li(e,r),t===2&&(l=Ql(e),l!==0&&(r=l,t=ko(e,l))),t===1))throw n=vr,Ut(e,0),gt(e,r),xe(e,Y()),n;switch(e.finishedWork=i,e.finishedLanes=r,t){case 0:case 1:throw Error(S(345));case 2:At(e,me,qe);break;case 3:if(gt(e,r),(r&130023424)===r&&(t=ua+500-Y(),10<t)){if(di(e,0)!==0)break;if(i=e.suspendedLanes,(i&r)!==r){pe(),e.pingedLanes|=e.suspendedLanes&i;break}e.timeoutHandle=to(At.bind(null,e,me,qe),t);break}At(e,me,qe);break;case 4:if(gt(e,r),(r&4194240)===r)break;for(t=e.eventTimes,i=-1;0<r;){var o=31-Ve(r);l=1<<o,o=t[o],o>i&&(i=o),r&=~l}if(r=i,r=Y()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*ah(r/1960))-r,10<r){e.timeoutHandle=to(At.bind(null,e,me,qe),r);break}At(e,me,qe);break;case 5:At(e,me,qe);break;default:throw Error(S(329))}}}return xe(e,Y()),e.callbackNode===n?Zc.bind(null,e):null}function ko(e,t){var n=Jn;return e.current.memoizedState.isDehydrated&&(Ut(e,t).flags|=256),e=Li(e,t),e!==2&&(t=me,me=n,t!==null&&Co(t)),e}function Co(e){me===null?me=e:me.push.apply(me,e)}function sh(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var i=n[r],l=i.getSnapshot;i=i.value;try{if(!Be(l(),i))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function gt(e,t){for(t&=~sa,t&=~Bi,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Ve(t),r=1<<n;e[n]=-1,t&=~r}}function Ps(e){if(D&6)throw Error(S(327));Cn();var t=di(e,0);if(!(t&1))return xe(e,Y()),null;var n=Li(e,t);if(e.tag!==0&&n===2){var r=Ql(e);r!==0&&(t=r,n=ko(e,r))}if(n===1)throw n=vr,Ut(e,0),gt(e,t),xe(e,Y()),n;if(n===6)throw Error(S(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,At(e,me,qe),xe(e,Y()),null}function ca(e,t){var n=D;D|=1;try{return e(t)}finally{D=n,D===0&&(Tn=Y()+500,Fi&&Rt())}}function Kt(e){yt!==null&&yt.tag===0&&!(D&6)&&Cn();var t=D;D|=1;var n=Re.transition,r=F;try{if(Re.transition=null,F=1,e)return e()}finally{F=r,Re.transition=n,D=t,!(D&6)&&Rt()}}function da(){ke=gn.current,H(gn)}function Ut(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Of(n)),K!==null)for(n=K.return;n!==null;){var r=n;switch(Wo(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&gi();break;case 3:Nn(),H(ve),H(ue),ea();break;case 5:Jo(r);break;case 4:Nn();break;case 13:H(U);break;case 19:H(U);break;case 10:Xo(r.type._context);break;case 22:case 23:da()}n=n.return}if(te=e,K=e=bt(e.current,null),re=ke=t,q=0,vr=null,sa=Bi=Xt=0,me=Jn=null,Ht!==null){for(t=0;t<Ht.length;t++)if(n=Ht[t],r=n.interleaved,r!==null){n.interleaved=null;var i=r.next,l=n.pending;if(l!==null){var o=l.next;l.next=i,r.next=o}n.pending=r}Ht=null}return e}function qc(e,t){do{var n=K;try{if(Yo(),ti.current=ji,Ei){for(var r=W.memoizedState;r!==null;){var i=r.queue;i!==null&&(i.pending=null),r=r.next}Ei=!1}if(Yt=0,ee=Z=W=null,Zn=!1,hr=0,aa.current=null,n===null||n.return===null){q=1,vr=t,K=null;break}e:{var l=e,o=n.return,s=n,u=t;if(t=re,s.flags|=32768,u!==null&&typeof u=="object"&&typeof u.then=="function"){var c=u,d=s,f=d.tag;if(!(d.mode&1)&&(f===0||f===11||f===15)){var m=d.alternate;m?(d.updateQueue=m.updateQueue,d.memoizedState=m.memoizedState,d.lanes=m.lanes):(d.updateQueue=null,d.memoizedState=null)}var x=ws(o);if(x!==null){x.flags&=-257,Ss(x,o,s,l,t),x.mode&1&&xs(l,c,t),t=x,u=c;var v=t.updateQueue;if(v===null){var w=new Set;w.add(u),t.updateQueue=w}else v.add(u);break e}else{if(!(t&1)){xs(l,c,t),pa();break e}u=Error(S(426))}}else if(B&&s.mode&1){var _=ws(o);if(_!==null){!(_.flags&65536)&&(_.flags|=256),Ss(_,o,s,l,t),Go(Ln(u,s));break e}}l=u=Ln(u,s),q!==4&&(q=2),Jn===null?Jn=[l]:Jn.push(l),l=o;do{switch(l.tag){case 3:l.flags|=65536,t&=-t,l.lanes|=t;var h=Ic(l,u,t);fs(l,h);break e;case 1:s=u;var p=l.type,g=l.stateNode;if(!(l.flags&128)&&(typeof p.getDerivedStateFromError=="function"||g!==null&&typeof g.componentDidCatch=="function"&&(Et===null||!Et.has(g)))){l.flags|=65536,t&=-t,l.lanes|=t;var y=$c(l,s,t);fs(l,y);break e}}l=l.return}while(l!==null)}td(n)}catch(k){t=k,K===n&&n!==null&&(K=n=n.return);continue}break}while(!0)}function Jc(){var e=bi.current;return bi.current=ji,e===null?ji:e}function pa(){(q===0||q===3||q===2)&&(q=4),te===null||!(Xt&268435455)&&!(Bi&268435455)||gt(te,re)}function Li(e,t){var n=D;D|=2;var r=Jc();(te!==e||re!==t)&&(qe=null,Ut(e,t));do try{uh();break}catch(i){qc(e,i)}while(!0);if(Yo(),D=n,bi.current=r,K!==null)throw Error(S(261));return te=null,re=0,q}function uh(){for(;K!==null;)ed(K)}function ch(){for(;K!==null&&!zp();)ed(K)}function ed(e){var t=rd(e.alternate,e,ke);e.memoizedProps=e.pendingProps,t===null?td(e):K=t,aa.current=null}function td(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=rh(n,t),n!==null){n.flags&=32767,K=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{q=6,K=null;return}}else if(n=nh(n,t,ke),n!==null){K=n;return}if(t=t.sibling,t!==null){K=t;return}K=t=e}while(t!==null);q===0&&(q=5)}function At(e,t,n){var r=F,i=Re.transition;try{Re.transition=null,F=1,dh(e,t,n,r)}finally{Re.transition=i,F=r}return null}function dh(e,t,n,r){do Cn();while(yt!==null);if(D&6)throw Error(S(327));n=e.finishedWork;var i=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(S(177));e.callbackNode=null,e.callbackPriority=0;var l=n.lanes|n.childLanes;if(Up(e,l),e===te&&(K=te=null,re=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||Br||(Br=!0,id(ci,function(){return Cn(),null})),l=(n.flags&15990)!==0,n.subtreeFlags&15990||l){l=Re.transition,Re.transition=null;var o=F;F=1;var s=D;D|=4,aa.current=null,lh(e,n),Xc(n,e),_f(Jl),pi=!!ql,Jl=ql=null,e.current=n,oh(n),Ip(),D=s,F=o,Re.transition=l}else e.current=n;if(Br&&(Br=!1,yt=e,Ni=i),l=e.pendingLanes,l===0&&(Et=null),Op(n.stateNode),xe(e,Y()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)i=t[n],r(i.value,{componentStack:i.stack,digest:i.digest});if(Mi)throw Mi=!1,e=wo,wo=null,e;return Ni&1&&e.tag!==0&&Cn(),l=e.pendingLanes,l&1?e===So?er++:(er=0,So=e):er=0,Rt(),null}function Cn(){if(yt!==null){var e=Iu(Ni),t=Re.transition,n=F;try{if(Re.transition=null,F=16>e?16:e,yt===null)var r=!1;else{if(e=yt,yt=null,Ni=0,D&6)throw Error(S(331));var i=D;for(D|=4,b=e.current;b!==null;){var l=b,o=l.child;if(b.flags&16){var s=l.deletions;if(s!==null){for(var u=0;u<s.length;u++){var c=s[u];for(b=c;b!==null;){var d=b;switch(d.tag){case 0:case 11:case 15:qn(8,d,l)}var f=d.child;if(f!==null)f.return=d,b=f;else for(;b!==null;){d=b;var m=d.sibling,x=d.return;if(Gc(d),d===c){b=null;break}if(m!==null){m.return=x,b=m;break}b=x}}}var v=l.alternate;if(v!==null){var w=v.child;if(w!==null){v.child=null;do{var _=w.sibling;w.sibling=null,w=_}while(w!==null)}}b=l}}if(l.subtreeFlags&2064&&o!==null)o.return=l,b=o;else e:for(;b!==null;){if(l=b,l.flags&2048)switch(l.tag){case 0:case 11:case 15:qn(9,l,l.return)}var h=l.sibling;if(h!==null){h.return=l.return,b=h;break e}b=l.return}}var p=e.current;for(b=p;b!==null;){o=b;var g=o.child;if(o.subtreeFlags&2064&&g!==null)g.return=o,b=g;else e:for(o=p;b!==null;){if(s=b,s.flags&2048)try{switch(s.tag){case 0:case 11:case 15:Hi(9,s)}}catch(k){Q(s,s.return,k)}if(s===o){b=null;break e}var y=s.sibling;if(y!==null){y.return=s.return,b=y;break e}b=s.return}}if(D=i,Rt(),Xe&&typeof Xe.onPostCommitFiberRoot=="function")try{Xe.onPostCommitFiberRoot(zi,e)}catch{}r=!0}return r}finally{F=n,Re.transition=t}}return!1}function zs(e,t,n){t=Ln(n,t),t=Ic(e,t,1),e=Ct(e,t,1),t=pe(),e!==null&&(xr(e,1,t),xe(e,t))}function Q(e,t,n){if(e.tag===3)zs(e,e,n);else for(;t!==null;){if(t.tag===3){zs(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(Et===null||!Et.has(r))){e=Ln(n,e),e=$c(t,e,1),t=Ct(t,e,1),e=pe(),t!==null&&(xr(t,1,e),xe(t,e));break}}t=t.return}}function ph(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=pe(),e.pingedLanes|=e.suspendedLanes&n,te===e&&(re&n)===n&&(q===4||q===3&&(re&130023424)===re&&500>Y()-ua?Ut(e,0):sa|=n),xe(e,t)}function nd(e,t){t===0&&(e.mode&1?(t=Pr,Pr<<=1,!(Pr&130023424)&&(Pr=4194304)):t=1);var n=pe();e=lt(e,t),e!==null&&(xr(e,t,n),xe(e,n))}function fh(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),nd(e,n)}function hh(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,i=e.memoizedState;i!==null&&(n=i.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(S(314))}r!==null&&r.delete(t),nd(e,n)}var rd;rd=function(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps||ve.current)ge=!0;else{if(!(e.lanes&n)&&!(t.flags&128))return ge=!1,th(e,t,n);ge=!!(e.flags&131072)}else ge=!1,B&&t.flags&1048576&&ac(t,xi,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;ri(e,t),e=t.pendingProps;var i=jn(t,ue.current);kn(t,n),i=na(null,t,r,e,i,n);var l=ra();return t.flags|=1,typeof i=="object"&&i!==null&&typeof i.render=="function"&&i.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,ye(r)?(l=!0,vi(t)):l=!1,t.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,Zo(t),i.updater=Vi,t.stateNode=i,i._reactInternals=t,so(t,r,e,n),t=po(null,t,r,!0,l,n)):(t.tag=0,B&&l&&Uo(t),de(null,t,i,n),t=t.child),t;case 16:r=t.elementType;e:{switch(ri(e,t),e=t.pendingProps,i=r._init,r=i(r._payload),t.type=r,i=t.tag=gh(r),e=Oe(r,e),i){case 0:t=co(null,t,r,e,n);break e;case 1:t=Es(null,t,r,e,n);break e;case 11:t=ks(null,t,r,e,n);break e;case 14:t=Cs(null,t,r,Oe(r.type,e),n);break e}throw Error(S(306,r,""))}return t;case 0:return r=t.type,i=t.pendingProps,i=t.elementType===r?i:Oe(r,i),co(e,t,r,i,n);case 1:return r=t.type,i=t.pendingProps,i=t.elementType===r?i:Oe(r,i),Es(e,t,r,i,n);case 3:e:{if(Ac(t),e===null)throw Error(S(387));r=t.pendingProps,l=t.memoizedState,i=l.element,fc(e,t),ki(t,r,null,n);var o=t.memoizedState;if(r=o.element,l.isDehydrated)if(l={element:r,isDehydrated:!1,cache:o.cache,pendingSuspenseBoundaries:o.pendingSuspenseBoundaries,transitions:o.transitions},t.updateQueue.baseState=l,t.memoizedState=l,t.flags&256){i=Ln(Error(S(423)),t),t=js(e,t,r,n,i);break e}else if(r!==i){i=Ln(Error(S(424)),t),t=js(e,t,r,n,i);break e}else for(Ee=kt(t.stateNode.containerInfo.firstChild),je=t,B=!0,Ae=null,n=dc(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(bn(),r===i){t=ot(e,t,n);break e}de(e,t,r,n)}t=t.child}return t;case 5:return hc(t),e===null&&lo(t),r=t.type,i=t.pendingProps,l=e!==null?e.memoizedProps:null,o=i.children,eo(r,i)?o=null:l!==null&&eo(r,l)&&(t.flags|=32),Fc(e,t),de(e,t,o,n),t.child;case 6:return e===null&&lo(t),null;case 13:return Vc(e,t,n);case 4:return qo(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=Mn(t,null,r,n):de(e,t,r,n),t.child;case 11:return r=t.type,i=t.pendingProps,i=t.elementType===r?i:Oe(r,i),ks(e,t,r,i,n);case 7:return de(e,t,t.pendingProps,n),t.child;case 8:return de(e,t,t.pendingProps.children,n),t.child;case 12:return de(e,t,t.pendingProps.children,n),t.child;case 10:e:{if(r=t.type._context,i=t.pendingProps,l=t.memoizedProps,o=i.value,A(wi,r._currentValue),r._currentValue=o,l!==null)if(Be(l.value,o)){if(l.children===i.children&&!ve.current){t=ot(e,t,n);break e}}else for(l=t.child,l!==null&&(l.return=t);l!==null;){var s=l.dependencies;if(s!==null){o=l.child;for(var u=s.firstContext;u!==null;){if(u.context===r){if(l.tag===1){u=nt(-1,n&-n),u.tag=2;var c=l.updateQueue;if(c!==null){c=c.shared;var d=c.pending;d===null?u.next=u:(u.next=d.next,d.next=u),c.pending=u}}l.lanes|=n,u=l.alternate,u!==null&&(u.lanes|=n),oo(l.return,n,t),s.lanes|=n;break}u=u.next}}else if(l.tag===10)o=l.type===t.type?null:l.child;else if(l.tag===18){if(o=l.return,o===null)throw Error(S(341));o.lanes|=n,s=o.alternate,s!==null&&(s.lanes|=n),oo(o,n,t),o=l.sibling}else o=l.child;if(o!==null)o.return=l;else for(o=l;o!==null;){if(o===t){o=null;break}if(l=o.sibling,l!==null){l.return=o.return,o=l;break}o=o.return}l=o}de(e,t,i.children,n),t=t.child}return t;case 9:return i=t.type,r=t.pendingProps.children,kn(t,n),i=Pe(i),r=r(i),t.flags|=1,de(e,t,r,n),t.child;case 14:return r=t.type,i=Oe(r,t.pendingProps),i=Oe(r.type,i),Cs(e,t,r,i,n);case 15:return Dc(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,i=t.pendingProps,i=t.elementType===r?i:Oe(r,i),ri(e,t),t.tag=1,ye(r)?(e=!0,vi(t)):e=!1,kn(t,n),zc(t,r,i),so(t,r,i,n),po(null,t,r,!0,e,n);case 19:return Hc(e,t,n);case 22:return Oc(e,t,n)}throw Error(S(156,t.tag))};function id(e,t){return _u(e,t)}function mh(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function _e(e,t,n,r){return new mh(e,t,n,r)}function fa(e){return e=e.prototype,!(!e||!e.isReactComponent)}function gh(e){if(typeof e=="function")return fa(e)?1:0;if(e!=null){if(e=e.$$typeof,e===Ro)return 11;if(e===Po)return 14}return 2}function bt(e,t){var n=e.alternate;return n===null?(n=_e(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function oi(e,t,n,r,i,l){var o=2;if(r=e,typeof e=="function")fa(e)&&(o=1);else if(typeof e=="string")o=5;else e:switch(e){case on:return Wt(n.children,i,l,t);case _o:o=8,i|=8;break;case Rl:return e=_e(12,n,t,i|2),e.elementType=Rl,e.lanes=l,e;case Pl:return e=_e(13,n,t,i),e.elementType=Pl,e.lanes=l,e;case zl:return e=_e(19,n,t,i),e.elementType=zl,e.lanes=l,e;case hu:return Ui(n,i,l,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case pu:o=10;break e;case fu:o=9;break e;case Ro:o=11;break e;case Po:o=14;break e;case ft:o=16,r=null;break e}throw Error(S(130,e==null?e:typeof e,""))}return t=_e(o,n,t,i),t.elementType=e,t.type=r,t.lanes=l,t}function Wt(e,t,n,r){return e=_e(7,e,r,t),e.lanes=n,e}function Ui(e,t,n,r){return e=_e(22,e,r,t),e.elementType=hu,e.lanes=n,e.stateNode={isHidden:!1},e}function Cl(e,t,n){return e=_e(6,e,null,t),e.lanes=n,e}function El(e,t,n){return t=_e(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function vh(e,t,n,r,i){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=il(0),this.expirationTimes=il(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=il(0),this.identifierPrefix=r,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function ha(e,t,n,r,i,l,o,s,u){return e=new vh(e,t,n,s,u),t===1?(t=1,l===!0&&(t|=8)):t=0,l=_e(3,null,null,t),e.current=l,l.stateNode=e,l.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},Zo(l),e}function yh(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:ln,key:r==null?null:""+r,children:e,containerInfo:t,implementation:n}}function ld(e){if(!e)return Nt;e=e._reactInternals;e:{if(qt(e)!==e||e.tag!==1)throw Error(S(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(ye(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(S(171))}if(e.tag===1){var n=e.type;if(ye(n))return lc(e,n,t)}return t}function od(e,t,n,r,i,l,o,s,u){return e=ha(n,r,!0,e,i,l,o,s,u),e.context=ld(null),n=e.current,r=pe(),i=jt(n),l=nt(r,i),l.callback=t??null,Ct(n,l,i),e.current.lanes=i,xr(e,i,r),xe(e,r),e}function Wi(e,t,n,r){var i=t.current,l=pe(),o=jt(i);return n=ld(n),t.context===null?t.context=n:t.pendingContext=n,t=nt(l,o),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=Ct(i,t,o),e!==null&&(He(e,i,o,l),ei(e,i,o)),o}function Ti(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function Is(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function ma(e,t){Is(e,t),(e=e.alternate)&&Is(e,t)}function xh(){return null}var ad=typeof reportError=="function"?reportError:function(e){console.error(e)};function ga(e){this._internalRoot=e}Gi.prototype.render=ga.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(S(409));Wi(e,t,null,null)};Gi.prototype.unmount=ga.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Kt(function(){Wi(null,e,null,null)}),t[it]=null}};function Gi(e){this._internalRoot=e}Gi.prototype.unstable_scheduleHydration=function(e){if(e){var t=Ou();e={blockedOn:null,target:e,priority:t};for(var n=0;n<mt.length&&t!==0&&t<mt[n].priority;n++);mt.splice(n,0,e),n===0&&Au(e)}};function va(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Qi(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function $s(){}function wh(e,t,n,r,i){if(i){if(typeof r=="function"){var l=r;r=function(){var c=Ti(o);l.call(c)}}var o=od(t,r,e,0,null,!1,!1,"",$s);return e._reactRootContainer=o,e[it]=o.current,ur(e.nodeType===8?e.parentNode:e),Kt(),o}for(;i=e.lastChild;)e.removeChild(i);if(typeof r=="function"){var s=r;r=function(){var c=Ti(u);s.call(c)}}var u=ha(e,0,!1,null,null,!1,!1,"",$s);return e._reactRootContainer=u,e[it]=u.current,ur(e.nodeType===8?e.parentNode:e),Kt(function(){Wi(t,u,n,r)}),u}function Yi(e,t,n,r,i){var l=n._reactRootContainer;if(l){var o=l;if(typeof i=="function"){var s=i;i=function(){var u=Ti(o);s.call(u)}}Wi(t,o,e,i)}else o=wh(n,t,e,i,r);return Ti(o)}$u=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=Un(t.pendingLanes);n!==0&&($o(t,n|1),xe(t,Y()),!(D&6)&&(Tn=Y()+500,Rt()))}break;case 13:Kt(function(){var r=lt(e,1);if(r!==null){var i=pe();He(r,e,1,i)}}),ma(e,1)}};Do=function(e){if(e.tag===13){var t=lt(e,134217728);if(t!==null){var n=pe();He(t,e,134217728,n)}ma(e,134217728)}};Du=function(e){if(e.tag===13){var t=jt(e),n=lt(e,t);if(n!==null){var r=pe();He(n,e,t,r)}ma(e,t)}};Ou=function(){return F};Fu=function(e,t){var n=F;try{return F=e,t()}finally{F=n}};Ul=function(e,t,n){switch(t){case"input":if(Dl(e,n),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var i=Oi(r);if(!i)throw Error(S(90));gu(r),Dl(r,i)}}}break;case"textarea":yu(e,n);break;case"select":t=n.value,t!=null&&yn(e,!!n.multiple,t,!1)}};ju=ca;bu=Kt;var Sh={usingClientEntryPoint:!1,Events:[Sr,cn,Oi,Cu,Eu,ca]},Vn={findFiberByHostInstance:Vt,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},kh={bundleType:Vn.bundleType,version:Vn.version,rendererPackageName:Vn.rendererPackageName,rendererConfig:Vn.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:at.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=Lu(e),e===null?null:e.stateNode},findFiberByHostInstance:Vn.findFiberByHostInstance||xh,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Ur=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Ur.isDisabled&&Ur.supportsFiber)try{zi=Ur.inject(kh),Xe=Ur}catch{}}Me.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Sh;Me.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!va(t))throw Error(S(200));return yh(e,t,null,n)};Me.createRoot=function(e,t){if(!va(e))throw Error(S(299));var n=!1,r="",i=ad;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(i=t.onRecoverableError)),t=ha(e,1,!1,null,null,n,!1,r,i),e[it]=t.current,ur(e.nodeType===8?e.parentNode:e),new ga(t)};Me.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(S(188)):(e=Object.keys(e).join(","),Error(S(268,e)));return e=Lu(t),e=e===null?null:e.stateNode,e};Me.flushSync=function(e){return Kt(e)};Me.hydrate=function(e,t,n){if(!Qi(t))throw Error(S(200));return Yi(null,e,t,!0,n)};Me.hydrateRoot=function(e,t,n){if(!va(e))throw Error(S(405));var r=n!=null&&n.hydratedSources||null,i=!1,l="",o=ad;if(n!=null&&(n.unstable_strictMode===!0&&(i=!0),n.identifierPrefix!==void 0&&(l=n.identifierPrefix),n.onRecoverableError!==void 0&&(o=n.onRecoverableError)),t=od(t,null,e,1,n??null,i,!1,l,o),e[it]=t.current,ur(e),r)for(e=0;e<r.length;e++)n=r[e],i=n._getVersion,i=i(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,i]:t.mutableSourceEagerHydrationData.push(n,i);return new Gi(t)};Me.render=function(e,t,n){if(!Qi(t))throw Error(S(200));return Yi(null,e,t,!1,n)};Me.unmountComponentAtNode=function(e){if(!Qi(e))throw Error(S(40));return e._reactRootContainer?(Kt(function(){Yi(null,null,e,!1,function(){e._reactRootContainer=null,e[it]=null})}),!0):!1};Me.unstable_batchedUpdates=ca;Me.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!Qi(n))throw Error(S(200));if(e==null||e._reactInternals===void 0)throw Error(S(38));return Yi(e,t,n,!1,r)};Me.version="18.3.1-next-f1338f8080-20240426";function sd(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(sd)}catch(e){console.error(e)}}sd(),su.exports=Me;var Ch=su.exports,ud,Ds=Ch;ud=Ds.createRoot,Ds.hydrateRoot;const ya=[{value:"visual",label:"视觉"},{value:"copy",label:"文案"},{value:"interaction",label:"交互"},{value:"layout",label:"布局"},{value:"data",label:"数据"},{value:"state",label:"状态"}],cd=[{value:"high",label:"高"},{value:"medium",label:"中"},{value:"low",label:"低"}],Eh=[{value:"open",label:"待处理"},{value:"resolved",label:"已处理"},{value:"deferred",label:"暂缓"}],jh=[{value:"default",label:"默认"},{value:"hover",label:"悬停"},{value:"focus",label:"聚焦"},{value:"active",label:"按下"},{value:"disabled",label:"禁用"},{value:"loading",label:"加载"},{value:"empty",label:"空状态"},{value:"error",label:"错误"}],Ce={category:"visual",priority:"medium",status:"open",interactionState:null,scope:"element"},bh={visual:"视觉",copy:"文案",interaction:"交互",layout:"布局",data:"数据",state:"状态"},Mh={high:"高",medium:"中",low:"低"},Nh={open:"待处理",resolved:"已处理",deferred:"暂缓"},Lh={default:"默认",hover:"悬停",focus:"聚焦",active:"按下",disabled:"禁用",loading:"加载",empty:"空状态",error:"错误"};function dd(e){return bh[e]||e}function pd(e){return Mh[e]||e}function Th(e){return Nh[e]||e}function fd(e){return e===null?"":Lh[e]||e}function Os(e){return e==="interaction"||e==="state"}function se({children:e,hover:t=!1,className:n="",as:r="div"}){const o=["wvaie-inspector-section",t?"wvaie-inspector-section-hover":"",n].filter(Boolean).join(" ");return a.jsx(r,{className:o,children:e})}function hd({disabled:e,hasStyleChanges:t,isPageScope:n=!1,editMode:r,attachMeasurements:i=!1,measurementsAvailable:l=!1,forceAttachMeasurements:o=!1,onToggleAttachMeasurements:s,applyToSimilar:u=!1,similarAvailable:c=!1,similarCount:d=0,onToggleApplyToSimilar:f,embedded:m=!1,onSave:x,onCancelEdit:v}){const[w,_]=I.useState(""),[h,p]=I.useState(Ce.category),[g,y]=I.useState(Ce.priority),[k,C]=I.useState(null),[E,M]=I.useState(!1),[O,R]=I.useState(!1),T=I.useId(),ce=`${T}-comment`,J=`${T}-category`,Ie=`${T}-priority`,st=`${T}-interaction-state`;I.useEffect(()=>{r?(_(r.initialComment),p(r.initialMetadata.category),y(r.initialMetadata.priority),C(r.initialMetadata.interactionState),M(r.initialMetadata.interactionState!==null||Os(r.initialMetadata.category)),R(!0)):(_(""),p(Ce.category),y(Ce.priority),C(null),M(!1),R(!1))},[r]),I.useEffect(()=>{Os(h)&&M(!0)},[h]);function zt(){const L=w.trim();if(!L&&!t)return;const X={category:h,priority:g,status:r?r.initialMetadata.status:Ce.status,interactionState:E?k:null,scope:n?"page":"element"};x(L,X),r||(_(""),p(Ce.category),y(Ce.priority),C(null),M(!1),R(!1))}const It=!e&&(!!w.trim()||t),j=n?"页面评论":"元素评论",P=r?"保存修改":n?"保存页面评论":"保存记录",z=a.jsxs("div",{className:"wvaie-comment-shell",children:[r&&a.jsx("div",{className:"wvaie-edit-mode-banner",children:"编辑模式：正在修改记录"}),a.jsx("h2",{className:"wvaie-card-title",children:j}),a.jsx("textarea",{className:"wvaie-textarea wvaie-comment-textarea",disabled:e,id:ce,onChange:L=>_(L.target.value),placeholder:n?"描述页面整体的问题或建议。":"描述这个元素要怎么改，或仅保存样式变化。",rows:4,value:w}),a.jsxs("div",{className:"wvaie-comment-footer",children:[a.jsxs("div",{className:"wvaie-comment-options",children:[!n&&l&&a.jsxs("label",{className:"wvaie-attach-measurement",children:[a.jsx("input",{type:"checkbox",checked:o||i,disabled:e||o,onChange:L=>s==null?void 0:s(L.target.checked)}),"附加测距数据",o&&a.jsx("span",{className:"wvaie-attach-measurement-hint",children:"（双元素测距必须附测距）"})]}),!n&&c&&a.jsxs("label",{className:"wvaie-attach-measurement",children:[a.jsx("input",{checked:u,disabled:e,onChange:L=>f==null?void 0:f(L.target.checked),type:"checkbox"}),"应用到相似元素（共 ",d," 个）"]}),a.jsx("button",{className:"wvaie-button wvaie-button-text",disabled:e,onClick:()=>R(L=>!L),type:"button",children:O?"收起附加设置":"附加设置"})]}),a.jsxs("div",{className:"wvaie-actions",children:[r&&a.jsx("button",{className:"wvaie-button",onClick:v,type:"button",children:"取消"}),a.jsx("button",{className:"wvaie-button wvaie-button-primary",disabled:!It,onClick:zt,type:"button",children:P})]})]}),O&&a.jsxs("div",{className:"wvaie-comment-meta-panel",children:[a.jsxs("div",{className:"wvaie-form-row",children:[a.jsxs("div",{className:"wvaie-form-field",children:[a.jsx("label",{htmlFor:J,children:"类型"}),a.jsx("select",{id:J,className:"wvaie-select",value:h,onChange:L=>p(L.target.value),disabled:e,children:ya.map(L=>a.jsx("option",{value:L.value,children:L.label},L.value))})]}),a.jsxs("div",{className:"wvaie-form-field",children:[a.jsx("label",{htmlFor:Ie,children:"优先级"}),a.jsx("select",{id:Ie,className:"wvaie-select",value:g,onChange:L=>y(L.target.value),disabled:e,children:cd.map(L=>a.jsx("option",{value:L.value,children:L.label},L.value))})]})]}),E&&!n&&a.jsx("div",{className:"wvaie-form-row",children:a.jsxs("div",{className:"wvaie-form-field",children:[a.jsx("label",{htmlFor:st,children:"交互态"}),a.jsxs("select",{id:st,className:"wvaie-select",value:k||"",onChange:L=>C(L.target.value?L.target.value:null),disabled:e,children:[a.jsx("option",{value:"",children:"无"}),jh.map(L=>a.jsx("option",{value:L.value,children:L.label},L.value))]})]})}),!E&&!n&&a.jsx("button",{type:"button",className:"wvaie-button wvaie-button-text",onClick:()=>M(!0),disabled:e,children:"+ 添加交互态"})]})]});return m?a.jsx("section",{className:"wvaie-comment-editor wvaie-comment-editor-embedded",children:z}):a.jsx(se,{as:"section",className:"wvaie-comment-editor",children:z})}function _h({element:e}){if(!e)return a.jsx(se,{as:"section",className:"wvaie-empty-state",children:a.jsx("p",{children:"已选中元素，可以添加评论或编辑样式。"})});const t=Math.round(e.rect.width),n=Math.round(e.rect.height),r=Math.round(e.rect.x),i=Math.round(e.rect.y),l=Rh(e.selector,e.tagName.toLowerCase()),o=e.text.trim()||l;return a.jsxs(se,{as:"section",className:"wvaie-element-summary",children:[a.jsxs("div",{className:"wvaie-element-head",children:[a.jsx("div",{className:"wvaie-element-tag",children:e.tagName.toLowerCase()}),a.jsxs("span",{className:"wvaie-element-dimensions",children:[t," × ",n," px"]})]}),e.className&&a.jsxs("p",{className:"wvaie-element-path",children:[".",e.className.split(" ").join(".")]}),e.id&&a.jsxs("p",{className:"wvaie-element-path",children:["#",e.id]}),a.jsxs("div",{className:"wvaie-style-section",children:[a.jsx("h2",{className:"wvaie-card-title",children:"位置与尺寸"}),a.jsx("div",{className:"wvaie-style-section-grid",children:a.jsxs("div",{className:"wvaie-style-dual-grid",children:[a.jsx(Wr,{label:"X",value:r}),a.jsx(Wr,{label:"Y",value:i}),a.jsx(Wr,{label:"W",value:t}),a.jsx(Wr,{label:"H",value:n})]})})]}),a.jsxs("div",{className:"wvaie-style-section",children:[a.jsx("h2",{className:"wvaie-card-title",children:"高级信息"}),a.jsxs("div",{className:"wvaie-advanced-info-grid",children:[a.jsxs("div",{className:"wvaie-advanced-info-cell",children:[a.jsx("span",{className:"wvaie-style-row-title",children:"说明"}),a.jsx("p",{className:"wvaie-advanced-info-text",children:o})]}),a.jsxs("div",{className:"wvaie-advanced-info-cell",children:[a.jsx("span",{className:"wvaie-style-row-title",children:"Selector"}),a.jsx("p",{className:"wvaie-advanced-info-text",children:l})]})]})]})]})}function Wr({label:e,value:t}){return a.jsx("div",{className:"wvaie-style-dual-cell",children:a.jsxs("div",{className:"wvaie-style-compact-shell",children:[a.jsx("span",{className:"wvaie-style-icon",children:e}),a.jsx("strong",{className:"wvaie-style-inline-value",children:t})]})})}function Rh(e,t){return e.includes("body")?e:`body > ${e||t}`}function Ph({interactionMode:e,recordsActive:t,recordCount:n,onBrowse:r,onSelectElement:i,onCommentMode:l,onMeasure:o,onAutoLayout:s,onShowRecords:u,onClose:c}){return a.jsx("div",{className:"wvaie-floating-row",children:a.jsxs("nav",{className:"wvaie-floating-toolbar","aria-label":"网页检查工具",children:[a.jsxs("div",{className:"wvaie-toolbar-group",role:"group","aria-label":"操作模式",children:[a.jsx(nn,{active:e==="browse",icon:a.jsx(Ih,{}),label:"浏览",onClick:r}),a.jsx(nn,{active:e==="select",icon:a.jsx(zh,{}),label:"选择",onClick:i}),a.jsx(nn,{active:e==="measure",icon:a.jsx($h,{}),label:"测量",onClick:o}),a.jsx(nn,{active:e==="comment",icon:a.jsx(Dh,{}),label:"评论",onClick:l}),a.jsx(nn,{active:e==="auto-layout",icon:a.jsx(Oh,{}),label:"自动布局",onClick:s})]}),a.jsxs("div",{className:"wvaie-toolbar-group",role:"group","aria-label":"结果操作",children:[a.jsx(nn,{active:t,badge:n>0?n:void 0,icon:a.jsx(Fh,{}),label:"记录",onClick:u,variant:"record"}),a.jsx("span",{className:"wvaie-toolbar-divider"}),a.jsx("button",{className:"wvaie-icon-button wvaie-toolbar-close",type:"button","aria-label":"退出编辑器",onClick:c,children:a.jsx(Ah,{})})]})]})})}function nn({active:e=!1,badge:t,disabled:n=!1,icon:r,label:i,onClick:l,variant:o="icon"}){const s=o==="record";return a.jsxs("button",{className:`wvaie-toolbar-button wvaie-toolbar-button-${o} ${e?"wvaie-toolbar-button-active":""}`,disabled:n,onClick:l,type:"button","aria-pressed":e,"aria-label":i,children:[r,s&&a.jsx("span",{className:"wvaie-toolbar-label",children:i}),t!==void 0&&a.jsx("span",{className:"wvaie-toolbar-badge",children:t})]})}function zh(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4.66675 1.66663H1.66675V4.66663H4.66675V1.66663Z"}),a.jsx("path",{d:"M4.66675 14.6666H1.66675V17.6666H4.66675V14.6666Z"}),a.jsx("path",{d:"M17.6667 1.66663H14.6667V4.66663H17.6667V1.66663Z"}),a.jsx("path",{d:"M3 14V5"}),a.jsx("path",{d:"M4.66675 2.66663H14.6667"}),a.jsx("path",{d:"M8 6L19 12.5L13.0286 13.1842L9.88408 19L8 6Z"})]})}function Ih(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4.99996 14.5891H3.74996H1.66663V3.33868C1.66663 2.87866 2.03972 2.50574 2.49996 2.50574H17.5C17.9602 2.50574 18.3333 2.87866 18.3333 3.33868V14.5891H15"}),a.jsx("path",{d:"M10 13.3334L5.83337 17.5H14.1667L10 13.3334Z"})]})}function $h(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M2.91663 10H17.0833"}),a.jsx("path",{d:"M10 2.91663V17.0833"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M3.75004 2.08337H2.08337V3.75004H3.75004V2.08337Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M7.50004 2.08337H5.83337V3.75004H7.50004V2.08337Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M14.1667 2.08337H12.5V3.75004H14.1667V2.08337Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M17.9167 2.08337H16.25V3.75004H17.9167V2.08337Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M17.9167 5.83337H16.25V7.50004H17.9167V5.83337Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M3.75004 5.83337H2.08337V7.50004H3.75004V5.83337Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M3.75004 16.25H2.08337V17.9167H3.75004V16.25Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M7.50004 16.25H5.83337V17.9167H7.50004V16.25Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M14.1667 16.25H12.5V17.9167H14.1667V16.25Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M17.9167 16.25H16.25V17.9167H17.9167V16.25Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M17.9167 12.5H16.25V14.1667H17.9167V12.5Z"}),a.jsx("path",{className:"wvaie-toolbar-icon-fill",d:"M3.75004 12.5H2.08337V14.1667H3.75004V12.5Z"})]})}function Dh(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M18.3333 9.99996C18.3333 14.6023 14.6023 18.3333 9.99996 18.3333C7.511 18.3333 1.66663 18.3333 1.66663 18.3333C1.66663 18.3333 1.66663 12.1134 1.66663 9.99996C1.66663 5.39758 5.39758 1.66663 9.99996 1.66663C14.6023 1.66663 18.3333 5.39758 18.3333 9.99996Z"}),a.jsx("path",{d:"M6 10H14"}),a.jsx("path",{d:"M10 6L10 14"})]})}function Oh(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M12.5 4.16663L10 1.66663L7.5 4.16663M10 1.66663V5.83329"}),a.jsx("path",{d:"M12.5 15.8333L10 18.3333L7.5 15.8333M10 18.3333V14.1666"}),a.jsx("path",{d:"M15.8333 12.5L18.3333 10L15.8333 7.5M18.3333 10H14.1666"}),a.jsx("path",{d:"M4.16663 12.5L1.66663 10L4.16663 7.5M1.66663 10H5.83329"})]})}function Fh(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M14.1666 4.16663V1.66663H3.33325V15.8333L5.83325 14.5833"}),a.jsx("path",{d:"M5.83325 18.3333V4.16663H16.6666V18.3333L11.2499 15.7197L5.83325 18.3333Z"})]})}function Ah(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4 4L16 16"}),a.jsx("path",{d:"M4 16L16 4"})]})}function Vh({disabled:e,onCopyPrompt:t,onExportJson:n,onImportJson:r}){const[i,l]=I.useState("");function o(){const s=i.trim();s&&(r(s),l(""))}return a.jsxs(se,{as:"footer",className:"wvaie-import-export",children:[a.jsx("h2",{children:"交付与恢复"}),a.jsx("textarea",{className:"wvaie-textarea",onChange:s=>l(s.target.value),placeholder:"粘贴 Web Visual AI Editor JSON 后导入",rows:4,value:i}),a.jsxs("div",{className:"wvaie-footer",children:[a.jsx("button",{className:"wvaie-button",disabled:!i.trim(),onClick:o,type:"button",children:"导入 JSON"}),a.jsx("button",{className:"wvaie-button",disabled:e,onClick:t,type:"button",children:"复制 Prompt"}),a.jsx("button",{className:"wvaie-button wvaie-button-primary",disabled:e,onClick:n,type:"button",children:"导出 JSON"})]}),a.jsx("p",{className:"wvaie-privacy-note",children:"导出内容可能包含页面 URL 与选中文本，请在分享前检查敏感信息。"})]})}function Hh({selectedCategory:e,selectedStatus:t,selectedRange:n,onCategoryChange:r,onStatusChange:i,onRangeChange:l}){return a.jsxs("div",{className:"wvaie-record-filters",children:[a.jsx("div",{className:"wvaie-filter-group",children:a.jsxs("select",{id:"wvaie-filter-category",className:"wvaie-filter-select",value:e,onChange:o=>r(o.target.value),children:[a.jsx("option",{value:"all",children:"全部"}),ya.map(o=>a.jsx("option",{value:o.value,children:o.label},o.value))]})}),a.jsx("div",{className:"wvaie-filter-group",children:a.jsxs("select",{id:"wvaie-filter-status",className:"wvaie-filter-select",value:t,onChange:o=>i(o.target.value),children:[a.jsx("option",{value:"all",children:"全部"}),Eh.map(o=>a.jsx("option",{value:o.value,children:o.label},o.value))]})}),a.jsx("div",{className:"wvaie-filter-group",children:a.jsxs("select",{id:"wvaie-filter-range",className:"wvaie-filter-select",value:n,onChange:o=>l(o.target.value),children:[a.jsx("option",{value:"all",children:"全部"}),a.jsx("option",{value:"single",children:"单元素"}),a.jsx("option",{value:"shared",children:"批量"})]})})]})}function rn({children:e,variant:t="primary",onClick:n,ariaLabel:r}){const i="wvaie-status-badge",l=`wvaie-status-badge-${t}`,s=[i,l,n?"wvaie-status-badge-clickable":""].filter(Boolean).join(" ");return n?a.jsx("button",{"aria-label":r,className:s,onClick:n,type:"button",children:e}):a.jsx("span",{className:s,children:e})}function Bh({records:e,unmatchedRecordIds:t,filterCategory:n,filterStatus:r,filterRange:i,onLocate:l,onEdit:o,onDelete:s,onStatusChange:u,onFilterCategoryChange:c,onFilterStatusChange:d,onFilterRangeChange:f,onHighlightSharedGroup:m}){const x=e.filter(v=>!(n!=="all"&&v.category!==n||r!=="all"&&v.status!==r||i==="single"&&v.sharedGroup||i==="shared"&&!v.sharedGroup));return a.jsxs("section",{className:"wvaie-record-list-view",children:[a.jsxs("div",{className:"wvaie-record-heading",children:[a.jsx("h2",{children:"修改记录"}),a.jsxs("span",{children:[x.length," / ",e.length]})]}),e.length>0&&a.jsx(Hh,{onCategoryChange:c,onStatusChange:d,onRangeChange:f,selectedCategory:n,selectedStatus:r,selectedRange:i}),e.length===0?a.jsx(se,{className:"wvaie-empty-state",children:a.jsx("p",{children:"还没有修改记录。"})}):x.length===0?a.jsx("p",{className:"wvaie-inline-empty",children:"没有符合当前筛选条件的记录。"}):a.jsx("div",{className:"wvaie-record-list",children:x.map(v=>{var w;return a.jsxs(se,{as:"article",className:"wvaie-record",hover:!0,children:[a.jsxs("div",{className:"wvaie-record-topline",children:[a.jsx(rn,{variant:"info",children:dd(v.category)}),a.jsx(rn,{variant:Uh(v.priority),children:pd(v.priority)}),v.interactionState&&a.jsx(rn,{variant:"info",children:fd(v.interactionState)}),v.sharedGroup&&a.jsxs(rn,{ariaLabel:`高亮批量范围，共 ${v.sharedGroup.totalMatched} 个元素`,onClick:()=>m(v),variant:"warning",children:["批量 × ",v.sharedGroup.totalMatched]}),((w=v.sharedGroup)==null?void 0:w.truncated)&&a.jsx(rn,{variant:"warning",children:"已截断"})]}),v.comment&&a.jsx("p",{className:"wvaie-record-comment",children:v.comment}),a.jsx("p",{className:"wvaie-record-selector",children:v.element?v.element.selector:"页面评论"}),v.styleChanges.length>0&&a.jsx(Wh,{changes:v.styleChanges}),t.has(v.id)&&a.jsx("p",{className:"wvaie-record-warning",children:"当前页面未匹配到元素"}),a.jsxs("div",{className:"wvaie-record-control-row",children:[a.jsxs("select",{"aria-label":"修改记录状态",className:"wvaie-record-status-select",onChange:_=>u(v.id,_.target.value),value:v.status,children:[a.jsx("option",{value:"open",children:"待处理"}),a.jsx("option",{value:"resolved",children:"已处理"}),a.jsx("option",{value:"deferred",children:"暂缓"})]}),a.jsx("button",{className:"wvaie-button",onClick:()=>l(v),type:"button",children:v.element?"定位":"查看"}),a.jsx("button",{className:"wvaie-button",onClick:()=>o(v),type:"button",children:"编辑"}),a.jsx("button",{className:"wvaie-button wvaie-button-danger",onClick:()=>s(v),type:"button",children:"删除"})]})]},v.id)})})]})}function Uh(e){return e==="high"?"error":e==="medium"?"warning":"success"}function Wh({changes:e}){return a.jsx("ul",{className:"wvaie-record-style-list","aria-label":"样式修改",children:e.map(t=>a.jsxs("li",{children:[a.jsx("span",{children:t.label}),a.jsxs("code",{children:[t.oldValue||"空"," -> ",t.newValue||"空"]})]},t.property))})}const md=["px","pt"],Se=md;function gd(e){return typeof e=="string"&&md.includes(e)}function Gh(e,t){var r,i;const n=(i=(r=e.trim().match(/(px|pt)$/i))==null?void 0:r[1])==null?void 0:i.toLowerCase();return gd(n)?n:t}const vd=[{property:"color",label:"文本颜色",inputType:"color"},{property:"backgroundColor",label:"背景色",inputType:"color"},{property:"fontFamily",label:"字体",inputType:"text"},{property:"fontSize",label:"字号",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"fontWeight",label:"字重",inputType:"select"},{property:"lineHeight",label:"行高",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"letterSpacing",label:"字间距",inputType:"text"},{property:"paddingTop",label:"内边距 上",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"paddingRight",label:"内边距 右",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"paddingBottom",label:"内边距 下",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"paddingLeft",label:"内边距 左",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"marginTop",label:"外边距 上",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"marginRight",label:"外边距 右",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"marginBottom",label:"外边距 下",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"marginLeft",label:"外边距 左",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"borderRadius",label:"圆角",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"borderWidth",label:"边框粗细",inputType:"number",unit:"px",unitOptions:[...Se]},{property:"borderColor",label:"边框颜色",inputType:"color"},{property:"boxShadow",label:"阴影",inputType:"text"}],Qh=["400","500","600","700"];function Yh(e){if(!(e instanceof HTMLElement))return[];const t=window.getComputedStyle(e);return vd.map(n=>({property:n.property,label:n.label,inputType:n.inputType,unit:n.unit,unitOptions:n.unitOptions,value:Xh(t,n.property)}))}function Xh(e,t){const n=e[t];return typeof n=="string"?n:""}const Kh=/^\s*(-?(?:\d+\.?\d*|\.\d+))(px|pt)?\s*$/i,Fs={px:1,pt:96/72};function yd(e){return e&&e.length>0?e:Se}function xd(e,t){const n=xa(e,t);return n?{numericText:wa(n.number),unit:n.unit,isNumeric:!0}:{numericText:e,unit:t,isNumeric:!1}}function xa(e,t){var r;const n=e.trim().match(Kh);return n?{number:Number(n[1]),unit:((r=n[2])==null?void 0:r.toLowerCase())??t}:null}function wd(e,t){const n=e.trim();if(!n)return`0${t}`;const r=xa(n,t);return r?`${wa(r.number)}${r.unit}`:e}function Sd(e,t,n){const r=xa(e,n);if(!r)return`0${t}`;const l=r.number*Fs[r.unit]/Fs[t];return`${wa(l)}${t}`}function wa(e){const t=Math.round(e*1e4)/1e4;return Object.is(t,-0)?"0":t.toString().replace(/\.0+$/,"").replace(/(\.\d*?)0+$/,"$1")}const As=["system-ui, sans-serif",'-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif','"SF Pro Display", "PingFang SC", sans-serif','"PingFang SC", "Microsoft YaHei", sans-serif','"Noto Sans SC", sans-serif',"Georgia, serif","ui-monospace, SFMono-Regular, Menlo, Consolas, monospace"],Zh=[{kind:"font",title:"字体/排版",properties:["fontFamily","fontSize","lineHeight","fontWeight"]},{kind:"single",title:"字间距",property:"letterSpacing"},{kind:"color",title:"文本颜色",property:"color"}],qh=[{kind:"corners",title:"圆角",property:"borderRadius"},{kind:"color",title:"背景颜色",property:"backgroundColor"}],Jh=[{kind:"single",title:"描边粗细",property:"borderWidth"},{kind:"color",title:"描边颜色",property:"borderColor"},{kind:"single",title:"阴影",property:"boxShadow"}];function em({supported:e,snapshot:t,draft:n,hasSelection:r,onChange:i,onReset:l}){if(!r)return null;if(!e||t.length===0)return a.jsx(se,{as:"section",children:a.jsx("p",{className:"wvaie-inline-empty",children:"该元素暂不支持样式预览。"})});const o=new Map;t.forEach(u=>o.set(u.property,u));const s=Object.values(n).some(u=>typeof u=="string"&&u.length>0);return a.jsxs(se,{as:"section",className:"wvaie-style-editor",children:[a.jsx(jl,{items:Zh,snapshotMap:o,draft:n,onChange:i}),a.jsx(jl,{items:qh,title:"外观",snapshotMap:o,draft:n,onChange:i}),a.jsx(jl,{items:Jh,title:"描边与效果",snapshotMap:o,draft:n,onChange:i}),s&&a.jsxs("div",{className:"wvaie-preview-banner",role:"status",children:[a.jsx("span",{children:"临时预览尚未记录"}),a.jsx("button",{className:"wvaie-button",onClick:l,type:"button",children:"重置"})]})]})}function jl({draft:e,items:t,onChange:n,snapshotMap:r,title:i}){var o;const l=i??((o=t[0])==null?void 0:o.title)??"";return a.jsxs("section",{className:"wvaie-style-section",children:[a.jsx("h2",{className:"wvaie-card-title",children:l}),a.jsx("div",{className:"wvaie-style-section-grid",children:t.map((s,u)=>{if(s.kind==="font")return a.jsx(tm,{draft:e,onChange:n,properties:s.properties,snapshotMap:r},`${s.kind}-${u}`);if(s.kind==="color"){const d=r.get(s.property);return d?a.jsx(nm,{currentValue:e[s.property]??d.value,label:s.title,onChange:f=>n(s.property,f)},s.property):null}if(s.kind==="corners"){const d=r.get(s.property);return d?a.jsx(rm,{currentValue:e[s.property]??d.value,label:s.title,onChange:f=>n(s.property,f),snapshot:d},s.property):null}const c=r.get(s.property);return c?a.jsx(im,{currentValue:e[s.property]??c.value,label:s.title,onChange:d=>n(s.property,d),snapshot:c},s.property):null})})]})}function tm({draft:e,onChange:t,properties:n,snapshotMap:r}){return a.jsx("div",{className:"wvaie-style-dual-grid",children:n.map(i=>{const l=r.get(i);return l?a.jsx("div",{className:"wvaie-style-dual-cell",children:a.jsx(Sa,{currentValue:e[i]??l.value,icon:kd(i),onChange:o=>t(i,o),snapshot:l})},i):null})})}function nm({currentValue:e,label:t,onChange:n}){return a.jsxs("div",{className:"wvaie-style-color-row",children:[a.jsx("div",{className:"wvaie-style-row-title",children:t}),a.jsxs("div",{className:"wvaie-style-color-strip",children:[a.jsx("input",{"aria-label":`${t}取色器`,className:"wvaie-style-color-swatch",onChange:r=>n(r.target.value),type:"color",value:am(e)}),a.jsx("input",{"aria-label":t,className:"wvaie-style-input wvaie-style-color-value",onChange:r=>n(r.target.value),type:"text",value:e}),a.jsx("div",{className:"wvaie-style-alpha-pill",children:"100%"})]})]})}function rm({currentValue:e,label:t,onChange:n,snapshot:r}){return a.jsxs("div",{className:"wvaie-style-corner-row",children:[a.jsx("div",{className:"wvaie-style-row-title",children:t}),a.jsx("div",{className:"wvaie-style-dual-grid",children:["top-left","top-right","bottom-left","bottom-right"].map(i=>a.jsx("div",{className:"wvaie-style-dual-cell",children:a.jsx(Sa,{currentValue:e,icon:a.jsx(mm,{corner:i}),onChange:n,snapshot:r})},i))})]})}function im({currentValue:e,label:t,onChange:n,snapshot:r}){const i=r.property==="boxShadow"?"wvaie-style-shadow-row":"wvaie-style-single-row";return a.jsxs("div",{className:i,children:[a.jsx("div",{className:"wvaie-style-row-title",children:t}),a.jsx(Sa,{currentValue:e,icon:kd(r.property),onChange:n,snapshot:r})]})}function Sa({currentValue:e,icon:t,onChange:n,snapshot:r}){return r.property==="fontFamily"?a.jsxs("div",{className:"wvaie-style-compact-shell",children:[a.jsx("span",{className:"wvaie-style-icon",children:t}),a.jsx(lm,{value:e,onChange:n,compact:!0})]}):r.inputType==="select"?a.jsxs("div",{className:"wvaie-style-compact-shell",children:[a.jsx("span",{className:"wvaie-style-icon",children:t}),a.jsx("select",{"aria-label":r.label,className:"wvaie-style-inline-select",onChange:i=>n(i.target.value),value:e,children:Qh.map(i=>a.jsx("option",{value:i,children:i},i))})]}):r.inputType==="number"?a.jsxs("div",{className:"wvaie-style-compact-shell",children:[a.jsx("span",{className:"wvaie-style-icon",children:t}),a.jsx(om,{label:r.label,onChange:n,unit:r.unit??"px",unitOptions:yd(r.unitOptions),value:e})]}):r.property==="boxShadow"?a.jsx("textarea",{"aria-label":r.label,className:"wvaie-textarea wvaie-style-shadow-textarea",onChange:i=>n(i.target.value),rows:3,value:e}):a.jsxs("div",{className:"wvaie-style-compact-shell",children:[a.jsx("span",{className:"wvaie-style-icon",children:t}),a.jsx("input",{"aria-label":r.label,className:"wvaie-style-inline-input",onChange:i=>n(i.target.value),type:"text",value:e})]})}function lm({compact:e=!1,onChange:t,value:n}){const[r,i]=I.useState(As),[l,o]=I.useState(""),[s,u]=I.useState(!1);async function c(){const f=window.queryLocalFonts;if(!f){o("当前浏览器或页面环境不支持读取本地字体，可继续手动输入字体栈。");return}u(!0),o("正在请求本地字体权限…");try{const m=await f(),x=Array.from(new Set(m.map(v=>v.family).filter(Boolean))).sort((v,w)=>v.localeCompare(w));if(x.length===0){o("没有读取到本地字体，已保留默认字体选项。");return}i([...x,...As]),o(`已读取 ${x.length} 个本地字体族。`)}catch{o("本地字体读取被取消或失败，可继续手动输入字体栈。")}finally{u(!1)}}const d=r.includes(n)?n:"";return e?a.jsxs("div",{className:"wvaie-style-font-compact",children:[a.jsxs("select",{"aria-label":"字体选择",className:"wvaie-style-inline-select",onChange:f=>{f.target.value&&t(f.target.value)},value:d,children:[a.jsx("option",{value:"",children:"当前字体"}),r.map(f=>a.jsx("option",{value:f,children:f},f))]}),a.jsx("button",{className:"wvaie-style-font-trigger",disabled:s,onClick:c,type:"button",children:s?"…":a.jsx(vm,{})}),l&&a.jsx("p",{className:"wvaie-font-status",role:"status",children:l})]}):a.jsxs("div",{className:"wvaie-font-family-control",children:[a.jsxs("div",{className:"wvaie-font-family-row",children:[a.jsxs("select",{"aria-label":"字体选择",className:"wvaie-style-select",onChange:f=>{f.target.value&&t(f.target.value)},value:d,children:[a.jsx("option",{value:"",children:"当前 / 手动字体"}),r.map(f=>a.jsx("option",{value:f,children:f},f))]}),a.jsx("button",{className:"wvaie-button wvaie-button-text",disabled:s,onClick:c,type:"button",children:s?"读取中":"读取本地字体"})]}),a.jsx("input",{"aria-label":"字体栈",className:"wvaie-style-input",onChange:f=>t(f.target.value),placeholder:"例如 SF Pro Display, PingFang SC, sans-serif",type:"text",value:n}),l&&a.jsx("p",{className:"wvaie-font-status",role:"status",children:l})]})}function om({label:e,onChange:t,unit:n,unitOptions:r,value:i}){const{numericText:l,unit:o}=xd(i,n),s=r.includes(o)?o:r[0]??n;function u(d){const f=d.target.value;if(!f.trim()){t(`0${s}`);return}t(wd(f,s))}function c(d){const f=d.target.value;t(Sd(i,f,s))}return a.jsxs("div",{className:"wvaie-style-inline-length",children:[a.jsx("input",{"aria-label":`${e}数值`,className:"wvaie-style-inline-input",inputMode:"decimal",onChange:u,type:"text",value:l}),a.jsx("select",{"aria-label":`${e}单位`,className:"wvaie-style-inline-unit",onChange:c,value:s,children:r.map(d=>a.jsx("option",{value:d,children:d},d))})]})}function am(e){const t=e.trim();if(/^#([0-9a-fA-F]{6})$/.test(t))return t;const n=t.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);return n?`#${bl(n[1])}${bl(n[2])}${bl(n[3])}`:"#000000"}function bl(e){return Number(e).toString(16).padStart(2,"0")}function kd(e){switch(e){case"fontFamily":return a.jsx(sm,{});case"fontSize":return a.jsx(um,{});case"lineHeight":return a.jsx(cm,{});case"fontWeight":return a.jsx(dm,{});case"letterSpacing":return a.jsx(pm,{});case"borderWidth":return a.jsx(fm,{});case"boxShadow":return a.jsx(hm,{});default:return a.jsx(gm,{})}}function sm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4 5H16"}),a.jsx("path",{d:"M7 15L10 5L13 15"}),a.jsx("path",{d:"M8.25 11H11.75"})]})}function um(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4 6H14"}),a.jsx("path",{d:"M9 6V16"}),a.jsx("path",{d:"M15 10H18"}),a.jsx("path",{d:"M16.5 10V16"})]})}function cm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M5 5H15"}),a.jsx("path",{d:"M5 10H15"}),a.jsx("path",{d:"M5 15H15"}),a.jsx("path",{d:"M2.75 5V15"})]})}function dm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M6 4H11.5C13.4 4 14.5 5.05 14.5 6.5C14.5 7.55 13.9 8.35 12.85 8.72"}),a.jsx("path",{d:"M6 9H12.25C14.25 9 15.5 10.1 15.5 11.75C15.5 13.65 14.1 15 11.95 15H6V4"})]})}function pm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M6 5L3.5 15"}),a.jsx("path",{d:"M6 5L8.5 15"}),a.jsx("path",{d:"M4.5 11H7.5"}),a.jsx("path",{d:"M12 5L9.5 15"}),a.jsx("path",{d:"M12 5L14.5 15"}),a.jsx("path",{d:"M10.5 11H13.5"}),a.jsx("path",{d:"M2.5 17H17.5"})]})}function fm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4 5H16"}),a.jsx("path",{d:"M4 10H16"}),a.jsx("path",{d:"M4 15H16"})]})}function hm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("rect",{x:"4",y:"4",width:"9",height:"9",rx:"2"}),a.jsx("path",{d:"M8 8H16V16H8Z"})]})}function mm({corner:e}){const t={"top-left":"M15 5H9C6.8 5 5 6.8 5 9V15","top-right":"M5 5H11C13.2 5 15 6.8 15 9V15","bottom-left":"M15 15H9C6.8 15 5 13.2 5 11V5","bottom-right":"M5 15H11C13.2 15 15 13.2 15 11V5"}[e];return a.jsx("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:a.jsx("path",{d:t})})}function gm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M5 5H15V15H5Z"}),a.jsx("path",{d:"M8 8H12V12H8Z"})]})}function vm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M10 4V13"}),a.jsx("path",{d:"M6.5 9.5L10 13L13.5 9.5"}),a.jsx("path",{d:"M5 16H15"})]})}function ym({title:e,message:t,confirmText:n="确认",cancelText:r="取消",onConfirm:i,onCancel:l}){const o=I.useRef(null),s=I.useRef(null),u=I.useRef(l);return u.current=l,I.useEffect(()=>{var x;const c=o.current,d=c==null?void 0:c.getRootNode(),f=d instanceof ShadowRoot?d.activeElement:document.activeElement;(x=s.current)==null||x.focus();function m(v){if(v.key==="Escape"){v.preventDefault(),u.current();return}if(v.key!=="Tab"||!c)return;const w=Array.from(c.querySelectorAll("button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled)")),_=w[0],h=w[w.length-1],p=d instanceof ShadowRoot?d.activeElement:document.activeElement;!_||!h||(v.shiftKey&&p===_?(v.preventDefault(),h.focus()):!v.shiftKey&&p===h&&(v.preventDefault(),_.focus()))}return c==null||c.addEventListener("keydown",m),()=>{c==null||c.removeEventListener("keydown",m),f instanceof HTMLElement&&f.focus()}},[]),a.jsx("div",{className:"wvaie-dialog-backdrop",onClick:l,children:a.jsxs("div",{"aria-describedby":"wvaie-dialog-message","aria-labelledby":"wvaie-dialog-title","aria-modal":"true",className:"wvaie-dialog",onClick:c=>c.stopPropagation(),ref:o,role:"alertdialog",children:[a.jsx("h3",{className:"wvaie-dialog-title",id:"wvaie-dialog-title",children:e}),a.jsx("p",{className:"wvaie-dialog-message",id:"wvaie-dialog-message",children:t}),a.jsxs("div",{className:"wvaie-dialog-actions",children:[a.jsx("button",{type:"button",className:"wvaie-button",onClick:l,ref:s,children:r}),a.jsx("button",{type:"button",className:"wvaie-button wvaie-button-danger",onClick:i,children:n})]})]})})}function xm({measurement:e,measurementMode:t,onExitMeasurementMode:n,onResetPairMeasurement:r}){return a.jsxs(se,{as:"section",className:"wvaie-measurement-panel",children:[a.jsxs("div",{className:"wvaie-mode-banner",children:[a.jsx("strong",{children:"双元素测距"}),a.jsx("span",{children:wm(t)})]}),e&&a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"wvaie-property-section",children:[a.jsx("h2",{children:"尺寸与视口"}),a.jsxs("p",{className:"wvaie-measurement-size",children:[e.size.width," × ",e.size.height," px"]}),a.jsxs("div",{className:"wvaie-value-grid wvaie-four-grid",children:[a.jsx(De,{label:"上",value:e.viewport.top}),a.jsx(De,{label:"右",value:e.viewport.right}),a.jsx(De,{label:"下",value:e.viewport.bottom}),a.jsx(De,{label:"左",value:e.viewport.left})]})]}),e.parent&&a.jsxs("div",{className:"wvaie-property-section",children:[a.jsx("h2",{children:"距父容器"}),a.jsx("p",{className:"wvaie-measurement-selector",children:Vs(e.parent.selector,38)}),a.jsxs("div",{className:"wvaie-value-grid wvaie-four-grid",children:[a.jsx(De,{label:"上",value:e.parent.distances.top}),a.jsx(De,{label:"右",value:e.parent.distances.right}),a.jsx(De,{label:"下",value:e.parent.distances.bottom}),a.jsx(De,{label:"左",value:e.parent.distances.left})]})]}),e.pair&&a.jsxs("div",{className:"wvaie-property-section wvaie-pair-results",children:[a.jsx("h2",{children:"与参照元素 B"}),a.jsx("p",{className:"wvaie-measurement-selector",children:Vs(e.pair.selector,38)}),a.jsxs("div",{className:"wvaie-value-grid",children:[a.jsx(De,{label:"水平",value:e.pair.horizontalDistance}),a.jsx(De,{label:"垂直",value:e.pair.verticalDistance}),a.jsx(De,{label:"中心",value:e.pair.centerDistance})]})]})]}),a.jsxs("div",{className:"wvaie-measurement-actions",children:[a.jsx("button",{className:"wvaie-button",onClick:r,type:"button",children:"重新测距"}),a.jsx("button",{className:"wvaie-button",onClick:n,type:"button",children:"退出测距"})]})]})}function De({label:e,value:t}){return a.jsxs("div",{className:"wvaie-value-cell",children:[a.jsx("span",{children:e}),a.jsx("strong",{children:t})]})}function wm(e){return e==="awaiting-b"?"A 已确定，请点击网页中的参照元素 B":e==="complete"?"测距完成，保存记录会以 A 为修改对象":"请点击网页元素作为起点 A"}function Vs(e,t){return e.length<=t?e:`${e.slice(0,t-1)}...`}const Sm={exact:"精确","class-primary":"主类","tag-only":"结构"};function km({matchLevel:e,primaryFeature:t,totalMatched:n,truncated:r,similar:i,applyToSimilar:l,onHoverSimilar:o,onHighlightAll:s,onToggleApplyToSimilar:u}){const[c,d]=I.useState(!1),f=i.length>0,m=e?Sm[e]:"未识别",x=c?i:i.slice(0,10);return I.useEffect(()=>{d(!1)},[t,n]),a.jsx(se,{as:"section",className:"wvaie-similar-card",children:a.jsxs("details",{className:"wvaie-similar-panel",children:[a.jsxs("summary",{children:[a.jsx("span",{children:"相似元素"}),f?a.jsxs(rn,{variant:"warning",children:[n," 个 / ",m]}):a.jsx("span",{className:"wvaie-similar-count",children:"无匹配"})]}),a.jsx("div",{className:"wvaie-similar-content",children:f?a.jsxs(a.Fragment,{children:[a.jsxs("p",{className:"wvaie-similar-feature",children:[a.jsx("span",{children:"匹配特征"}),a.jsx("code",{title:t,children:t}),r&&a.jsx("span",{className:"wvaie-similar-truncated",children:"已截断"})]}),a.jsxs("label",{className:"wvaie-shared-switch",children:[a.jsxs("span",{children:[a.jsx("strong",{children:"共享元素"}),a.jsx("small",{children:"开启后保存记录会带上这一组相似元素"})]}),a.jsx("input",{checked:l,onChange:v=>{u(v.target.checked),v.target.checked&&s()},type:"checkbox"})]}),a.jsx("p",{className:"wvaie-similar-help",children:"当前元素与以下元素会被作为同一批范围；聚焦或悬停可预览。"}),a.jsx("ul",{className:"wvaie-similar-list","aria-label":"匹配到的其他相似元素",children:x.map((v,w)=>a.jsx("li",{children:a.jsx("button",{className:"wvaie-similar-target",onBlur:()=>o(null),onFocus:()=>o(w),onMouseEnter:()=>o(w),onMouseLeave:()=>o(null),title:v.selector,type:"button",children:v.selector})},`${v.selector}-${w}`))}),i.length>10&&a.jsx("button",{className:"wvaie-button wvaie-button-text",onClick:()=>d(v=>!v),type:"button",children:c?"仅显示前 10 个":`查看全部 ${i.length} 个其他目标`}),a.jsxs("button",{className:"wvaie-button",onClick:s,type:"button",children:["高亮全部 ",n," 个"]})]}):a.jsx("p",{className:"wvaie-inline-empty",children:"当前元素没有可批量应用的相似目标。"})})]})})}function Cm({editMode:e,onSave:t,onCancelEdit:n}){const[r,i]=I.useState(!!e),l=I.useId();return I.useEffect(()=>{e&&i(!0)},[e]),r?a.jsxs(se,{as:"section",className:"wvaie-page-comment-expanded",children:[a.jsxs("div",{className:"wvaie-page-comment-header",children:[a.jsx("h2",{children:"页面评论"}),a.jsx("button",{"aria-controls":l,"aria-expanded":!0,type:"button",className:"wvaie-button wvaie-button-text",onClick:()=>i(!1),children:"收起"})]}),a.jsx("div",{className:"wvaie-page-comment-body",id:l,children:a.jsx(hd,{disabled:!1,editMode:e,embedded:!0,hasStyleChanges:!1,isPageScope:!0,onCancelEdit:n,onSave:t})})]}):a.jsx(se,{as:"section",className:"wvaie-page-comment-collapsed",hover:!0,children:a.jsx("button",{"aria-controls":l,"aria-expanded":!1,type:"button",className:"wvaie-page-comment-trigger",onClick:()=>i(!0),children:"描述页面整体的问题或建议"})})}const Em=[{value:"none",label:"不指定对齐"},{value:"start",label:"起点对齐"},{value:"center",label:"居中对齐"},{value:"end",label:"终点对齐"},{value:"space-between",label:"两端等距"}],jm=[{title:"内边距",items:[{label:"上",property:"paddingTop",icon:a.jsx(ct,{side:"top"})},{label:"右",property:"paddingRight",icon:a.jsx(ct,{side:"right"})},{label:"下",property:"paddingBottom",icon:a.jsx(ct,{side:"bottom"})},{label:"左",property:"paddingLeft",icon:a.jsx(ct,{side:"left"})}]},{title:"外边距",items:[{label:"上",property:"marginTop",icon:a.jsx(ct,{side:"top"})},{label:"右",property:"marginRight",icon:a.jsx(ct,{side:"right"})},{label:"下",property:"marginBottom",icon:a.jsx(ct,{side:"bottom"})},{label:"左",property:"marginLeft",icon:a.jsx(ct,{side:"left"})}]}];function bm(e){return["flex","inline-flex","grid","inline-grid"].includes(e.display)&&e.siblingCount>1}function Mm({context:e,hasSelection:t,spacingDraft:n,spacingSnapshot:r,onStyleChange:i,onSave:l}){var p,g;const[o,s]=I.useState("none"),[u,c]=I.useState("none"),[d,f]=I.useState(""),[m,x]=I.useState(""),v=t&&e!==null&&(o!=="none"||u!=="none"||d.trim()||m.trim()),w=I.useMemo(()=>{const y=new Map;return r.forEach(k=>y.set(k.property,k)),y},[r]);function _(){v&&(l({direction:o,alignment:u,gap:d.trim(),note:m.trim()}),s("none"),c("none"),f(""),x(""))}if(!t)return a.jsxs(se,{as:"section",className:"wvaie-layout-panel",children:[a.jsx("h2",{className:"wvaie-card-title",children:"自动布局"}),a.jsx("p",{className:"wvaie-inline-empty",children:"选择元素后查看父容器布局。"})]});if(!e)return a.jsxs(se,{as:"section",className:"wvaie-layout-panel",children:[a.jsx("h2",{className:"wvaie-card-title",children:"自动布局"}),a.jsx("p",{className:"wvaie-inline-empty",children:"当前元素没有可识别的父容器布局。"})]});if(!bm(e))return a.jsxs(se,{as:"section",className:"wvaie-layout-panel wvaie-layout-panel-empty",children:[a.jsx("h2",{className:"wvaie-card-title",children:"自动布局"}),a.jsx("p",{className:"wvaie-inline-empty",children:"当前父容器不是 flex / grid，或没有可交换的兄弟元素；布局参数已收起，避免产生无效记录。"})]});const h=o!=="none"?o:(p=e.flexDirection)!=null&&p.startsWith("column")?"vertical":(g=e.flexDirection)!=null&&g.startsWith("row")?"horizontal":"none";return a.jsxs(se,{as:"section",className:"wvaie-layout-panel",children:[a.jsx("h2",{className:"wvaie-card-title",children:"自动布局"}),a.jsxs("div",{className:"wvaie-layout-direction-grid",role:"group","aria-label":"布局方向",children:[a.jsx(Hs,{active:h==="vertical",icon:a.jsx(Lm,{}),label:"纵向",onClick:()=>s(o==="vertical"?"none":"vertical")}),a.jsx(Hs,{active:h==="horizontal",icon:a.jsx(Tm,{}),label:"横向",onClick:()=>s(o==="horizontal"?"none":"horizontal")})]}),a.jsxs("div",{className:"wvaie-layout-overview-grid",children:[a.jsxs("div",{className:"wvaie-layout-preview-card",children:[a.jsxs("div",{className:["wvaie-layout-preview-bars",h==="horizontal"?"wvaie-layout-preview-bars-horizontal":""].filter(Boolean).join(" "),"aria-hidden":"true",children:[a.jsx("span",{}),a.jsx("span",{}),a.jsx("span",{})]}),a.jsxs("div",{className:"wvaie-layout-preview-meta",children:[a.jsx("span",{children:"父容器"}),a.jsx("strong",{children:e.parentSelector})]})]}),a.jsxs("div",{className:"wvaie-layout-gap-card",children:[a.jsxs("span",{className:"wvaie-layout-gap-caption",children:[a.jsx(_m,{})," Gap"]}),a.jsx("input",{className:"wvaie-style-input",onChange:y=>f(y.target.value),placeholder:`${e.gap.row}`,value:d})]})]}),jm.map(y=>a.jsxs("div",{className:"wvaie-layout-spacing-block",children:[a.jsx("div",{className:"wvaie-layout-spacing-title",children:y.title}),a.jsx("div",{className:"wvaie-layout-spacing-grid",children:y.items.map(k=>{var C;return a.jsx(Nm,{currentValue:n[k.property]??((C=w.get(k.property))==null?void 0:C.value)??"0px",icon:k.icon,label:k.label,onChange:E=>i(k.property,E),snapshot:w.get(k.property)},k.property)})})]},y.title)),v&&a.jsxs("div",{className:"wvaie-layout-save-strip",role:"status",children:[a.jsx("span",{children:"布局意图尚未保存"}),a.jsx("button",{className:"wvaie-button wvaie-button-primary",onClick:_,type:"button",children:"保存"})]}),a.jsxs("details",{className:"wvaie-layout-advanced",children:[a.jsx("summary",{children:"高级布局信息"}),a.jsxs("div",{className:"wvaie-layout-meta-grid",children:[a.jsxs("div",{className:"wvaie-layout-context-cell",children:[a.jsx("span",{children:"布局"}),a.jsx("strong",{children:e.display})]}),a.jsxs("div",{className:"wvaie-layout-context-cell",children:[a.jsx("span",{children:"位置"}),a.jsxs("strong",{children:[e.childIndex+1," / ",e.siblingCount]})]}),a.jsxs("div",{className:"wvaie-layout-context-cell",children:[a.jsx("span",{children:"横轴"}),a.jsx("strong",{children:e.justifyContent??"未设置"})]}),a.jsxs("div",{className:"wvaie-layout-context-cell",children:[a.jsx("span",{children:"纵轴"}),a.jsx("strong",{children:e.alignItems??"未设置"})]})]}),a.jsx("div",{className:"wvaie-form-row",children:a.jsxs("div",{className:"wvaie-form-field",children:[a.jsx("label",{htmlFor:"wvaie-layout-alignment",children:"对齐方式"}),a.jsx("select",{className:"wvaie-select",id:"wvaie-layout-alignment",value:u,onChange:y=>c(y.target.value),children:Em.map(y=>a.jsx("option",{value:y.value,children:y.label},y.value))})]})}),a.jsxs("div",{className:"wvaie-form-field",children:[a.jsx("label",{htmlFor:"wvaie-layout-note",children:"布局说明"}),a.jsx("textarea",{className:"wvaie-textarea",id:"wvaie-layout-note",onChange:y=>x(y.target.value),placeholder:"补充布局意图，例如保持按钮等宽、移动端换行等。",rows:3,value:m})]})]})]})}function Hs({active:e,icon:t,label:n,onClick:r}){return a.jsxs("button",{"aria-pressed":e,className:`wvaie-layout-mode-button ${e?"wvaie-layout-mode-active":""}`,onClick:r,type:"button",children:[a.jsx("span",{className:"wvaie-layout-mode-icon","aria-hidden":"true",children:t}),n]})}function Nm({currentValue:e,icon:t,label:n,onChange:r,snapshot:i}){const l=(i==null?void 0:i.unit)??"px",o=yd(i==null?void 0:i.unitOptions);return a.jsxs("div",{className:"wvaie-layout-spacing-cell",children:[a.jsxs("div",{className:"wvaie-layout-spacing-meta",children:[a.jsx("span",{className:"wvaie-layout-spacing-icon","aria-hidden":"true",children:t}),a.jsx("span",{className:"wvaie-layout-spacing-label",children:n})]}),a.jsx(Rm,{label:n,onChange:r,unit:l,unitOptions:o,value:e})]})}function Lm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M13 3L10.5 5.5L8 3"}),a.jsx("path",{d:"M10.5 5.5V16"}),a.jsx("rect",{x:"3",y:"3",width:"5",height:"5",rx:"1"}),a.jsx("rect",{x:"3",y:"12",width:"5",height:"5",rx:"1"})]})}function Tm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M17 13L14.5 10.5L17 8"}),a.jsx("path",{d:"M14.5 10.5H4"}),a.jsx("rect",{x:"3",y:"3",width:"5",height:"5",rx:"1"}),a.jsx("rect",{x:"12",y:"3",width:"5",height:"5",rx:"1"})]})}function _m(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M4 5H16"}),a.jsx("path",{d:"M7 10H13"}),a.jsx("path",{d:"M4 15H16"})]})}function ct({side:e}){const t={top:a.jsx("path",{d:"M4 5H16"}),right:a.jsx("path",{d:"M15 4V16"}),bottom:a.jsx("path",{d:"M4 15H16"}),left:a.jsx("path",{d:"M5 4V16"})}[e],n={top:{x:7.5,y:9.5},right:{x:6,y:7.5},bottom:{x:7.5,y:5.5},left:{x:9,y:7.5}}[e];return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[t,a.jsx("rect",{x:n.x,y:n.y,width:"5",height:"5",rx:"1"})]})}function Rm({label:e,onChange:t,unit:n,unitOptions:r,value:i}){const{numericText:l,unit:o}=xd(i,n),s=r.includes(o)?o:r[0]??n;function u(d){const f=d.target.value;if(!f.trim()){t(`0${s}`);return}t(wd(f,s))}function c(d){const f=d.target.value;t(Sd(i,f,s))}return a.jsxs("div",{className:"wvaie-style-length",children:[a.jsx("input",{"aria-label":`${e}数值`,className:"wvaie-style-length-input",inputMode:"decimal",onChange:u,type:"text",value:l}),a.jsx("select",{"aria-label":`${e}单位`,className:"wvaie-style-length-unit",onChange:c,value:s,children:r.map(d=>a.jsx("option",{value:d,children:d},d))})]})}function Pm({applyToSimilar:e,recordCount:t,recordsActive:n,similarAvailable:r,similarCount:i,onRefresh:l,onShowRecords:o,onShowInspector:s,onToggleApplyToSimilar:u}){return a.jsxs("div",{className:"wvaie-panel-utility wvaie-panel-drag-handle",title:"拖动此区域移动面板",children:[a.jsxs("div",{className:"wvaie-panel-utility-pill",role:"group","aria-label":"面板视图",children:[a.jsx("button",{"aria-label":"返回属性面板","aria-pressed":!n,className:`wvaie-panel-mode-button ${n?"":"wvaie-panel-mode-button-active"}`,onClick:s,type:"button",children:a.jsx(zm,{})}),a.jsxs("button",{"aria-label":`查看修改记录，共 ${t} 条`,"aria-pressed":n,className:`wvaie-panel-mode-button wvaie-panel-record-toggle ${n?"wvaie-panel-mode-button-active":""}`,onClick:o,type:"button",children:[a.jsx(Im,{}),a.jsx("span",{className:"wvaie-panel-record-label",children:"记录"}),a.jsx("span",{className:"wvaie-panel-utility-badge",children:t})]})]}),a.jsxs("label",{className:`wvaie-panel-shared-pill ${r?"":"wvaie-panel-shared-pill-disabled"}`,children:[a.jsx("span",{className:"wvaie-panel-shared-label",children:"共享元素"}),a.jsx("input",{"aria-label":`共享元素${r?`，共 ${i} 个匹配元素`:"，当前不可用"}`,checked:e,disabled:!r,onChange:c=>u(c.target.checked),type:"checkbox"})]}),a.jsx("button",{className:"wvaie-panel-refresh-circle",onClick:l,type:"button","aria-label":"重置当前样式预览",children:a.jsx($m,{})})]})}function zm(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M8.36282 3.99414L6.59507 2.22638C6.26965 1.90094 5.74199 1.90094 5.41657 2.22638L3.05954 4.5834C2.7341 4.90882 2.7341 5.43649 3.05954 5.7619L4.82732 7.5297"}),a.jsx("path",{d:"M12.0536 15.5893L13.8214 17.357C14.1468 17.6825 14.6745 17.6825 14.9999 17.357L17.3569 15C17.6824 14.6745 17.6824 14.1469 17.3569 13.8215L15.5892 12.0537"}),a.jsx("path",{d:"M17.3656 4.99132L15.0086 2.6343C14.6832 2.30886 14.1555 2.30886 13.8301 2.6343L2.63423 13.8302C2.30879 14.1556 2.30879 14.6832 2.63423 15.0087L4.99125 17.3657C5.31669 17.6911 5.84433 17.6911 6.16976 17.3657L17.3656 6.16983C17.6911 5.8444 17.6911 5.31676 17.3656 4.99132Z"}),a.jsx("path",{className:"wvaie-panel-icon-fill",d:"M9.99999 10.8333C10.4602 10.8333 10.8333 10.4602 10.8333 9.99996C10.8333 9.53972 10.4602 9.16663 9.99999 9.16663C9.53975 9.16663 9.16666 9.53972 9.16666 9.99996C9.16666 10.4602 9.53975 10.8333 9.99999 10.8333Z"}),a.jsx("path",{className:"wvaie-panel-icon-fill",d:"M8.33333 12.5C8.79357 12.5 9.16667 12.1269 9.16667 11.6667C9.16667 11.2065 8.79357 10.8334 8.33333 10.8334C7.8731 10.8334 7.5 11.2065 7.5 11.6667C7.5 12.1269 7.8731 12.5 8.33333 12.5Z"}),a.jsx("path",{className:"wvaie-panel-icon-fill",d:"M11.6667 9.16667C12.1269 9.16667 12.5 8.79357 12.5 8.33333C12.5 7.8731 12.1269 7.5 11.6667 7.5C11.2064 7.5 10.8333 7.8731 10.8333 8.33333C10.8333 8.79357 11.2064 9.16667 11.6667 9.16667Z"})]})}function Im(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M14.1666 4.16663V1.66663H3.33325V15.8333L5.83325 14.5833"}),a.jsx("path",{d:"M5.83325 18.3333V4.16663H16.6666V18.3333L11.2499 15.7197L5.83325 18.3333Z"})]})}function $m(){return a.jsxs("svg",{viewBox:"0 0 20 20","aria-hidden":"true",children:[a.jsx("path",{d:"M17.5 3.33337V10"}),a.jsx("path",{d:"M2.5 10V16.6667"}),a.jsx("path",{d:"M17.5 10C17.5 5.85787 14.1421 2.5 10 2.5C7.88104 2.5 5.96733 3.37873 4.60338 4.79167M2.5 10C2.5 14.1421 5.85787 17.5 10 17.5C12.0232 17.5 13.8592 16.6989 15.2083 15.3966"})]})}const Gr=302,Bs=253,Ot=12;function Dm({target:e,onCancel:t,onSave:n}){const[r,i]=I.useState(""),[l,o]=I.useState(Ce.category),[s,u]=I.useState(Ce.priority),c=I.useRef(null),d=I.useId(),f=I.useMemo(()=>Om(e.rect),[e.rect]),m=r.trim().length>0;I.useEffect(()=>{var v;(v=c.current)==null||v.focus()},[e.element.selector]);function x(){m&&n(r,{category:l,priority:s,status:Ce.status,interactionState:null,scope:"element"})}return a.jsxs("aside",{"aria-label":"快速添加元素评论",className:"wvaie-quick-comment",style:{left:`${f.left}px`,top:`${f.top}px`},children:[a.jsx("h2",{className:"wvaie-quick-comment-title",children:"评论"}),a.jsxs("p",{className:"wvaie-quick-comment-current",title:e.element.selector,children:["当前元素：",e.element.selector]}),a.jsx("textarea",{className:"wvaie-textarea wvaie-quick-comment-textarea",id:d,onChange:v=>i(v.target.value),onKeyDown:v=>{(v.metaKey||v.ctrlKey)&&v.key==="Enter"&&x()},placeholder:"输入评论内容",ref:c,rows:3,value:r}),a.jsxs("div",{className:"wvaie-quick-comment-meta",children:[a.jsx("select",{"aria-label":"评论类型",className:"wvaie-select",onChange:v=>o(v.target.value),value:l,children:ya.map(v=>a.jsx("option",{value:v.value,children:v.label},v.value))}),a.jsx("select",{"aria-label":"优先级",className:"wvaie-select",onChange:v=>u(v.target.value),value:s,children:cd.map(v=>a.jsx("option",{value:v.value,children:v.label},v.value))})]}),a.jsx("div",{className:"wvaie-quick-comment-actions",children:a.jsx("button",{className:"wvaie-button wvaie-button-primary",disabled:!m,type:"button",onClick:x,children:"保存评论"})})]})}function Om(e){const t=window.innerWidth||Gr+Ot*2,n=window.innerHeight||Bs+Ot*2,r=e.x+e.width+14,i=e.x-Gr-14,l=r+Gr<=t-Ot?r:i,o=e.y+Math.min(e.height,40)-18,s=n-Bs-Ot;return{left:Us(Math.round(l),Ot,t-Gr-Ot),top:Us(Math.round(o),Ot,s)}}function Us(e,t,n){return Math.min(Math.max(e,t),Math.max(t,n))}function Fm(e){return e!==null&&["flex","inline-flex","grid","inline-grid"].includes(e.display)&&e.siblingCount>1}function Am({handlers:e,state:t}){var d,f,m,x,v;const[n,r]=I.useState(null),i=t.selectedElement!==null,l=Object.values(t.styleDraft).some(w=>typeof w=="string"&&w.length>0),o=t.interactionMode==="measure",s=t.interactionMode==="auto-layout"||Fm(t.layoutContext);function u(){n&&(e.onDeleteRecord(n),r(null))}const c=t.editingRecord?{recordId:t.editingRecord.id,initialComment:t.editingRecord.comment,initialMetadata:{category:t.editingRecord.category,priority:t.editingRecord.priority,status:t.editingRecord.status,interactionState:t.editingRecord.interactionState,scope:t.editingRecord.scope}}:void 0;return a.jsxs(a.Fragment,{children:[t.enabled&&a.jsx(Ph,{interactionMode:t.interactionMode,onAutoLayout:e.onAutoLayoutMode,onBrowse:e.onBrowseMode,onCommentMode:e.onCommentMode,onClose:e.onClose,onMeasure:e.onEnterMeasurementMode,onSelectElement:e.onSelectMode,onShowRecords:e.onShowRecords,recordCount:t.records.length,recordsActive:t.panelView==="records"}),a.jsxs("main",{className:`wvaie-panel ${t.panelView==="records"?"wvaie-panel-records":"wvaie-panel-style"}`,hidden:!t.enabled,children:[a.jsx(Pm,{applyToSimilar:t.applyToSimilar,onRefresh:e.onResetStylePreview,onShowInspector:e.onShowInspector,onShowRecords:e.onShowRecords,onToggleApplyToSimilar:e.onToggleApplyToSimilar,recordCount:t.records.length,recordsActive:t.panelView==="records",similarAvailable:t.similarElements.length>0,similarCount:t.similarTotalMatched}),t.statusMessage&&a.jsx("p",{className:"wvaie-status-message",role:"status",children:t.statusMessage}),a.jsx("div",{className:"wvaie-scroll",children:t.panelView==="records"?a.jsxs(a.Fragment,{children:[a.jsx(Bh,{filterCategory:t.filterCategory,filterStatus:t.filterStatus,onDelete:w=>r(w),onEdit:e.onEditRecord,onFilterCategoryChange:e.onFilterCategoryChange,onFilterStatusChange:e.onFilterStatusChange,onFilterRangeChange:e.onFilterRangeChange,onHighlightSharedGroup:e.onHighlightSharedGroup,onLocate:e.onLocateRecord,onStatusChange:e.onStatusChange,records:t.records,unmatchedRecordIds:t.unmatchedRecordIds,filterRange:t.filterRange}),a.jsx(Vh,{disabled:t.records.length===0,onCopyPrompt:e.onCopyPrompt,onExportJson:e.onExportJson,onImportJson:e.onImportJson})]}):a.jsxs(a.Fragment,{children:[a.jsx(Cm,{editMode:((d=t.editingRecord)==null?void 0:d.scope)==="page"?c:void 0,onCancelEdit:e.onCancelEdit,onSave:e.onSavePageComment}),a.jsx(_h,{element:t.selectedElement}),i&&((f=t.editingRecord)==null?void 0:f.scope)!=="page"&&a.jsx(km,{matchLevel:t.similarMatchLevel,applyToSimilar:t.applyToSimilar,onHighlightAll:e.onHighlightAllSimilar,onHoverSimilar:e.onHoverSimilar,onToggleApplyToSimilar:e.onToggleApplyToSimilar,primaryFeature:t.similarPrimaryFeature,similar:t.similarElements,totalMatched:t.similarTotalMatched,truncated:t.similarTruncated}),s&&a.jsx(Mm,{context:t.layoutContext,hasSelection:i,onSave:e.onSaveLayoutIntent,spacingDraft:t.styleDraft,spacingSnapshot:t.selectedStyleSnapshot,onStyleChange:e.onStyleDraftChange}),o?a.jsx(xm,{hasSelection:i,measurement:t.measurement,measurementMode:t.measurementMode,onEnterMeasurementMode:e.onEnterMeasurementMode,onExitMeasurementMode:e.onExitMeasurementMode,onResetPairMeasurement:e.onResetPairMeasurement}):a.jsx(em,{draft:t.styleDraft,hasSelection:i,onChange:e.onStyleDraftChange,onReset:e.onResetStylePreview,snapshot:t.selectedStyleSnapshot,supported:t.selectedStyleSupported}),i&&((m=t.editingRecord)==null?void 0:m.scope)!=="page"&&a.jsx(hd,{attachMeasurements:t.attachMeasurements,disabled:!i&&!t.editingRecord,editMode:((x=t.editingRecord)==null?void 0:x.scope)==="element"?c:void 0,forceAttachMeasurements:((v=t.measurement)==null?void 0:v.pair)!==null&&t.measurement!==null,hasStyleChanges:l,measurementsAvailable:t.measurement!==null,applyToSimilar:t.applyToSimilar,similarAvailable:t.similarElements.length>0,similarCount:t.similarTotalMatched,onCancelEdit:e.onCancelEdit,onSave:e.onSaveComment,onToggleAttachMeasurements:e.onToggleAttachMeasurements,onToggleApplyToSimilar:e.onToggleApplyToSimilar})]})}),n&&a.jsx(ym,{cancelText:"取消",confirmText:"删除",message:`确定要删除这条记录吗？${n.element?`元素：${n.element.selector}`:"页面评论"}`,onCancel:()=>r(null),onConfirm:u,title:"删除记录"})]}),t.quickCommentTarget&&a.jsx(Dm,{target:t.quickCommentTarget,onCancel:e.onCancelQuickComment,onSave:e.onSaveQuickComment})]})}const Ws="web-visual-ai-editor-panel-root",dt=8;function Qr(e,t,n){return Math.min(Math.max(e,t),Math.max(t,n))}function Vm(e){return e instanceof Element?e.closest("button, input, select, textarea, a, summary, [role='button'], [contenteditable='true']")!==null:!1}function Hm(e){let t=null,n=null;function r(u){if(u.hidden||!u.style.left||!u.style.top)return;const c=u.getBoundingClientRect(),d=window.innerWidth-c.width-dt,f=window.innerHeight-c.height-dt,m=Qr(c.left,dt,d),x=Qr(c.top,dt,f);u.style.left=`${Math.round(m)}px`,u.style.top=`${Math.round(x)}px`}function i(u){if(!t||u.pointerId!==t.pointerId)return;const c=window.innerWidth-t.width-dt,d=window.innerHeight-t.height-dt,f=Qr(u.clientX-t.offsetX,dt,c),m=Qr(u.clientY-t.offsetY,dt,d);t.panel.style.left=`${Math.round(f)}px`,t.panel.style.top=`${Math.round(m)}px`,u.preventDefault()}function l(u){var c,d;!t||u.pointerId!==t.pointerId||(t.panel.classList.remove("wvaie-panel-dragging"),(d=(c=t.handle).releasePointerCapture)==null||d.call(c,t.pointerId),t=null,window.removeEventListener("pointermove",i),window.removeEventListener("pointerup",l),window.removeEventListener("pointercancel",l))}function o(u){var x;if(!u.isPrimary||u.button!==0||Vm(u.target))return;const c=u.target;if(!(c instanceof Element))return;const d=c.closest(".wvaie-panel-drag-handle, .wvaie-header"),f=d==null?void 0:d.closest(".wvaie-panel");if(!(d instanceof HTMLElement)||!(f instanceof HTMLElement))return;const m=f.getBoundingClientRect();t={handle:d,panel:f,pointerId:u.pointerId,offsetX:u.clientX-m.left,offsetY:u.clientY-m.top,width:m.width,height:m.height},n=f,f.style.left=`${Math.round(m.left)}px`,f.style.top=`${Math.round(m.top)}px`,f.style.right="auto",f.style.bottom="auto",f.classList.add("wvaie-panel-dragging"),(x=d.setPointerCapture)==null||x.call(d,u.pointerId),window.addEventListener("pointermove",i),window.addEventListener("pointerup",l),window.addEventListener("pointercancel",l),u.preventDefault(),u.stopPropagation()}function s(){if(!(n!=null&&n.isConnected)){n=null;return}r(n)}return e.addEventListener("pointerdown",o),window.addEventListener("resize",s),{clamp(){n!=null&&n.isConnected&&r(n)},destroy(){var u,c;e.removeEventListener("pointerdown",o),window.removeEventListener("resize",s),window.removeEventListener("pointermove",i),window.removeEventListener("pointerup",l),window.removeEventListener("pointercancel",l),t==null||t.panel.classList.remove("wvaie-panel-dragging"),t&&((c=(u=t.handle).releasePointerCapture)==null||c.call(u,t.pointerId)),t=null,n=null}}}function Bm(e){var c;(c=document.getElementById(Ws))==null||c.remove();const t=document.createElement("div");t.id=Ws,document.documentElement.appendChild(t);const n=t.attachShadow({mode:"open"}),r=document.createElement("div"),i=document.createElement("style");i.textContent=`
    :host {
      all: initial;
      color-scheme: dark;
      --bg: #121212;
      --bg-panel: linear-gradient(180deg, rgba(24, 24, 24, 0.94) 0%, rgba(15, 15, 15, 0.94) 100%);
      --bg-toolbar: rgba(24, 24, 24, 0.9);
      --bg-raised: rgba(80, 80, 80, 0.5);
      --bg-field: rgba(80, 80, 80, 0.5);
      --bg-field-hover: rgba(80, 80, 80, 0.64);
      --bg-hover: rgba(80, 80, 80, 0.42);
      --border: rgba(255, 255, 255, 0.08);
      --border-strong: rgba(255, 255, 255, 0.18);
      --text: rgba(255, 255, 255, 0.95);
      --text-muted: #e8e8e8;
      --text-dim: rgba(232, 232, 232, 0.5);
      --accent: #535dff;
      --accent-secondary: #aeb5ff;
      --accent-hover: #626bff;
      --accent-soft: rgba(83, 93, 255, 0.16);
      --accent-fill: #535dff;
      --accent-fill-hover: #626bff;
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
      --mono: "SF Mono", ui-monospace, Menlo, Consolas, monospace;
      --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", sans-serif;
      font-family: var(--sans);
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    [hidden] {
      display: none !important;
    }

    button,
    input,
    select,
    textarea {
      font: inherit;
    }

    button {
      color: inherit;
    }

    button:focus-visible,
    input:focus-visible,
    select:focus-visible,
    textarea:focus-visible,
    summary:focus-visible {
      outline: 2px solid var(--accent);
      outline-offset: 1px;
    }

    .wvaie-floating-row {
      position: fixed;
      top: max(14px, env(safe-area-inset-top));
      left: 50%;
      z-index: 2147483646;
      display: flex;
      align-items: center;
      transform: translateX(-50%);
      gap: 10px;
      pointer-events: auto;
    }

    .wvaie-floating-toolbar {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 5px;
      border: 1.5px solid rgba(255, 255, 255, 0.1);
      border-radius: 100px;
      background: rgba(24, 24, 24, 0.9);
      color: #e8e8e8;
      box-shadow: 0 14px 32px rgba(0, 0, 0, 0.28);
      backdrop-filter: blur(8px);
      pointer-events: auto;
    }

    .wvaie-floating-switch,
    .wvaie-floating-refresh {
      display: inline-flex;
      align-items: center;
      min-height: 44px;
      border: 1.5px solid rgba(255, 255, 255, 0.1);
      background: rgba(40, 40, 40, 0.9);
      color: #e8e8e8;
      box-shadow: 0 14px 32px rgba(0, 0, 0, 0.28);
      backdrop-filter: blur(8px);
    }

    .wvaie-floating-switch {
      gap: 10px;
      border-radius: 100px;
      padding: 5px 5px 5px 13px;
      cursor: pointer;
      font-size: 13px;
      line-height: 20px;
      white-space: nowrap;
    }

    .wvaie-floating-switch-disabled {
      cursor: not-allowed;
      opacity: 0.48;
    }

    .wvaie-floating-switch input {
      position: relative;
      width: 56px;
      height: 32px;
      margin: 0;
      border: 0;
      border-radius: 999px;
      appearance: none;
      background: rgba(80, 80, 80, 0.6);
      cursor: pointer;
      transition: background 160ms ease-out;
    }

    .wvaie-floating-switch input::before {
      position: absolute;
      top: 3px;
      left: 3px;
      width: 26px;
      height: 26px;
      border-radius: 999px;
      background: #fff;
      content: "";
      transition: transform 160ms ease-out;
    }

    .wvaie-floating-switch input:checked {
      background: #535dff;
    }

    .wvaie-floating-switch input:checked::before {
      transform: translateX(24px);
    }

    .wvaie-floating-refresh {
      justify-content: center;
      width: 44px;
      border-radius: 999px;
      cursor: pointer;
      padding: 0;
    }

    .wvaie-floating-refresh:hover {
      background: rgba(80, 80, 80, 0.72);
    }

    .wvaie-floating-refresh svg {
      width: 18px;
      height: 18px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.7;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .wvaie-toolbar-group {
      display: flex;
      align-items: center;
      gap: 7px;
    }

    .wvaie-toolbar-divider {
      width: 1px;
      height: 25px;
      background: rgba(255, 255, 255, 0.16);
    }

    .wvaie-toolbar-button,
    .wvaie-icon-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      width: 34px;
      height: 34px;
      min-height: 34px;
      border: 1px solid transparent;
      border-radius: 17px;
      background: transparent;
      color: #e8e8e8;
      cursor: pointer;
      font-size: 13px;
      padding: 8px;
      transition: background 160ms ease-out, color 160ms ease-out, opacity 160ms ease-out;
    }

    .wvaie-icon-button {
      min-width: 34px;
    }

    .wvaie-toolbar-button svg,
    .wvaie-icon-button svg {
      width: 18px;
      height: 18px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.65;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .wvaie-toolbar-button svg .wvaie-toolbar-icon-fill {
      fill: currentColor;
      stroke: none;
    }

    .wvaie-toolbar-button:hover:not(:disabled),
    .wvaie-icon-button:hover {
      border-radius: 17px;
      background: rgba(80, 80, 80, 0.38);
      color: #fff;
    }

    .wvaie-toolbar-button-active {
      border-radius: 100px;
      background: rgba(80, 80, 80, 0.6);
      color: #fff;
      box-shadow: none;
    }

    .wvaie-toolbar-button-active:hover:not(:disabled) {
      background: rgba(80, 80, 80, 0.72);
      color: #fff;
    }

    .wvaie-toolbar-button-record {
      width: auto;
      border-radius: 17px;
      background: rgba(80, 80, 80, 0.6);
      padding: 8px;
    }

    .wvaie-toolbar-label {
      color: #e8e8e8;
      font-family: var(--sans);
      font-size: 13px;
      font-weight: 400;
      line-height: 18px;
      white-space: nowrap;
    }

    .wvaie-toolbar-button:disabled {
      cursor: not-allowed;
      opacity: 0.42;
    }

    .wvaie-toolbar-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 18px;
      min-height: 17px;
      border-radius: 20px;
      padding: 0 4px;
      background: #535dff;
      color: #e8e8e8;
      font-size: 11px;
      line-height: 15px;
      font-variant-numeric: tabular-nums;
    }

    .wvaie-toolbar-button-active .wvaie-toolbar-badge {
      background: #535dff;
    }

    .wvaie-panel {
      position: fixed;
      top: max(90px, calc(env(safe-area-inset-top) + 74px));
      right: max(14px, env(safe-area-inset-right));
      z-index: 2147483645;
      display: flex;
      flex-direction: column;
      width: min(383px, calc(100vw - 28px));
      max-height: calc(100dvh - max(106px, calc(env(safe-area-inset-top) + 98px)));
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 16px;
      background: var(--bg-panel);
      background-color: rgba(24, 24, 24, 0.94);
      color: var(--text);
      box-shadow: 0 24px 70px rgba(0, 0, 0, 0.38), inset 0 1px 0 rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(8px);
      pointer-events: auto;
    }

    .wvaie-panel-utility {
      display: flex;
      flex: none;
      align-items: center;
      gap: 8px;
      min-height: 56px;
      padding: 12px 16px 0;
      color: #e8e8e8;
      cursor: grab;
      touch-action: none;
      user-select: none;
    }

    .wvaie-panel-utility-pill,
    .wvaie-panel-shared-pill,
    .wvaie-panel-refresh-circle {
      display: inline-flex;
      align-items: center;
      min-height: 42px;
      border: 1.5px solid rgba(255, 255, 255, 0.1);
      background: rgba(40, 40, 40, 0.9);
      color: #e8e8e8;
      box-shadow: 0 14px 32px rgba(0, 0, 0, 0.28);
      backdrop-filter: blur(8px);
    }

    .wvaie-panel-dragging .wvaie-panel-utility,
    .wvaie-panel-dragging .wvaie-header {
      cursor: grabbing;
    }

    .wvaie-panel-utility-group {
      display: flex;
      flex: none;
      align-items: center;
      gap: 8px;
    }

    .wvaie-panel-utility-pill {
      gap: 6px;
      border-radius: 999px;
      padding: 5px;
    }

    .wvaie-panel-mode-button {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 32px;
      min-width: 32px;
      border: 1px solid transparent;
      border-radius: 999px;
      background: transparent;
      color: #e8e8e8;
      cursor: pointer;
      padding: 7px;
      transition: background 160ms ease-out, border-color 160ms ease-out, color 160ms ease-out;
    }

    .wvaie-panel-mode-button:hover,
    .wvaie-panel-mode-button-active {
      background: rgba(80, 80, 80, 0.6);
      color: #fff;
    }

    .wvaie-panel-mode-button svg,
    .wvaie-panel-refresh-circle svg {
      width: 18px;
      height: 18px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.65;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .wvaie-panel-mode-button svg .wvaie-panel-icon-fill {
      fill: currentColor;
      stroke: none;
    }

    .wvaie-panel-record-toggle {
      gap: 5px;
      min-width: 59px;
      padding-right: 7px;
    }

    .wvaie-panel-record-label {
      color: #e8e8e8;
      font-size: 13px;
      line-height: 18px;
      white-space: nowrap;
    }

    .wvaie-panel-utility-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 18px;
      min-height: 17px;
      border-radius: 20px;
      padding: 0 4px;
      background: #535dff;
      color: #e8e8e8;
      font-size: 11px;
      line-height: 15px;
      font-variant-numeric: tabular-nums;
    }

    .wvaie-panel-shared-pill {
      display: inline-flex;
      flex: 1 1 auto;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      min-width: 0;
      border-radius: 999px;
      padding: 5px 5px 5px 13px;
      color: #e8e8e8;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      line-height: 18px;
      white-space: nowrap;
    }

    .wvaie-panel-shared-pill-disabled {
      cursor: not-allowed;
      opacity: 0.48;
    }

    .wvaie-panel-shared-label {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-panel-shared-pill input {
      position: relative;
      flex: none;
      width: 54px;
      height: 32px;
      margin: 0;
      border: 0;
      border-radius: 999px;
      appearance: none;
      background: rgba(80, 80, 80, 0.6);
      cursor: pointer;
      transition: background 160ms ease-out;
    }

    .wvaie-panel-shared-pill input::before {
      position: absolute;
      top: 3px;
      left: 3px;
      width: 26px;
      height: 26px;
      border-radius: 999px;
      background: #fff;
      content: "";
      transition: transform 160ms ease-out;
    }

    .wvaie-panel-shared-pill input:checked {
      background: #535dff;
    }

    .wvaie-panel-shared-pill input:checked::before {
      transform: translateX(22px);
    }

    .wvaie-panel-refresh-circle {
      justify-content: center;
      flex: none;
      width: 42px;
      padding: 0;
      border-radius: 999px;
      cursor: pointer;
    }

    .wvaie-panel-refresh-circle:hover {
      background: rgba(80, 80, 80, 0.72);
    }

    .wvaie-header {
      display: flex;
      flex: none;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      min-height: 62px;
      padding: 14px 22px 12px;
      border-bottom: 1px solid var(--border);
      background: transparent;
      cursor: grab;
      touch-action: none;
      user-select: none;
    }

    .wvaie-panel-dragging .wvaie-header {
      cursor: grabbing;
    }

    .wvaie-header-title {
      margin: 0;
      color: var(--text);
      font-size: 15px;
      font-weight: 600;
      line-height: 20px;
    }

    .wvaie-header-mode {
      margin: 0;
      color: var(--text-dim);
      font-size: 12px;
      line-height: 16px;
    }

    .wvaie-header-version {
      border: 1px solid rgba(91, 108, 255, 0.52);
      border-radius: 999px;
      padding: 4px 9px;
      background: rgba(91, 108, 255, 0.14);
      color: #dfe3ff;
      font-size: 12px;
      font-variant-numeric: tabular-nums;
    }

    .wvaie-panel-tabs {
      display: grid;
      flex: none;
      grid-template-columns: 1fr 1fr;
      height: 46px;
      border-bottom: 1px solid var(--border);
      background: transparent;
    }

    .wvaie-panel-tabs button {
      position: relative;
      border: 0;
      background: transparent;
      color: var(--text-muted);
      cursor: pointer;
      font-size: 14px;
      font-weight: 600;
    }

    .wvaie-panel-tabs button:hover {
      background: var(--bg-raised);
      color: var(--text);
    }

    .wvaie-panel-tabs .wvaie-tab-active {
      color: var(--text);
    }

    .wvaie-panel-tabs .wvaie-tab-active::after {
      position: absolute;
      right: 20px;
      bottom: 0;
      left: 20px;
      height: 2px;
      content: "";
      border-radius: 1px;
      background: var(--accent);
    }

    .wvaie-count {
      margin-left: 5px;
      color: var(--text-dim);
      font-variant-numeric: tabular-nums;
    }

    .wvaie-status-message {
      flex: none;
      margin: 0;
      margin: 16px 16px 0;
      padding: 9px 12px;
      border-radius: 10px;
      background: rgba(80, 80, 80, 0.32);
      color: var(--text-muted);
      font-size: 12px;
      line-height: 17px;
    }

    .wvaie-scroll {
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
      overscroll-behavior: contain;
      padding-bottom: 16px;
      scrollbar-color: rgba(255, 255, 255, 0.22) transparent;
    }

    .wvaie-scroll > .wvaie-inspector-section:first-child,
    .wvaie-record-list-view {
      margin-top: 24px;
    }

    .wvaie-inspector-section {
      display: grid;
      gap: 12px;
      margin: 24px 16px 0;
      padding: 0;
      border: 0;
      border-radius: 0;
      background: transparent;
      box-shadow: none;
    }

    .wvaie-inspector-section-hover {
      transition: background 160ms ease-out;
    }

    .wvaie-inspector-section-hover:hover {
      background: rgba(255, 255, 255, 0.025);
    }

    .wvaie-card-title {
      margin: 0;
      color: var(--text);
      font-size: 14px;
      font-weight: 600;
      line-height: 20px;
    }

    .wvaie-status-badge {
      display: inline-flex;
      align-items: center;
      min-height: 22px;
      border: 1px solid transparent;
      border-radius: 999px;
      padding: 2px 8px;
      font-size: 11px;
      line-height: 16px;
      white-space: nowrap;
    }

    .wvaie-status-badge-primary {
      background: var(--accent-fill);
      color: #fff;
    }

    .wvaie-status-badge-info {
      border-color: rgba(91, 108, 255, 0.34);
      background: var(--accent-soft);
      color: #dfe3ff;
    }

    .wvaie-status-badge-success {
      border-color: rgba(16, 185, 129, 0.28);
      background: rgba(16, 185, 129, 0.16);
      color: #79e0bd;
    }

    .wvaie-status-badge-warning {
      border-color: rgba(245, 158, 11, 0.3);
      background: rgba(245, 158, 11, 0.16);
      color: #ffd181;
    }

    .wvaie-status-badge-error {
      border-color: rgba(239, 68, 68, 0.3);
      background: rgba(239, 68, 68, 0.16);
      color: #ffb2b2;
    }

    button.wvaie-status-badge {
      cursor: pointer;
      font-family: var(--sans);
      transition: border-color 180ms ease-out, background 180ms ease-out;
    }

    button.wvaie-status-badge:hover {
      border-color: rgba(91, 108, 255, 0.58);
      background: rgba(91, 108, 255, 0.22);
    }

    .wvaie-empty-state {
      padding: 18px 0;
      text-align: center;
    }

    .wvaie-empty-state h2 {
      margin: 0;
      color: var(--text);
      font-size: 14px;
      font-weight: 500;
    }

    .wvaie-empty-state p,
    .wvaie-inline-empty {
      margin: 0;
      color: var(--text-muted);
      font-size: 12px;
      line-height: 18px;
    }

    .wvaie-inline-empty {
      padding: 16px;
    }

    .wvaie-section-heading {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }

    .wvaie-section-heading h2 {
      margin: 0;
      color: var(--text);
      font-size: 14px;
      font-weight: 600;
      line-height: 20px;
    }

    .wvaie-section-heading span {
      border-radius: 999px;
      padding: 2px 7px;
      background: var(--accent-soft);
      color: #dfe3ff;
      font-size: 11px;
      line-height: 16px;
    }

    .wvaie-layout-facts {
      display: grid;
      gap: 8px;
      margin: 0;
      padding: 12px;
      border-radius: 8px;
      background: var(--bg-field);
    }

    .wvaie-layout-facts div {
      display: grid;
      grid-template-columns: 64px minmax(0, 1fr);
      gap: 10px;
      align-items: baseline;
    }

    .wvaie-layout-facts dt,
    .wvaie-layout-facts dd {
      margin: 0;
      font-size: 12px;
      line-height: 18px;
    }

    .wvaie-layout-facts dt {
      color: var(--text-dim);
    }

    .wvaie-layout-facts dd {
      overflow-wrap: anywhere;
      color: var(--text-muted);
      font-family: var(--mono);
    }

    .wvaie-layout-direct-card {
      display: grid;
      gap: 4px;
      padding: 12px 13px;
      border: 1px solid rgba(91, 108, 255, 0.24);
      border-radius: 14px;
      background: var(--accent-soft);
    }

    .wvaie-layout-direct-card strong {
      color: var(--text);
      font-size: 13px;
      line-height: 18px;
    }

    .wvaie-layout-direct-card p {
      margin: 0;
      color: var(--text-muted);
      font-size: 12px;
      line-height: 18px;
    }

    .wvaie-layout-panel {
      gap: 14px;
    }

    .wvaie-layout-panel-empty {
      gap: 10px;
    }

    .wvaie-layout-direction-grid,
    .wvaie-layout-mode-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }

    .wvaie-layout-mode-button {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 9px;
      min-height: 48px;
      border: 1px solid transparent;
      border-radius: 8px;
      background: var(--bg-field);
      color: var(--text);
      cursor: pointer;
      font-size: 14px;
      font-weight: 600;
      line-height: 20px;
      transition: background 160ms ease-out, border-color 160ms ease-out, box-shadow 160ms ease-out;
    }

    .wvaie-layout-mode-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      color: var(--text-muted);
      flex: none;
    }

    .wvaie-layout-mode-icon svg,
    .wvaie-layout-spacing-icon svg,
    .wvaie-style-icon svg,
    .wvaie-style-font-trigger svg {
      width: 18px;
      height: 18px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.5;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .wvaie-layout-mode-icon rect,
    .wvaie-layout-spacing-icon rect {
      fill: currentColor;
      stroke: none;
    }

    .wvaie-layout-mode-button:hover {
      border-color: var(--border-strong);
      background: var(--bg-field-hover);
    }

    .wvaie-layout-mode-active {
      border-color: rgba(83, 93, 255, 0.72);
      background: rgba(83, 93, 255, 0.2);
      box-shadow: inset 0 0 0 1px rgba(83, 93, 255, 0.2);
    }

    .wvaie-layout-overview-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }

    .wvaie-layout-preview-card,
    .wvaie-layout-gap-card {
      display: flex;
      align-items: center;
      gap: 12px;
      min-height: 82px;
      border-radius: 8px;
      background: var(--bg-field);
      padding: 12px;
    }

    .wvaie-layout-preview-card {
      position: relative;
      display: grid;
      align-items: stretch;
      overflow: hidden;
    }

    .wvaie-layout-preview-bars {
      position: relative;
      display: grid;
      gap: 6px;
      align-content: center;
      justify-items: stretch;
      min-height: 58px;
      padding: 10px;
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.03);
    }

    .wvaie-layout-preview-bars::before {
      position: absolute;
      inset: 10px;
      content: "";
      background-image: radial-gradient(circle, rgba(232, 232, 232, 0.34) 1px, transparent 1.5px);
      background-position: 0 0;
      background-size: 72px 34px;
      opacity: 0.72;
    }

    .wvaie-layout-preview-bars span {
      position: relative;
      display: block;
      height: 8px;
      border-radius: 6px;
      background: rgba(83, 93, 255, 0.85);
    }

    .wvaie-layout-preview-bars-horizontal {
      grid-auto-flow: column;
      grid-auto-columns: 1fr;
      align-items: end;
    }

    .wvaie-layout-preview-bars-horizontal span {
      width: 8px;
      height: auto;
      min-height: 30px;
    }

    .wvaie-layout-preview-meta {
      display: none;
    }

    .wvaie-layout-preview-meta span,
    .wvaie-layout-gap-caption,
    .wvaie-layout-spacing-title {
      color: var(--text-dim);
      font-size: 12px;
      line-height: 16px;
    }

    .wvaie-layout-preview-meta strong,
    .wvaie-layout-gap-value {
      overflow: hidden;
      color: var(--text);
      font: 600 13px/18px var(--mono);
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-layout-gap-card .wvaie-style-input {
      flex: 1 1 auto;
      min-height: 40px;
      border: 0;
      background: transparent;
      padding: 0;
      font-size: 14px;
      font-weight: 600;
      font-variant-numeric: tabular-nums;
    }

    .wvaie-layout-gap-caption {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      flex: none;
    }

    .wvaie-layout-gap-caption svg {
      width: 18px;
      height: 18px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.5;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .wvaie-layout-spacing-block {
      display: grid;
      gap: 8px;
    }

    .wvaie-layout-advanced {
      display: grid;
      gap: 10px;
      padding-top: 2px;
    }

    .wvaie-layout-advanced summary {
      display: flex;
      align-items: center;
      gap: 6px;
      color: var(--text-dim);
      cursor: pointer;
      font-size: 12px;
      line-height: 18px;
      list-style: none;
    }

    .wvaie-layout-advanced summary::-webkit-details-marker {
      display: none;
    }

    .wvaie-layout-advanced summary::before {
      display: inline-block;
      width: 12px;
      color: var(--text-dim);
      content: "›";
      transition: transform 160ms ease-out;
    }

    .wvaie-layout-advanced[open] summary::before {
      transform: rotate(90deg);
    }

    .wvaie-layout-save-strip {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      min-height: 40px;
      border-radius: 8px;
      background: rgba(83, 93, 255, 0.14);
      color: var(--text);
      font-size: 12px;
      line-height: 18px;
      padding: 8px 10px 8px 12px;
    }

    .wvaie-layout-save-strip .wvaie-button {
      min-height: 30px;
      padding: 0 11px;
    }

    .wvaie-layout-spacing-grid,
    .wvaie-layout-meta-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }

    .wvaie-layout-spacing-cell,
    .wvaie-layout-context-cell {
      display: flex;
      align-items: center;
      gap: 10px;
      min-height: 40px;
      border-radius: 8px;
      background: var(--bg-field);
      padding: 10px 12px;
    }

    .wvaie-layout-spacing-meta {
      display: flex;
      align-items: center;
      gap: 10px;
      flex: 0 0 auto;
    }

    .wvaie-layout-spacing-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      border-radius: 0;
      background: transparent;
      color: var(--text-muted);
      font: 600 11px/1 var(--mono);
    }

    .wvaie-layout-spacing-label {
      display: none;
      color: var(--text);
      font-size: 13px;
      line-height: 18px;
    }

    .wvaie-layout-spacing-cell .wvaie-style-length {
      min-height: 40px;
      flex: 1 1 auto;
      background: transparent;
    }

    .wvaie-layout-context-cell strong {
      overflow: hidden;
      color: var(--text);
      font: 600 13px/18px var(--mono);
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-layout-context-cell span {
      color: var(--text-dim);
      font-size: 12px;
      line-height: 16px;
      white-space: nowrap;
    }

    .wvaie-element-summary {
      gap: 14px;
    }

    .wvaie-element-head {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 12px;
      padding: 0;
    }

    .wvaie-element-tag {
      color: var(--accent-secondary);
      font-size: 17px;
      font-weight: 600;
    }

    .wvaie-element-dimensions {
      color: var(--text);
      font: 600 14px/18px var(--mono);
      font-variant-numeric: tabular-nums;
    }

    .wvaie-element-path {
      overflow: hidden;
      margin: 0;
      padding: 0;
      color: var(--text-muted);
      font: 12px/18px var(--mono);
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-property-section h2,
    .wvaie-import-export h2,
    .wvaie-record-heading h2 {
      margin: 0;
      color: var(--text);
      font-size: 14px;
      font-weight: 700;
      line-height: 20px;
    }

    .wvaie-control-group summary,
    .wvaie-similar-panel summary {
      cursor: pointer;
      list-style: none;
      color: var(--text);
      font-size: 14px;
      font-weight: 700;
      line-height: 42px;
    }

    .wvaie-control-group summary::before,
    .wvaie-similar-panel summary::before {
      display: inline-block;
      width: 15px;
      content: "›";
      color: var(--text-dim);
    }

    details[open] > summary::before {
      transform: rotate(90deg);
    }

    .wvaie-style-editor,
    .wvaie-measurement-panel {
      gap: 12px;
    }

    .wvaie-similar-panel {
      padding: 0;
      color: var(--text-muted);
      font-size: 12px;
      min-width: 0;
    }

    .wvaie-similar-panel summary {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
    }

    .wvaie-similar-panel summary::before {
      flex: none;
    }

    .wvaie-similar-count {
      margin-left: auto;
      border-radius: 11px;
      padding: 3px 8px;
      background: var(--bg-field);
      color: var(--text-dim);
      font-size: 11px;
    }

    .wvaie-similar-content {
      display: grid;
      gap: 10px;
      min-width: 0;
      max-width: 100%;
      padding: 0 0 2px 15px;
    }

    .wvaie-similar-feature,
    .wvaie-similar-help {
      margin: 0;
      line-height: 18px;
      min-width: 0;
    }

    .wvaie-similar-feature code {
      display: block;
      max-width: 100%;
      margin-top: 6px;
      overflow: hidden;
      border-radius: 8px;
      padding: 7px 9px;
      background: var(--bg-field);
      color: var(--text);
      font: 11px/17px var(--mono);
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-similar-truncated {
      display: inline-block;
      margin-top: 6px;
      color: #bfdbfe;
    }

    .wvaie-shared-switch {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 10px 12px;
      border: 1px solid var(--border);
      border-radius: 14px;
      background: var(--bg-field);
      color: var(--text);
      cursor: pointer;
    }

    .wvaie-shared-switch span {
      display: grid;
      gap: 2px;
    }

    .wvaie-shared-switch strong {
      font-size: 13px;
      line-height: 18px;
    }

    .wvaie-shared-switch small {
      color: var(--text-dim);
      font-size: 11px;
      line-height: 16px;
    }

    .wvaie-shared-switch input {
      position: relative;
      flex: none;
      width: 42px;
      height: 24px;
      margin: 0;
      border: 0;
      border-radius: 999px;
      appearance: none;
      background: rgba(255, 255, 255, 0.18);
      cursor: pointer;
      transition: background 160ms ease-out;
    }

    .wvaie-shared-switch input::before {
      position: absolute;
      top: 3px;
      left: 3px;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: #fff;
      content: "";
      transition: transform 160ms ease-out;
    }

    .wvaie-shared-switch input:checked {
      background: var(--accent-fill);
    }

    .wvaie-shared-switch input:checked::before {
      transform: translateX(18px);
    }

    .wvaie-similar-list {
      display: grid;
      gap: 4px;
      min-width: 0;
      max-width: 100%;
      margin: 0;
      padding: 0;
      list-style: none;
    }

    .wvaie-similar-list li {
      min-width: 0;
      max-width: 100%;
    }

    .wvaie-similar-target {
      display: block;
      width: 100%;
      max-width: 100%;
      overflow: hidden;
      border: 1px solid transparent;
      border-radius: 8px;
      padding: 9px 12px;
      background: var(--bg-field);
      color: var(--text-muted);
      cursor: pointer;
      font: 11px/16px var(--mono);
      text-align: left;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-similar-target:hover,
    .wvaie-similar-target:focus-visible {
      border-color: var(--accent-secondary);
      color: var(--text);
    }

    .wvaie-style-section {
      display: grid;
      gap: 12px;
    }

    .wvaie-style-section-grid {
      display: grid;
      gap: 10px;
    }

    .wvaie-style-dual-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }

    .wvaie-style-dual-cell {
      display: grid;
      min-height: 40px;
      border-radius: 8px;
      background: var(--bg-field);
      padding: 10px 12px;
    }

    .wvaie-style-row-title {
      color: var(--text-dim);
      font-size: 12px;
      line-height: 16px;
    }

    .wvaie-style-compact-shell {
      display: flex;
      align-items: center;
      gap: 10px;
      min-width: 0;
    }

    .wvaie-style-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      border-radius: 0;
      background: transparent;
      color: var(--text-muted);
      font: 600 11px/1 var(--mono);
      flex: none;
    }

    .wvaie-style-inline-input,
    .wvaie-style-inline-select,
    .wvaie-style-inline-unit,
    .wvaie-style-inline-value {
      min-width: 0;
      border: 0;
      background: transparent;
      color: var(--text);
      font-size: 13px;
      line-height: 20px;
      padding: 0;
    }

    .wvaie-style-inline-select,
    .wvaie-style-inline-unit {
      appearance: none;
      cursor: pointer;
    }

    .wvaie-style-inline-input:focus,
    .wvaie-style-inline-select:focus,
    .wvaie-style-inline-unit:focus {
      outline: none;
    }

    .wvaie-style-inline-length {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
      flex: 1 1 auto;
    }

    .wvaie-style-inline-input {
      flex: 1 1 auto;
      width: 100%;
    }

    .wvaie-style-inline-unit,
    .wvaie-style-alpha-pill,
    .wvaie-style-font-trigger {
      flex: none;
      color: var(--text-muted);
      font-size: 12px;
    }

    .wvaie-style-font-compact {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
      flex: 1 1 auto;
    }

    .wvaie-style-font-compact .wvaie-style-inline-select {
      flex: 1 1 auto;
      min-width: 0;
    }

    .wvaie-style-font-trigger {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      border: 0;
      border-radius: 0;
      background: transparent;
      color: var(--text-muted);
      cursor: pointer;
    }

    .wvaie-style-color-row,
    .wvaie-style-corner-row,
    .wvaie-style-single-row,
    .wvaie-style-shadow-row {
      display: grid;
      gap: 8px;
    }

    .wvaie-style-color-strip {
      display: grid;
      grid-template-columns: 20px minmax(0, 1fr) auto;
      align-items: center;
      gap: 16px;
      min-height: 40px;
      border-radius: 8px;
      background: var(--bg-field);
      padding: 10px 12px;
    }

    .wvaie-style-color-swatch {
      width: 20px;
      height: 20px;
      border: 0;
      border-radius: 4px;
      padding: 0;
      background: transparent;
    }

    .wvaie-style-color-value {
      min-height: auto;
      border: 0;
      background: transparent;
      padding: 0;
    }

    .wvaie-style-shadow-textarea {
      min-height: 80px;
      resize: none;
    }

    .wvaie-style-inline-value {
      font: 600 14px/20px var(--mono);
      font-variant-numeric: tabular-nums;
    }

    .wvaie-advanced-info-grid {
      display: grid;
      gap: 8px;
    }

    .wvaie-advanced-info-cell {
      display: grid;
      gap: 8px;
    }

    .wvaie-advanced-info-text {
      margin: 0;
      min-height: 64px;
      border-radius: 8px;
      background: var(--bg-field);
      color: var(--text-muted);
      font: 12px/18px var(--mono);
      padding: 12px;
      overflow-wrap: anywhere;
    }

    .wvaie-style-input,
    .wvaie-style-select,
    .wvaie-select,
    .wvaie-filter-select,
    .wvaie-record-status-select,
    .wvaie-textarea {
      width: 100%;
      min-height: 40px;
      border: 1px solid transparent;
      border-radius: 8px;
      background: var(--bg-field);
      color: var(--text);
      font-size: 13px;
      padding: 8px 13px;
    }

    .wvaie-style-length {
      display: flex;
      align-items: stretch;
      min-height: 40px;
      overflow: hidden;
      border: 1px solid transparent;
      border-radius: 8px;
      background: var(--bg-field);
      transition: background 160ms ease-out, border-color 160ms ease-out, box-shadow 160ms ease-out;
    }

    .wvaie-style-length:hover {
      border-color: var(--border-strong);
      background: var(--bg-field-hover);
    }

    .wvaie-style-length:focus-within {
      border-color: rgba(91, 108, 255, 0.78);
      box-shadow: inset 0 0 0 1px rgba(91, 108, 255, 0.24);
    }

    .wvaie-style-length-input {
      flex: 1 1 auto;
      min-width: 0;
      border: 0;
      background: transparent;
      color: var(--text);
      font-size: 13px;
      line-height: 1;
      padding: 10px 12px 10px 13px;
    }

    .wvaie-style-length-input:focus {
      outline: none;
    }

    .wvaie-style-length-unit {
      flex: none;
      width: 66px;
      border: 0;
      border-left: 1px solid var(--border);
      background-color: rgba(255, 255, 255, 0.045);
      background-image:
        linear-gradient(45deg, transparent 50%, var(--text-dim) 50%),
        linear-gradient(135deg, var(--text-dim) 50%, transparent 50%);
      background-position:
        calc(100% - 13px) 52%,
        calc(100% - 9px) 52%;
      background-repeat: no-repeat;
      background-size: 4px 4px;
      color: var(--text);
      cursor: pointer;
      font-size: 12px;
      font-variant-numeric: tabular-nums;
      padding: 0 22px 0 10px;
      text-align: center;
      appearance: none;
    }

    .wvaie-style-length-unit:hover {
      background-color: rgba(255, 255, 255, 0.065);
    }

    .wvaie-style-length-unit:focus {
      outline: none;
    }

    .wvaie-style-input:hover,
    .wvaie-style-select:hover,
    .wvaie-select:hover,
    .wvaie-filter-select:hover,
    .wvaie-record-status-select:hover,
    .wvaie-textarea:hover {
      border-color: var(--border-strong);
      background: var(--bg-field-hover);
    }

    .wvaie-style-input:focus,
    .wvaie-style-select:focus,
    .wvaie-select:focus,
    .wvaie-filter-select:focus,
    .wvaie-record-status-select:focus,
    .wvaie-textarea:focus {
      border-color: rgba(91, 108, 255, 0.78);
      box-shadow: inset 0 0 0 1px rgba(91, 108, 255, 0.24);
      outline: none;
    }

    .wvaie-style-color {
      display: grid;
      grid-template-columns: 44px minmax(0, 1fr);
      gap: 10px;
    }

    .wvaie-style-color input[type="color"] {
      width: 44px;
      height: 40px;
      padding: 5px;
      border: 1px solid var(--border-strong);
      border-radius: 8px;
      background: var(--bg-field);
    }

    .wvaie-font-family-control {
      display: grid;
      gap: 8px;
    }

    .wvaie-font-family-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 8px;
    }

    .wvaie-font-family-row .wvaie-button {
      min-height: 40px;
      white-space: nowrap;
    }

    .wvaie-font-status {
      margin: 0;
      color: var(--text-dim);
      font-size: 11px;
      line-height: 16px;
    }

    .wvaie-preview-banner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 10px 13px;
      border-radius: 8px;
      background: var(--accent-soft);
      color: var(--text);
      font-size: 12px;
    }

    .wvaie-mode-banner {
      display: grid;
      gap: 3px;
      padding: 12px 13px;
      border: 1px solid var(--border);
      border-radius: 13px;
      background: var(--accent-soft);
      font-size: 12px;
    }

    .wvaie-mode-banner strong {
      font-size: 13px;
    }

    .wvaie-mode-banner span {
      color: var(--text-muted);
      line-height: 18px;
    }

    .wvaie-measurement-size {
      margin: 0;
      color: var(--text);
      font: 14px/20px var(--mono);
      font-variant-numeric: tabular-nums;
    }

    .wvaie-measurement-selector {
      overflow: hidden;
      margin: 0;
      color: var(--text-muted);
      font: 12px/18px var(--mono);
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-pair-results {
      border-radius: 14px;
      padding: 13px;
      background: var(--accent-soft);
    }

    .wvaie-measurement-actions {
      display: flex;
      gap: 8px;
      padding: 2px 0 0;
    }

    .wvaie-quick-comment {
      position: fixed;
      z-index: 2147483646;
      display: grid;
      width: 302px;
      gap: 24px;
      padding: 16px;
      border: 1.5px solid rgba(255, 255, 255, 0.1);
      border-radius: 16px;
      background: rgba(24, 24, 24, 0.9);
      color: var(--text);
      box-shadow: 0 24px 70px rgba(0, 0, 0, 0.38), inset 0 1px 0 rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(8px);
      pointer-events: auto;
    }

    .wvaie-quick-comment-title,
    .wvaie-quick-comment-current {
      margin: 0;
    }

    .wvaie-quick-comment-title {
      color: var(--text);
      font-size: 14px;
      font-weight: 600;
      line-height: 20px;
    }

    .wvaie-quick-comment-current {
      color: var(--text);
      font-size: 14px;
      font-weight: 600;
      line-height: 20px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-quick-comment-textarea {
      min-height: 220px;
      margin-top: -16px;
    }

    .wvaie-quick-comment-meta {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
      margin-top: -8px;
    }

    .wvaie-quick-comment-actions {
      display: flex;
      justify-content: flex-end;
      margin-top: -8px;
    }

    .wvaie-comment-editor {
      display: grid;
      gap: 12px;
    }

    .wvaie-page-comment-collapsed,
    .wvaie-page-comment-expanded {
      display: grid;
      gap: 10px;
      padding: 0;
    }

    .wvaie-page-comment-trigger {
      min-height: 88px;
      width: 100%;
      border: 0;
      border-radius: 8px;
      background: var(--bg-field);
      color: var(--text-dim);
      cursor: text;
      font-size: 13px;
      line-height: 20px;
      padding: 12px;
      text-align: left;
    }

    .wvaie-page-comment-trigger:hover {
      background: var(--bg-field-hover);
      color: var(--text-muted);
    }

    .wvaie-page-comment-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .wvaie-page-comment-header h2 {
      margin: 0;
      color: var(--text);
      font-size: 16px;
      font-weight: 700;
      line-height: 22px;
    }

    .wvaie-help-text {
      margin: 0;
      color: var(--text-muted);
      font-size: 13px;
      line-height: 22px;
    }

    .wvaie-page-comment-body,
    .wvaie-comment-editor-embedded {
      display: grid;
      gap: 12px;
    }

    .wvaie-comment-editor-embedded {
      padding-top: 4px;
    }

    .wvaie-textarea {
      min-height: 88px;
      resize: vertical;
      line-height: 20px;
    }

    .wvaie-comment-shell,
    .wvaie-comment-meta-panel {
      display: grid;
      gap: 12px;
    }

    .wvaie-form-row {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }

    .wvaie-form-field {
      display: grid;
      gap: 5px;
    }

    .wvaie-form-field label {
      color: var(--text-muted);
      font-size: 14px;
      line-height: 20px;
    }

    .wvaie-attach-measurement {
      display: flex;
      align-items: flex-start;
      gap: 7px;
      color: var(--text-muted);
      font-size: 12px;
      line-height: 18px;
    }

    .wvaie-attach-measurement input {
      margin-top: 2px;
      accent-color: var(--accent);
    }

    .wvaie-attach-measurement-hint {
      color: var(--text-dim);
    }

    .wvaie-option-checks {
      display: grid;
      gap: 7px;
    }

    .wvaie-comment-textarea {
      min-height: 88px;
    }

    .wvaie-comment-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      min-height: 33px;
    }

    .wvaie-comment-options {
      display: flex;
      align-items: center;
      gap: 12px;
      min-width: 0;
      flex-wrap: wrap;
    }

    .wvaie-edit-mode-banner {
      padding: 10px 12px;
      border-radius: 8px;
      background: var(--accent-soft);
      color: var(--text);
      font-size: 12px;
    }

    .wvaie-actions,
    .wvaie-footer {
      display: flex;
      flex: none;
      justify-content: flex-end;
      gap: 8px;
    }

    .wvaie-layout-footer {
      display: flex;
      justify-content: flex-end;
    }

    .wvaie-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 40px;
      border: 1px solid transparent;
      border-radius: 8px;
      background: var(--bg-field);
      color: var(--text);
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      padding: 0 14px;
      white-space: nowrap;
      transition: background 160ms ease-out, border-color 160ms ease-out, box-shadow 160ms ease-out;
    }

    .wvaie-button:hover:not(:disabled) {
      border-color: var(--border-strong);
      background: var(--bg-field-hover);
    }

    .wvaie-button-primary {
      border-color: transparent;
      background: var(--accent-fill);
      color: #fff;
      box-shadow: inset 0 0 0 1px rgba(91, 108, 255, 0.36);
    }

    .wvaie-button-primary:hover:not(:disabled) {
      border-color: transparent;
      background: var(--accent-fill-hover);
    }

    .wvaie-button-text {
      border-color: transparent;
      background: transparent;
      color: var(--text-muted);
    }

    .wvaie-button-danger {
      color: #ffb4a4;
    }

    .wvaie-button-danger:hover:not(:disabled) {
      border-color: var(--danger);
      background: rgba(239, 68, 68, 0.14);
    }

    .wvaie-button:disabled {
      cursor: not-allowed;
      opacity: 0.42;
    }

    .wvaie-record-list-view {
      display: grid;
      gap: 12px;
      padding: 0 16px 12px;
    }

    .wvaie-record-heading,
    .wvaie-record-filters {
      margin: 0;
    }

    .wvaie-record-heading {
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: var(--text-dim);
      font-size: 13px;
    }

    .wvaie-record-heading span {
      font-variant-numeric: tabular-nums;
    }

    .wvaie-record-filters {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 10px;
    }

    .wvaie-filter-group {
      display: grid;
      gap: 5px;
    }

    .wvaie-filter-label {
      color: var(--text-muted);
      font-size: 11px;
    }

    .wvaie-record-list {
      display: grid;
      gap: 10px;
    }

    .wvaie-record {
      display: grid;
      gap: 9px;
      padding: 12px;
      border-radius: 8px;
      background: var(--bg-raised);
    }

    .wvaie-record-topline {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }

    .wvaie-record-comment {
      margin: 0;
      color: var(--text);
      font-size: 13px;
      line-height: 19px;
    }

    .wvaie-record-selector {
      overflow: hidden;
      margin: 0;
      color: var(--text-muted);
      font: 11px/17px var(--mono);
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .wvaie-record-style-list {
      display: grid;
      gap: 4px;
      margin: 0;
      padding: 8px 0 0;
      border-top: 1px solid var(--border);
      list-style: none;
    }

    .wvaie-record-style-list li {
      display: grid;
      gap: 2px;
      color: var(--text-muted);
      font-size: 11px;
    }

    .wvaie-record-style-list code {
      color: var(--text);
      font: 11px/16px var(--mono);
    }

    .wvaie-record-warning {
      margin: 0;
      color: #ffb4a4;
      font-size: 11px;
    }

    .wvaie-record-control-row {
      display: flex;
      gap: 5px;
      margin-top: 2px;
      flex-wrap: wrap;
    }

    .wvaie-record-status-select {
      flex: 1;
      min-width: 106px;
    }

    .wvaie-import-export {
      display: grid;
      gap: 12px;
      margin-bottom: 12px;
    }

    .wvaie-import-export .wvaie-footer {
      justify-content: flex-start;
    }

    .wvaie-privacy-note {
      margin: 0;
      color: var(--text-muted);
      font-size: 11px;
      line-height: 17px;
    }

    .wvaie-dialog-backdrop {
      position: absolute;
      inset: 0;
      z-index: 20;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 18px;
      background: rgba(0, 0, 0, 0.56);
    }

    .wvaie-dialog {
      display: grid;
      gap: 12px;
      width: 100%;
      padding: 16px;
      border: 1px solid var(--border-strong);
      border-radius: 8px;
      background: rgba(24, 24, 24, 0.98);
      box-shadow: 0 18px 44px rgba(0, 0, 0, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }

    .wvaie-dialog-title,
    .wvaie-dialog-message {
      margin: 0;
    }

    .wvaie-dialog-title {
      font-size: 14px;
    }

    .wvaie-dialog-message {
      color: var(--text-muted);
      font-size: 12px;
      line-height: 18px;
    }

    .wvaie-dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
    }

    @media (prefers-reduced-motion: reduce) {
      .wvaie-toolbar-button,
      .wvaie-icon-button,
      .wvaie-button,
      .wvaie-inspector-section-hover,
      button.wvaie-status-badge {
        transition: none;
      }
    }
  `,n.append(i,r);const l=ud(r),o=Hm(r);let s={enabled:!0,panelView:"inspector",interactionMode:"select",selectedElement:null,selectedStyleSnapshot:[],selectedStyleSupported:!1,styleDraft:{},records:[],statusMessage:"选择模式：点击网页元素查看并编辑属性。",unmatchedRecordIds:new Set,editingRecord:null,filterCategory:"all",filterStatus:"all",filterRange:"all",measurement:null,measurementMode:"off",attachMeasurements:!0,similarMatchLevel:null,similarPrimaryFeature:"",similarTotalMatched:1,similarTruncated:!1,similarElements:[],applyToSimilar:!1,layoutContext:null,quickCommentTarget:null};function u(){l.render(a.jsx(Am,{handlers:e,state:s})),requestAnimationFrame(()=>o.clamp())}return u(),{update(d){s=d,u()},destroy(){o.destroy(),l.unmount(),t.remove()}}}const Um=["fontFamily","fontSize","fontWeight","lineHeight","letterSpacing"],Wm=new Set(Um);function ka(e){return Wm.has(e)}function Xi(e){return e.filter(t=>ka(t.property)).map(t=>({...t}))}const Gm=["visual","copy","interaction","layout","data","state"],Gs={high:0,medium:1,low:2};function Qm(e){const{records:t}=e,n=Ym(t),r=Xm(t);return`你是资深前端工程师和 UI 设计还原助手。

请根据以下网页改稿记录，对目标页面进行修改。你需要优先保持现有技术栈、组件结构、样式体系和交互逻辑，不要大范围重构。

页面信息：
- URL: ${e.page.url}
- Title: ${e.page.title}
- Viewport: ${e.page.viewport.width} x ${e.page.viewport.height}

${n}

修改要求：
${r||"当前没有修改记录。"}

输出要求：
1. 说明你修改了哪些文件。
2. 说明每条评论和样式修改对应的实现方式。
3. 如果 selector 无法直接匹配，请根据文本、位置和上下文寻找最接近元素。
4. 处理样式修改时，请优先结合现有样式系统（如设计 token、CSS 变量、Tailwind 等）实现，不要机械写 inline style。
5. 不要删除无关功能。
6. 标记为"暂缓 / 仅供参考"的记录请暂时不要执行，仅作为参考信息。
7. 优先处理"必改"（高优先级）记录，再处理"建议"（中优先级）和"备注"（低优先级）。
8. 修改后请运行必要的构建、类型检查或测试。`}function Ym(e){if(e.length===0)return"总览：当前没有修改记录。";const t=e.filter(i=>i.priority==="high").length,n=e.filter(i=>i.priority==="medium").length,r=e.filter(i=>i.priority==="low").length;return`总览：共 ${e.length} 条记录（必改 ${t} 条 / 建议 ${n} 条 / 备注 ${r} 条）`}function Xm(e){const t=[];for(const n of Gm){const r=e.filter(o=>o.category===n);if(r.length===0)continue;const l=[...r].sort((o,s)=>Gs[o.priority]-Gs[s.priority]).map((o,s)=>Km(o,s)).join(`

`);t.push(`## ${dd(n)}

${l}`)}return t.join(`

`)}function Km(e,t){var c;const{element:n}=e,r=e.status==="deferred"?"（暂缓 / 仅供参考）":"",i=pd(e.priority),l=Th(e.status),o=[`第 ${t+1} 项 [${i}优先级 / ${l}] ${r}`.trim()];n?o.push(`- 元素选择器：${n.selector}`,`- 元素类型：${n.tagName}`,`- 元素文本：${n.text||"空"}`,`- 元素位置：x=${n.rect.x}, y=${n.rect.y}, width=${n.rect.width}, height=${n.rect.height}`):o.push("- 作用域：页面级评论"),e.interactionState&&o.push(`- 交互态：${fd(e.interactionState)}`),o.push(`- 用户评论 / 修改意图：${e.comment||"空"}`),e.sharedGroup&&n&&o.push(...tg(n,e.sharedGroup));const s=(c=e.fontChanges)!=null&&c.length?e.fontChanges:Xi(e.styleChanges),u=e.styleChanges.filter(d=>!ka(d.property));if(s.length>0){o.push("- 字体修改：");for(const d of s)o.push(`  - ${rg(d)}`)}if(u.length>0){o.push("- 样式修改：");for(const d of u)o.push(`  - ${ng(d)}`)}return e.measurements&&o.push(...qm(e.measurements)),(e.layoutContext||e.layoutIntent)&&o.push(...Zm(e.layoutContext??null,e.layoutIntent??null)),o.push(""),o.push(n?"请找到对应元素或最接近的组件实现，并按评论意图与样式差异修改。":"请根据页面整体情况实现此建议。"),(e.styleChanges.length>0||s.length>0)&&o.push("注意：处理样式时请优先结合现有样式系统实现。"),o.join(`
`)}function Zm(e,t){const n=["- 布局辅助："];return e&&n.push(`  - 父容器：${e.parentSelector}（${e.parentTagName}，display: ${e.display}）`,`  - 当前布局：direction ${e.flexDirection||"未指定"} / justify ${e.justifyContent||"未指定"} / align ${e.alignItems||"未指定"}`,`  - 当前间距：row ${e.gap.row} / column ${e.gap.column}`,`  - 当前子元素位置：第 ${e.childIndex+1} 个 / 共 ${e.siblingCount} 个`),t&&n.push(`  - 目标方向：${Jm(t.direction)}`,`  - 目标对齐：${eg(t.alignment)}`,`  - 目标间距：${t.gap||"未指定"}`,`  - 补充说明：${t.note||"无"}`),n}function qm(e){const t=["- 测距："];return t.push(`  - 当前尺寸：${e.size.width}×${e.size.height}`),t.push(`  - 距视口：上 ${e.viewport.top} / 右 ${e.viewport.right} / 下 ${e.viewport.bottom} / 左 ${e.viewport.left}`),e.parent&&t.push(`  - 距父容器（${e.parent.selector}）：上 ${e.parent.distances.top} / 右 ${e.parent.distances.right} / 下 ${e.parent.distances.bottom} / 左 ${e.parent.distances.left}`),e.pair&&t.push(`  - 与目标元素（${e.pair.selector}）：水平 ${e.pair.horizontalDistance}、垂直 ${e.pair.verticalDistance}、中心 ${e.pair.centerDistance}`),t}function Jm(e){return e==="horizontal"?"横向":e==="vertical"?"纵向":"未指定"}function eg(e){return e==="start"?"起点对齐":e==="center"?"居中对齐":e==="end"?"终点对齐":e==="space-between"?"两端等距":"未指定"}function tg(e,t){const n={exact:"精确匹配（tag + 完整 class）","class-primary":"主类匹配（同 tag + 同主类）","tag-only":"结构匹配（同父容器同 tag）"},r=[e,...t.targets],i=[`- 作用范围：以下修改请应用到 ${t.totalMatched} 个相似元素（匹配级别：${n[t.matchLevel]}）：`];for(const l of r.slice(0,10))i.push(`  - ${l.selector}`);return r.length>10&&i.push("  - ..."),t.truncated&&i.push("  - 注意：识别结果已截断到 50 个，可能漏掉部分元素。"),i}function ng(e){return`${e.property}: ${e.oldValue||"空"} -> ${e.newValue||"空"}`}function rg(e){return`${e.label}（${e.property}）: ${e.oldValue||"空"} -> ${e.newValue||"空"}`}function Ca(e){if(e.id)return`#${og(e.id)}`;const t=ig(e);return t||lg(e)}function ig(e){const t=["data-testid","data-cy","aria-label"];for(const n of t){const r=e.getAttribute(n);if(r)return`${e.tagName.toLowerCase()}[${n}="${ag(r)}"]`}return null}function lg(e){const t=[];let n=e;for(;n&&n!==document.documentElement;){const r=n.tagName.toLowerCase(),i=n.parentElement;if(!i){t.unshift(r);break}const l=Array.from(i.children).indexOf(n)+1;t.unshift(`${r}:nth-child(${l})`),n=i}return t.join(" > ")}function og(e){var t;return(t=globalThis.CSS)!=null&&t.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"')}function ag(e){return e.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}const sg=240;function Ki(e){const t=e.getBoundingClientRect(),n=(e.textContent??"").trim().replace(/\s+/g," ");return{tagName:e.tagName.toLowerCase(),id:e.id||null,className:ug(e),selector:Ca(e),text:n.slice(0,sg),rect:{x:Math.round(t.x),y:Math.round(t.y),width:Math.round(t.width),height:Math.round(t.height)}}}function ug(e){return typeof e.className=="string"&&e.className||null}function cg(){const e=new WeakMap,t=new Set;function n(r,i){let l=e.get(r);l||(l=new Map,e.set(r,l)),l.has(i)||l.set(i,r.style[i])}return{apply(r,i,l){if(!(r instanceof HTMLElement))return{ok:!1,reason:"该元素暂不支持样式预览"};n(r,i);try{r.style[i]=l}catch{return{ok:!1,reason:"样式值无法应用"}}return t.add(r),{ok:!0}},reset(r){if(!(r instanceof HTMLElement))return;const i=e.get(r);if(i){for(const[l,o]of i)r.style[l]=o??"";e.delete(r),t.delete(r)}},resetAll(){for(const r of t){const i=e.get(r);if(i){for(const[l,o]of i)r.style[l]=o??"";e.delete(r)}}t.clear()}}}function dg(e,t=n=>document.querySelector(n)){const n=new Map;let r=0;for(const i of e){if(!i.element||!i.comment.trim())continue;r+=1;const l=n.get(i.element.selector);if(l){l.count=r;continue}const o=t(i.element.selector);o&&n.set(i.element.selector,{count:r,element:o})}return Array.from(n.entries()).map(([i,l])=>({id:i,count:l.count,rect:pg(l.element)}))}function pg(e){const t=e.getBoundingClientRect();return{x:t.x,y:t.y,width:t.width,height:t.height}}function fg(e){return{width:Math.round(e.width),height:Math.round(e.height)}}function hg(e,t){return{top:Math.round(e.y),right:Math.round(t.width-(e.x+e.width)),bottom:Math.round(t.height-(e.y+e.height)),left:Math.round(e.x)}}function mg(e,t){return t.width<=0||t.height<=0?null:{top:Math.round(e.y-t.y),right:Math.round(t.x+t.width-(e.x+e.width)),bottom:Math.round(t.y+t.height-(e.y+e.height)),left:Math.round(e.x-t.x)}}function gg(e,t){const n=e.x+e.width,r=e.y+e.height,i=t.x+t.width,l=t.y+t.height;let o=0;n<=t.x?o=t.x-n:i<=e.x&&(o=e.x-i);let s=0;r<=t.y?s=t.y-r:l<=e.y&&(s=e.y-l);const u={x:e.x+e.width/2,y:e.y+e.height/2},c={x:t.x+t.width/2,y:t.y+t.height/2},d=c.x-u.x,f=c.y-u.y,m=Math.sqrt(d*d+f*f);return{horizontalDistance:Math.round(o),verticalDistance:Math.round(s),centerDistance:Math.round(m)}}const vg=50,yg=["web-visual-ai-editor-"];function xg(e,t=document.body,n={}){const r=n.limit??vg,i=e.tagName.toLowerCase(),l=Nl(e),o=Array.from(t.querySelectorAll(i)).filter(u=>!kg(u));if(l.length>0){const u=o.filter(c=>wg(Nl(c),l));if(u.length>=2){const c=Ml(u,e,r),d=l.length>0?`.${l.join(".")}`:"";return{matchLevel:"exact",primaryFeature:`${i}${d}`,totalMatched:c.totalMatched,truncated:c.truncated,similar:c.similar}}}if(l.length>0){const u=Sg(l),c=o.filter(d=>Nl(d).includes(u));if(c.length>=2){const d=Ml(c,e,r);return{matchLevel:"class-primary",primaryFeature:`${i}.${u}`,totalMatched:d.totalMatched,truncated:d.truncated,similar:d.similar}}}const s=e.parentElement;if(s){const u=o.filter(c=>c.parentElement===s);if(u.length>=2){const c=Ml(u,e,r);return{matchLevel:"tag-only",primaryFeature:i,totalMatched:c.totalMatched,truncated:c.truncated,similar:c.similar}}}return{matchLevel:"tag-only",primaryFeature:i,totalMatched:1,truncated:!1,similar:[]}}function Ml(e,t,n){const r=e.filter(u=>u!==t),i=r.length+1,l=i>n,o=l?n:i,s=o-1;return{totalMatched:o,truncated:l,similar:r.slice(0,s)}}function Nl(e){return Array.from(e.classList)}function wg(e,t){if(e.length!==t.length)return!1;const n=new Set(e);for(const r of t)if(!n.has(r))return!1;return!0}function Sg(e){return[...e].sort((t,n)=>n.length!==t.length?n.length-t.length:t.localeCompare(n))[0]}function kg(e){let t=e;for(;t;){if(t.id&&yg.some(n=>t.id.startsWith(n)))return!0;t=t.parentElement}return!1}const Cg=["flex","inline-flex","grid","inline-grid","block","inline"];function Eg(e){const t=e.parentElement;if(!t)return null;const n=window.getComputedStyle(t),r=jg(n.display),i=Array.from(t.children).filter(o=>o instanceof HTMLElement),l=Math.max(0,i.indexOf(e));return{parentSelector:Ca(t),parentTagName:t.tagName.toLowerCase(),display:r,flexDirection:r==="flex"||r==="inline-flex"?n.flexDirection:null,justifyContent:r==="flex"||r==="inline-flex"||r==="grid"||r==="inline-grid"?n.justifyContent:null,alignItems:r==="flex"||r==="inline-flex"||r==="grid"||r==="inline-grid"?n.alignItems:null,gap:{row:n.rowGap,column:n.columnGap},childIndex:l,siblingCount:i.length}}function jg(e){return Cg.includes(e)?e:"other"}const bg="0.8",Cd="Web Visual AI Editor",Mg=["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8"];function Ng(e={}){const t=Jt(e);return{version:"0.8",sessionId:Ea(e),page:Ig(),createdAt:t,updatedAt:t,records:[]}}function Cr(e,t,n,r=[],i=Ce,l=null,o=null,s={}){const u=n.trim(),c=i.scope==="page",d=c?[]:r,f=c?[]:Xi(d);if(!u&&d.length===0)return e;const m=Jt(s);return{...e,updatedAt:m,records:[...e.records,{id:Ea(s),element:c?null:t,comment:u,category:i.category,priority:i.priority,status:i.status,interactionState:c?null:i.interactionState,scope:i.scope,createdAt:m,updatedAt:m,styleChanges:d,fontChanges:f,measurements:c?null:l,sharedGroup:c?null:o,layoutContext:c?null:s.layoutContext??null,layoutIntent:c?null:s.layoutIntent??null}]}}function Lg(e,t,n,r,i=null,l=null,o={}){const s=e.records.findIndex(f=>f.id===t);if(s===-1)return e;const u=Jt(o),c=r.scope==="page",d=[...e.records];return d[s]={...d[s],element:c?null:d[s].element,comment:n.trim(),category:r.category,priority:r.priority,status:r.status,interactionState:c?null:r.interactionState,scope:r.scope,styleChanges:c?[]:d[s].styleChanges,fontChanges:c?[]:d[s].fontChanges??Xi(d[s].styleChanges),measurements:c?null:i,sharedGroup:c?null:l,layoutContext:c?null:o.layoutContext??d[s].layoutContext??null,layoutIntent:c?null:o.layoutIntent??d[s].layoutIntent??null,updatedAt:u},{...e,updatedAt:u,records:d}}function Tg(e,t,n={}){if(e.records.findIndex(l=>l.id===t)===-1)return e;const i=Jt(n);return{...e,updatedAt:i,records:e.records.filter(l=>l.id!==t)}}function _g(e,t,n,r={}){const i=e.records.findIndex(s=>s.id===t);if(i===-1)return e;const l=Jt(r),o=[...e.records];return o[i]={...o[i],status:n,updatedAt:l},{...e,updatedAt:l,records:o}}function Rg(e,t={}){const n={app:Cd,version:bg,exportedAt:Jt(t),page:e.page,records:e.records};return JSON.stringify(n,null,2)}function Pg(e,t={}){let n;try{n=JSON.parse(e)}catch{return{ok:!1,reason:"JSON 格式不正确"}}if(!we(n))return{ok:!1,reason:"JSON 格式不正确"};if(n.app!==Cd)return{ok:!1,reason:"不是 Web Visual AI Editor 导出的数据"};if(typeof n.version!="string"||!$g(n.version))return{ok:!1,reason:"当前版本暂不支持该数据版本"};if(!Array.isArray(n.records))return{ok:!1,reason:"未找到可导入的修改记录"};if(!Dg(n.page)||!n.records.every(Og))return{ok:!1,reason:"导入数据缺少必要字段"};const r=n.version,i=n.records.map(o=>zg(o,r)),l=Jt(t);return{ok:!0,session:{version:"0.8",sessionId:Ea(t),page:n.page,createdAt:l,updatedAt:l,records:i}}}function zg(e,t){const n=e.scope==="page"?"page":"element",r=n==="page",i=r?null:e.element,l=Array.isArray(e.styleChanges)?e.styleChanges:[],o=r?[]:l.filter(Ed).map(h=>({...h})),s=Array.isArray(e.fontChanges)?e.fontChanges:[],u=r?[]:t==="0.7"||t==="0.8"?s.filter(Fg).map(h=>({...h})):Xi(o),c=e.category==="visual"||e.category==="copy"||e.category==="interaction"||e.category==="layout"||e.category==="data"||e.category==="state"?e.category:Ce.category,d=e.priority==="low"||e.priority==="medium"||e.priority==="high"?e.priority:Ce.priority,f=!r&&(e.interactionState==="default"||e.interactionState==="hover"||e.interactionState==="focus"||e.interactionState==="active"||e.interactionState==="disabled"||e.interactionState==="loading"||e.interactionState==="empty"||e.interactionState==="error")?e.interactionState:null;let m="open";e.status==="resolved"?m="resolved":e.status==="deferred"&&(m="deferred");const x=n==="element"&&Ag(e.measurements)?e.measurements:null,v=n==="element"&&i&&(t==="0.5"||t==="0.6"||t==="0.7"||t==="0.8")&&Vg(e.sharedGroup)?e.sharedGroup:null,w=n==="element"&&(t==="0.6"||t==="0.7"||t==="0.8")&&Hg(e.layoutContext)?e.layoutContext:null,_=n==="element"&&(t==="0.6"||t==="0.7"||t==="0.8")&&Bg(e.layoutIntent)?e.layoutIntent:null;return{id:String(e.id),element:i,comment:typeof e.comment=="string"?e.comment:"",category:c,priority:d,status:m,interactionState:f,scope:n,createdAt:typeof e.createdAt=="string"?e.createdAt:new Date().toISOString(),updatedAt:typeof e.updatedAt=="string"?e.updatedAt:new Date().toISOString(),styleChanges:o,fontChanges:u,measurements:x,sharedGroup:v,layoutContext:w,layoutIntent:_}}function Ig(){return{url:window.location.href,origin:window.location.origin,title:document.title,viewport:{width:window.innerWidth,height:window.innerHeight}}}function Jt(e){var t;return((t=e.now)==null?void 0:t.call(e))??new Date().toISOString()}function Ea(e){var t;return((t=e.idFactory)==null?void 0:t.call(e))??crypto.randomUUID()}function we(e){return typeof e=="object"&&e!==null}function $g(e){return Mg.includes(e)}function Dg(e){return we(e)&&typeof e.url=="string"&&typeof e.origin=="string"&&typeof e.title=="string"&&we(e.viewport)&&typeof e.viewport.width=="number"&&typeof e.viewport.height=="number"}function Og(e){return!we(e)||typeof e.id!="string"||typeof e.comment!="string"?!1:e.scope==="page"?!0:jd(e.element)}function Ed(e){return we(e)&&typeof e.property=="string"&&typeof e.label=="string"&&typeof e.oldValue=="string"&&typeof e.newValue=="string"&&(e.unit===void 0||gd(e.unit))}function Fg(e){return Ed(e)&&ka(e.property)}function Ag(e){return!(!we(e)||!we(e.size)||typeof e.size.width!="number"||typeof e.size.height!="number"||!we(e.viewport))}function Vg(e){return we(e)&&(e.matchLevel==="exact"||e.matchLevel==="class-primary"||e.matchLevel==="tag-only")&&typeof e.primaryFeature=="string"&&typeof e.totalMatched=="number"&&typeof e.truncated=="boolean"&&Array.isArray(e.targets)&&e.targets.every(jd)}function Hg(e){return we(e)&&typeof e.parentSelector=="string"&&typeof e.parentTagName=="string"&&(e.display==="flex"||e.display==="inline-flex"||e.display==="grid"||e.display==="inline-grid"||e.display==="block"||e.display==="inline"||e.display==="other")&&(typeof e.flexDirection=="string"||e.flexDirection===null)&&(typeof e.justifyContent=="string"||e.justifyContent===null)&&(typeof e.alignItems=="string"||e.alignItems===null)&&we(e.gap)&&typeof e.gap.row=="string"&&typeof e.gap.column=="string"&&typeof e.childIndex=="number"&&typeof e.siblingCount=="number"}function Bg(e){return we(e)&&(e.direction==="none"||e.direction==="horizontal"||e.direction==="vertical")&&(e.alignment==="none"||e.alignment==="start"||e.alignment==="center"||e.alignment==="end"||e.alignment==="space-between")&&typeof e.gap=="string"&&typeof e.note=="string"}function jd(e){return we(e)&&typeof e.selector=="string"&&typeof e.tagName=="string"&&typeof e.text=="string"&&we(e.rect)&&typeof e.rect.x=="number"&&typeof e.rect.y=="number"&&typeof e.rect.width=="number"&&typeof e.rect.height=="number"}function Pt(){return window.__webVisualAiEditorRuntime||(window.__webVisualAiEditorRuntime={enabled:!1,panelView:"inspector",interactionMode:"select",listenerReady:!1,overlay:null,panel:null,hoveredElement:null,selectedElement:null,selectedSnapshot:null,selectedStyleSnapshot:[],selectedStyleSupported:!1,styleDraft:{},stylePreviewManager:cg(),session:Ng(),statusMessage:"请选择页面元素并添加评论。",unmatchedRecordIds:new Set,editingRecord:null,filterCategory:"all",filterStatus:"all",filterRange:"all",measurementMode:"off",pairFirstElement:null,pairSecondElement:null,currentMeasurements:null,currentLayoutContext:null,quickCommentTarget:null,attachMeasurements:!0,similarMatchLevel:null,similarPrimaryFeature:"",similarTotalMatched:1,similarTruncated:!1,similarElements:[],similarSnapshots:[],applyToSimilar:!1,layoutDrag:null,layoutGuide:null,layoutMoves:[],rafId:null}),window.__webVisualAiEditorRuntime}function Ug(e){e.enabled||(e.overlay=Ud({onLayoutDragStart(t){mv(e,t)}}),e.panel=Bm({onSaveComment(t,n){e.editingRecord?Xs(e,e.editingRecord.id,t,n):Xg(e,t,n)},onSaveQuickComment(t,n){Zg(e,t,n)},onCancelQuickComment(){Td(e)},onSavePageComment(t,n){var r;if(((r=e.editingRecord)==null?void 0:r.scope)==="page"){Xs(e,e.editingRecord.id,t,n);return}e.session=Cr(e.session,null,t,[],n,null,null),e.statusMessage="页面评论已保存。",N(e)},onSaveLayoutIntent(t){Jg(e,t)},onLocateRecord(t){ev(e,t)},onEditRecord(t){tv(e,t)},onDeleteRecord(t){nv(e,t.id)},onStatusChange(t,n){rv(e,t,n)},onCancelEdit(){_d(e)},onFilterCategoryChange(t){e.filterCategory=t,N(e)},onFilterStatusChange(t){e.filterStatus=t,N(e)},onFilterRangeChange(t){e.filterRange=t,N(e)},onHoverSimilar(t){uv(e,t)},onHighlightAllSimilar(){cv(e)},onHighlightSharedGroup(t){dv(e,t)},onExportJson(){iv(e)},onImportJson(t){lv(e,t)},onCopyPrompt(){ov(e)},onStyleDraftChange(t,n){Pv(e,t,n)},onResetStylePreview(){zv(e)},onEnterMeasurementMode(){pv(e)},onAutoLayoutMode(){Id(e)},onCommentMode(){hv(e)},onExitMeasurementMode(){Rd(e)},onResetPairMeasurement(){fv(e)},onToggleAttachMeasurements(t){e.attachMeasurements=t,N(e)},onToggleApplyToSimilar(t){e.applyToSimilar=t,N(e)},onBrowseMode(){Pd(e)},onSelectMode(){zd(e)},onShowInspector(){e.panelView="inspector",N(e)},onShowRecords(){Rv(e)},onClose(){bd(e)}}),e.enabled=!0,Gg(),N(e))}function bd(e){var t,n;e.enabled&&(e.stylePreviewManager.resetAll(),vv(e),Ue(e),(t=e.overlay)==null||t.destroy(),(n=e.panel)==null||n.destroy(),e.overlay=null,e.panel=null,e.enabled=!1,e.panelView="inspector",e.interactionMode="select",e.hoveredElement=null,e.selectedElement=null,e.selectedSnapshot=null,e.selectedStyleSnapshot=[],e.selectedStyleSupported=!1,e.styleDraft={},e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,e.currentMeasurements=null,e.currentLayoutContext=null,e.quickCommentTarget=null,e.editingRecord=null,e.layoutGuide=null,Zi(e),Qg())}function Wg(){const e=Pt();return e.enabled?bd(e):Ug(e),e.enabled}const Qs=Pt();Qs.listenerReady||(chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type!=="WVAIE_TOGGLE_EDITOR")return!1;const r=Wg();return n({ok:!0,enabled:r}),!1}),Qs.listenerReady=!0);function Gg(){document.addEventListener("mousemove",Md,!0),document.addEventListener("click",Nd,!0),document.addEventListener("keydown",Ld,!0),window.addEventListener("scroll",_i,!0),window.addEventListener("resize",_i,!0)}function Qg(){document.removeEventListener("mousemove",Md,!0),document.removeEventListener("click",Nd,!0),document.removeEventListener("keydown",Ld,!0),window.removeEventListener("scroll",_i,!0),window.removeEventListener("resize",_i,!0)}function Md(e){const t=Pt();if(!t.enabled||t.layoutDrag||t.interactionMode==="browse"||Bd(e))return;const n=Hd(e);n&&(t.hoveredElement=n,ba(t))}function Nd(e){const t=Pt();if(!t.enabled||Bd(e)||t.interactionMode==="browse")return;const n=Hd(e);if(!(!n||!(n instanceof HTMLElement))){if(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),t.editingRecord){t.statusMessage="正在编辑记录，先取消编辑再选元素。",N(t);return}if(t.interactionMode==="comment"){Kg(t,n);return}if(t.interactionMode==="measure"){Yg(t,n);return}en(t,n,"已选中元素，可以添加评论或编辑样式。")}}function Ld(e){if(e.key!=="Escape")return;const t=Pt();if(t.enabled){if(t.editingRecord){_d(t);return}if(t.quickCommentTarget){Td(t);return}if(t.interactionMode==="measure"){Rd(t);return}if(t.interactionMode==="auto-layout"){zd(t);return}Pd(t)}}function Yg(e,t){if(e.measurementMode==="awaiting-a"){Yr(e,t,"已选择元素 A，请点击元素 B。");return}if(e.measurementMode==="awaiting-b"){if(!e.pairFirstElement){Yr(e,t,"已选择元素 A，请点击元素 B。");return}if(t===e.pairFirstElement){Ys(e,"已取消元素 A，请重新点击页面元素选择 A。");return}e.pairSecondElement=t,e.measurementMode="complete",en(e,e.pairFirstElement,"双元素测距完成，元素 A 保持为记录对象；点击 A 可取消并重新测距。");return}if(e.measurementMode==="complete"){if(t===e.pairFirstElement){Ys(e,"已取消本次测距，请重新点击页面元素选择 A。");return}Yr(e,t,"已重新选择元素 A，请点击元素 B。");return}Yr(e,t,"已选择元素 A，请点击元素 B。")}function Yr(e,t,n){e.pairFirstElement=t,e.pairSecondElement=null,e.measurementMode="awaiting-b",en(e,t,n)}function Ys(e,t){e.pairFirstElement=null,e.pairSecondElement=null,e.measurementMode="awaiting-a",av(e,t)}function _i(){const e=Pt();e.enabled&&(We(e),Er(e),qg(e),e.layoutGuide=null,ba(e))}function Xg(e,t,n){var s;if(!e.selectedSnapshot){e.statusMessage="请先选择页面元素。",N(e);return}const r=Iv(e);if(!t.trim()&&r.length===0){e.statusMessage="请填写评论或修改样式后再保存。",N(e);return}const l=e.attachMeasurements||((s=e.currentMeasurements)==null?void 0:s.pair)!==null&&e.currentMeasurements!==null?e.currentMeasurements:null,o=jr(e);e.session=Cr(e.session,e.selectedSnapshot,t,r,n,l,o),e.statusMessage="记录已保存。",e.applyToSimilar=!1,e.measurementMode==="complete"&&(e.measurementMode="off",e.interactionMode="select",e.pairFirstElement=null,e.pairSecondElement=null,We(e)),N(e)}function Kg(e,t){if(en(e,t,"评论模式：已选中元素，请填写评论。"),!e.selectedSnapshot){e.statusMessage="该元素暂不支持添加评论。",N(e);return}e.quickCommentTarget={element:e.selectedSnapshot,rect:Ze(t)},e.statusMessage="评论弹窗已打开，保存后会加入记录列表。",N(e)}function Zg(e,t,n){const r=e.quickCommentTarget,i=t.trim();if(!r||!e.selectedSnapshot){e.statusMessage="请先在评论模式下点击页面元素。",N(e);return}if(!i){e.statusMessage="请填写评论后再保存。",N(e);return}e.session=Cr(e.session,e.selectedSnapshot,i,[],{...n,scope:"element"},null,jr(e)),e.quickCommentTarget=null,e.applyToSimilar=!1,e.statusMessage="评论已保存，可继续点击页面元素添加下一条。",N(e)}function Td(e){e.quickCommentTarget=null,e.statusMessage=e.interactionMode==="comment"?"已取消当前评论，仍可继续点击元素添加评论。":"已取消当前评论。",N(e)}function qg(e){!e.quickCommentTarget||!e.selectedElement||!e.selectedSnapshot||(e.quickCommentTarget={element:e.selectedSnapshot,rect:Ze(e.selectedElement)})}function Jg(e,t){if(!e.selectedSnapshot||!e.currentLayoutContext){e.statusMessage="请先选择可识别父容器布局的元素。",N(e);return}const n={category:"layout",priority:"medium",status:"open",interactionState:null,scope:"element"};e.session=Cr(e.session,e.selectedSnapshot,$v(t),[],n,null,jr(e),{layoutContext:e.currentLayoutContext,layoutIntent:t}),e.statusMessage="布局意图已保存。",e.applyToSimilar=!1,N(e)}function ev(e,t){var r;if(!t.element){e.statusMessage="这是页面级评论。",N(e);return}const n=document.querySelector(t.element.selector);if(!n){e.unmatchedRecordIds.add(t.id),e.statusMessage="当前页面未匹配到该元素。",N(e);return}e.unmatchedRecordIds.delete(t.id),n.scrollIntoView({block:"center",inline:"center",behavior:"smooth"}),en(e,n,"已定位到记录对应元素。"),(r=e.overlay)==null||r.flash(Ze(n))}function tv(e,t){if(t.element){const n=document.querySelector(t.element.selector);n instanceof HTMLElement&&en(e,n,"已定位到待编辑记录的元素。")}e.panelView="inspector",e.interactionMode="select",e.editingRecord=t,e.applyToSimilar=t.sharedGroup!==null,e.statusMessage="编辑模式：修改完成后点击保存。",N(e)}function _d(e){e.editingRecord=null,e.applyToSimilar=!1,e.statusMessage="已取消编辑。",N(e)}function Xs(e,t,n,r){const l=r.scope==="element"&&e.attachMeasurements&&e.currentMeasurements!==null?e.currentMeasurements:null,o=r.scope==="element"?jr(e):null;e.session=Lg(e.session,t,n,r,l,o),e.editingRecord=null,e.applyToSimilar=!1,e.statusMessage="记录已更新。",N(e)}function nv(e,t){e.session=Tg(e.session,t),e.unmatchedRecordIds.delete(t),e.statusMessage="记录已删除。",N(e)}function rv(e,t,n){e.session=_g(e.session,t,n),e.statusMessage=`状态已更新为：${n==="open"?"待处理":n==="resolved"?"已处理":"暂缓"}`,N(e)}function iv(e){const t=Rg(e.session),n=new Blob([t],{type:"application/json;charset=utf-8"}),r=URL.createObjectURL(n),i=document.createElement("a");i.href=r,i.download=`web-visual-ai-editor-${new Date().toISOString().slice(0,10)}.json`,i.click(),URL.revokeObjectURL(r),e.statusMessage="JSON 已导出。",N(e)}function lv(e,t){const n=Pg(t);if(!n.ok){e.statusMessage=n.reason,N(e);return}e.session=n.session,e.selectedElement=null,e.selectedSnapshot=null,e.selectedStyleSnapshot=[],e.selectedStyleSupported=!1,e.styleDraft={},e.currentMeasurements=null,e.currentLayoutContext=null,e.quickCommentTarget=null,Zi(e),e.unmatchedRecordIds=new Set,e.statusMessage=`已导入 ${n.session.records.length} 条记录。`,N(e)}async function ov(e){try{await navigator.clipboard.writeText(Qm(e.session)),e.statusMessage="AI Prompt 已复制。"}catch{e.statusMessage="复制失败，请检查浏览器剪贴板权限。"}N(e)}function en(e,t,n){const r=t instanceof HTMLElement;e.selectedElement=r?t:null,e.selectedSnapshot=Ki(t),e.selectedStyleSnapshot=r?Yh(t):[],e.selectedStyleSupported=r,e.styleDraft={},e.quickCommentTarget=null,e.applyToSimilar=!1,e.panelView="inspector",e.statusMessage=r?n:"该元素暂不支持样式预览。",sv(e),We(e),Er(e),N(e)}function av(e,t){e.selectedElement=null,e.selectedSnapshot=null,e.selectedStyleSnapshot=[],e.selectedStyleSupported=!1,e.styleDraft={},e.quickCommentTarget=null,e.applyToSimilar=!1,e.panelView="inspector",e.statusMessage=t,Zi(e),We(e),Er(e),N(e)}function We(e){if(!e.selectedElement){e.currentMeasurements=null,e.currentLayoutContext=null;return}const t=e.selectedElement.getBoundingClientRect(),n={x:t.x,y:t.y,width:t.width,height:t.height},r={width:window.innerWidth,height:window.innerHeight};let i=null;const l=e.selectedElement.parentElement;if(l){const s=l.getBoundingClientRect(),u={x:s.x,y:s.y,width:s.width,height:s.height},c=mg(n,u);c&&(i={selector:Ca(l),distances:c})}let o=null;if(e.measurementMode==="complete"&&e.pairFirstElement&&e.pairSecondElement){const s=e.selectedElement===e.pairFirstElement?e.pairSecondElement:e.pairFirstElement,u=s.getBoundingClientRect(),c={x:u.x,y:u.y,width:u.width,height:u.height},d=gg(n,c),f=Ki(s);o={selector:f.selector,text:f.text,rect:{x:Math.round(u.x),y:Math.round(u.y),width:Math.round(u.width),height:Math.round(u.height)},horizontalDistance:d.horizontalDistance,verticalDistance:d.verticalDistance,centerDistance:d.centerDistance}}e.currentMeasurements={size:fg(n),viewport:hg(n,r),parent:i,pair:o}}function Er(e){e.currentLayoutContext=e.selectedElement?Eg(e.selectedElement):null}function sv(e){if(!e.selectedElement){Zi(e);return}const t=xg(e.selectedElement,document.body);e.similarMatchLevel=t.matchLevel,e.similarPrimaryFeature=t.primaryFeature,e.similarTotalMatched=t.totalMatched,e.similarTruncated=t.truncated,e.similarElements=t.similar,e.similarSnapshots=t.similar.map(n=>Ki(n))}function Zi(e){e.similarMatchLevel=null,e.similarPrimaryFeature="",e.similarTotalMatched=1,e.similarTruncated=!1,e.similarElements=[],e.similarSnapshots=[],e.applyToSimilar=!1}function jr(e){return!e.applyToSimilar||!e.similarMatchLevel||e.similarSnapshots.length===0?null:{matchLevel:e.similarMatchLevel,primaryFeature:e.similarPrimaryFeature,totalMatched:e.similarTotalMatched,truncated:e.similarTruncated,targets:e.similarSnapshots}}function uv(e,t){var r;if(t===null)return;const n=e.similarElements[t];n&&((r=e.overlay)==null||r.flash(Ze(n)))}function cv(e){var t;!e.selectedElement||e.similarElements.length===0||((t=e.overlay)==null||t.highlightSimilar([Ze(e.selectedElement),...e.similarElements.map(Ze)]),e.statusMessage=`已高亮 ${e.similarTotalMatched} 个相似元素。`,N(e))}function dv(e,t){var n;!t.element||!t.sharedGroup||((n=e.overlay)==null||n.highlightSimilar([t.element.rect,...t.sharedGroup.targets.map(r=>r.rect)]),e.statusMessage=`已高亮记录中的 ${t.sharedGroup.totalMatched} 个批量目标。`,N(e))}function pv(e){Ue(e),e.quickCommentTarget=null,e.interactionMode="measure",e.panelView="inspector",e.pairSecondElement=null,e.selectedElement?(e.measurementMode="awaiting-b",e.pairFirstElement=e.selectedElement,e.statusMessage="已将当前元素设为 A，请选择参照元素 B。"):(e.measurementMode="awaiting-a",e.pairFirstElement=null,e.statusMessage="请点击页面元素选择起点 A。"),N(e)}function Rd(e){Ue(e),e.quickCommentTarget=null,e.interactionMode="select",e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,We(e),e.statusMessage="已退出测距模式。",N(e)}function fv(e){Ue(e),e.quickCommentTarget=null,e.interactionMode="measure",e.measurementMode="awaiting-a",e.pairFirstElement=null,e.pairSecondElement=null,We(e),e.statusMessage="已重置测距，请重新选择 A。",N(e)}function Pd(e){Ue(e),e.quickCommentTarget=null,e.interactionMode="browse",e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,e.hoveredElement=null,We(e),e.statusMessage="浏览模式：网页原有点击和输入已恢复。",N(e)}function zd(e){Ue(e),e.quickCommentTarget=null,e.interactionMode="select",e.panelView="inspector",e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,We(e),e.statusMessage="选择模式：点击网页元素查看并编辑属性。",N(e)}function Id(e){e.quickCommentTarget=null,e.interactionMode="auto-layout",e.panelView="inspector",e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,e.layoutGuide=null,We(e),Er(e),e.statusMessage=e.selectedElement?"自动布局：拖动元素中部粉色横条，和同父容器元素精准交换。":"自动布局：先点击一个元素，再拖动粉色横条交换同级元素位置。",N(e)}function hv(e){Ue(e),e.interactionMode="comment",e.panelView="inspector",e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,e.quickCommentTarget=null,We(e),Er(e),e.statusMessage="评论模式：点击页面元素，直接添加一条评论。",N(e)}function mv(e,t){var i;if(e.interactionMode!=="auto-layout"&&Id(e),!((i=e.selectedElement)!=null&&i.parentElement)){e.statusMessage="自动布局需要先选择一个有父容器的元素。",N(e);return}const n=e.selectedElement.parentElement,r=Lt(n);if(r.length<2){e.statusMessage="当前父容器内没有可交换位置的同级元素。",N(e);return}Ue(e),e.layoutDrag={pointerId:t.pointerId,element:e.selectedElement,parent:n,originalIndex:r.indexOf(e.selectedElement),originalNextSibling:e.selectedElement.nextElementSibling,previewIndex:r.indexOf(e.selectedElement),previewTarget:null,animationStyles:new Map,animationTimers:new Map,flow:_v(n)},e.layoutGuide=yv(e.layoutDrag,t.clientX,t.clientY),e.statusMessage="正在调整布局位置：拖到同级元素上会精准交换，松开后保存记录。",window.addEventListener("pointermove",$d,!0),window.addEventListener("pointerup",Ri,!0),window.addEventListener("pointercancel",Ri,!0),N(e)}function $d(e){const t=Pt();if(!t.layoutDrag||e.pointerId!==t.layoutDrag.pointerId)return;const n=ja(t.layoutDrag,e.clientX,e.clientY);n?(xv(t.layoutDrag,n),t.layoutGuide=Dd(n)):t.layoutGuide=null,ba(t),e.preventDefault(),e.stopPropagation()}function Ri(e){const t=Pt();if(!t.layoutDrag||e.pointerId!==t.layoutDrag.pointerId)return;const n=t.layoutDrag,r=ja(n,e.clientX,e.clientY);if(e.type==="pointercancel"){wv(n),Mv(n),Ue(t),t.statusMessage="已取消本次布局拖动。",N(t);return}Ue(t),r||(t.layoutGuide=null),gv(t,n),e.preventDefault(),e.stopPropagation()}function Ue(e){!e.layoutDrag&&!e.layoutGuide||(e.layoutDrag=null,e.layoutGuide=null,window.removeEventListener("pointermove",$d,!0),window.removeEventListener("pointerup",Ri,!0),window.removeEventListener("pointercancel",Ri,!0))}function gv(e,t){if(!t.element.isConnected||!t.parent.isConnected){e.statusMessage="目标元素已从页面移除，布局调整已取消。",N(e);return}const r=Lt(t.parent).indexOf(t.element);if(en(e,t.element,r===t.originalIndex?"自动布局：位置未变化。":`自动布局：已移动到第 ${r+1} 位，并保存布局记录。`),r===t.originalIndex)return;e.layoutMoves.some(o=>o.element===t.element)||e.layoutMoves.push({element:t.element,parent:t.parent,originalNextSibling:t.originalNextSibling});const i={direction:t.flow,alignment:"none",gap:"",note:`拖动换位：从第 ${t.originalIndex+1} 位移动到第 ${r+1} 位。`},l={category:"layout",priority:"medium",status:"open",interactionState:null,scope:"element"};e.session=Cr(e.session,Ki(t.element),`布局调整：${i.note}`,[],l,null,jr(e),{layoutContext:e.currentLayoutContext,layoutIntent:i}),e.applyToSimilar=!1,N(e)}function vv(e){var t;for(const n of[...e.layoutMoves].reverse())!n.element.isConnected||!n.parent.isConnected||n.parent.insertBefore(n.element,(t=n.originalNextSibling)!=null&&t.isConnected?n.originalNextSibling:null);e.layoutMoves=[]}function yv(e,t,n){const r=ja(e,t,n);return r?Dd(r):null}function Dd(e){return{targetRect:e.targetRect,lineRect:e.lineRect,alignmentLines:e.alignmentLines,label:e.label}}function ja(e,t,n){const r=Sv(e,t,n);if(!r)return null;const l=Lt(e.parent).indexOf(r),o=Ze(r),s=Nv(e.flow,o),u=Lv(e.flow,Ze(e.element),o,s);return{insertIndex:l,swapTarget:r,targetRect:o,lineRect:s,alignmentLines:u,label:`交换第 ${l+1} 位`}}function xv(e,t){t.swapTarget===e.previewTarget||!e.element.isConnected||!e.parent.isConnected||!t.swapTarget.isConnected||(Od(e,()=>{Ev(e.element,t.swapTarget)}),e.previewTarget=t.swapTarget,e.previewIndex=Lt(e.parent).indexOf(e.element))}function wv(e){!e.element.isConnected||!e.parent.isConnected||(Od(e,()=>{var t;e.parent.insertBefore(e.element,(t=e.originalNextSibling)!=null&&t.isConnected?e.originalNextSibling:null)}),e.previewIndex=e.originalIndex,e.previewTarget=null)}function Sv(e,t,n){const r=new Set(Lt(e.parent));for(const i of document.elementsFromPoint(t,n)){if(!(i instanceof HTMLElement)||i===e.element||i.id.startsWith("web-visual-ai-editor-"))continue;const l=kv(i,e.parent);if(l&&l!==e.element&&r.has(l))return l}return Cv(e,t,n)}function kv(e,t){let n=e;for(;n&&n.parentElement!==t;){if(n===t||n.id.startsWith("web-visual-ai-editor-"))return null;n=n.parentElement}return(n==null?void 0:n.parentElement)===t?n:null}function Cv(e,t,n){const r=Lt(e.parent).filter(s=>s!==e.element);let i=null;for(const s of r){const u=s.getBoundingClientRect(),c=u.x+u.width/2,d=u.y+u.height/2,f=Math.hypot(c-t,d-n);(!i||f<i.distance)&&(i={element:s,distance:f,rect:u})}if(!i)return null;const l=Math.max(24,Math.min(96,Math.max(i.rect.width,i.rect.height)*.36));return t>=i.rect.x-l&&t<=i.rect.x+i.rect.width+l&&n>=i.rect.y-l&&n<=i.rect.y+i.rect.height+l?i.element:null}function Ev(e,t){const n=e.parentElement;if(!n||t.parentElement!==n||e===t)return;const r=e.nextSibling,i=t.nextSibling;if(r===t){n.insertBefore(t,e);return}if(i===e){n.insertBefore(e,t);return}n.insertBefore(e,i),n.insertBefore(t,r)}function Od(e,t){const n=Lt(e.parent),r=new Map;for(const i of n)r.set(i,i.getBoundingClientRect());t();for(const i of Lt(e.parent)){const l=r.get(i);if(!l)continue;const o=i.getBoundingClientRect(),s=l.x-o.x,u=l.y-o.y;Math.abs(s)<1&&Math.abs(u)<1||jv(e,i,s,u)}}function jv(e,t,n,r){const i=bv(e,t),l=e.animationTimers.get(t);l!==void 0&&window.clearTimeout(l),t.style.transition="none",t.style.transform=`translate(${Math.round(n)}px, ${Math.round(r)}px) ${i.transform}`.trim(),t.style.willChange="transform",window.requestAnimationFrame(()=>{t.style.transition="transform 140ms cubic-bezier(0.2, 0.8, 0.2, 1)",t.style.transform=i.transform}),e.animationTimers.set(t,window.setTimeout(()=>{Fd(e,t)},180))}function bv(e,t){const n=e.animationStyles.get(t);if(n)return n;const r={transform:t.style.transform,transition:t.style.transition,willChange:t.style.willChange};return e.animationStyles.set(t,r),r}function Fd(e,t){const n=e.animationStyles.get(t);n&&(t.style.transform=n.transform,t.style.transition=n.transition,t.style.willChange=n.willChange,e.animationStyles.delete(t),e.animationTimers.delete(t))}function Mv(e){for(const t of e.animationTimers.values())window.clearTimeout(t);for(const t of e.animationStyles.keys())Fd(e,t)}function Nv(e,t){return e==="horizontal"?{x:Math.round(t.x+t.width/2-1),y:Math.round(t.y),width:2,height:Math.max(12,Math.round(t.height))}:{x:Math.round(t.x),y:Math.round(t.y+t.height/2-1),width:Math.max(12,Math.round(t.width)),height:2}}function Lv(e,t,n,r){const i=[],l=n??t;if(e==="horizontal"){const o=r.x+r.width/2;i.push(Ll(o)),i.push(Tl(l.y+l.height/2)),i.push(Tl(t.y+t.height/2))}else{const o=r.y+r.height/2;i.push(Tl(o)),i.push(Ll(l.x+l.width/2)),i.push(Ll(t.x+t.width/2))}return Tv(i)}function Ll(e){return{x:Math.round(Ad(e,0,window.innerWidth)),y:0,width:1,height:window.innerHeight}}function Tl(e){return{x:0,y:Math.round(Ad(e,0,window.innerHeight)),width:window.innerWidth,height:1}}function Tv(e){const t=[];for(const n of e)t.some(i=>i.width===n.width&&i.height===n.height&&Math.abs(i.x-n.x)<=1&&Math.abs(i.y-n.y)<=1)||t.push(n);return t}function Ad(e,t,n){return Math.min(Math.max(e,t),Math.max(t,n))}function _v(e){const t=window.getComputedStyle(e);return t.display==="flex"||t.display==="inline-flex"?t.flexDirection.startsWith("column")?"vertical":"horizontal":t.display==="grid"||t.display==="inline-grid"?t.gridAutoFlow.includes("column")?"vertical":"horizontal":"vertical"}function Lt(e){return Array.from(e.children).filter(t=>t instanceof HTMLElement&&!t.id.startsWith("web-visual-ai-editor-"))}function Rv(e){Ue(e),e.quickCommentTarget=null,e.panelView="records",e.interactionMode="browse",e.measurementMode="off",e.pairFirstElement=null,e.pairSecondElement=null,e.hoveredElement=null,We(e),e.statusMessage="查看当前页面的修改记录。",N(e)}function Pv(e,t,n){if(!e.selectedElement){e.statusMessage="请先选择页面元素。",N(e);return}const r=Vd(e.selectedStyleSnapshot,t),i=n.trim();if(e.styleDraft={...e.styleDraft,[t]:i},!i||i===r){if(delete e.styleDraft[t],e.selectedElement){const o=e.stylePreviewManager.apply(e.selectedElement,t,r??"");o.ok||(e.statusMessage=o.reason)}N(e);return}const l=e.stylePreviewManager.apply(e.selectedElement,t,i);l.ok?e.statusMessage="已应用临时预览，未保存到记录。":e.statusMessage=l.reason,N(e)}function zv(e){e.selectedElement&&(e.stylePreviewManager.reset(e.selectedElement),e.styleDraft={},e.statusMessage="已重置当前元素样式预览。",N(e))}function Iv(e){const t=[];for(const n of vd){const r=e.styleDraft[n.property];if(typeof r!="string"||!r)continue;const i=Vd(e.selectedStyleSnapshot,n.property);i!==r&&t.push({property:n.property,label:n.label,oldValue:i??"",newValue:r,unit:n.unit?Gh(r,n.unit):void 0})}return t}function Vd(e,t){var n;return((n=e.find(r=>r.property===t))==null?void 0:n.value)??null}function ba(e){e.rafId===null&&(e.rafId=window.requestAnimationFrame(()=>{e.rafId=null,N(e)}))}function N(e){var t,n;(t=e.overlay)==null||t.update({enabled:e.enabled,hoverRect:e.hoveredElement?Ze(e.hoveredElement):null,selectedRect:e.selectedElement?Ze(e.selectedElement):null,selectedElement:e.selectedElement,measurement:Dv(e),layoutMode:e.interactionMode==="auto-layout",layoutGuide:e.layoutGuide,commentPins:Ov(e)}),(n=e.panel)==null||n.update({enabled:e.enabled,panelView:e.panelView,interactionMode:e.interactionMode,selectedElement:e.selectedSnapshot,selectedStyleSnapshot:e.selectedStyleSnapshot,selectedStyleSupported:e.selectedStyleSupported,styleDraft:e.styleDraft,records:e.session.records,statusMessage:e.statusMessage,unmatchedRecordIds:e.unmatchedRecordIds,editingRecord:e.editingRecord,filterCategory:e.filterCategory,filterStatus:e.filterStatus,filterRange:e.filterRange,measurement:e.currentMeasurements,layoutContext:e.currentLayoutContext,measurementMode:e.measurementMode,attachMeasurements:e.attachMeasurements,similarMatchLevel:e.similarMatchLevel,similarPrimaryFeature:e.similarPrimaryFeature,similarTotalMatched:e.similarTotalMatched,similarTruncated:e.similarTruncated,similarElements:e.similarSnapshots,applyToSimilar:e.applyToSimilar,quickCommentTarget:e.quickCommentTarget})}function $v(e){const t={none:"",horizontal:"改为横向排列",vertical:"改为纵向排列"},n={none:"",start:"起点对齐",center:"居中对齐",end:"终点对齐","space-between":"两端等距"},r=[t[e.direction],n[e.alignment],e.gap?`目标间距 ${e.gap}`:"",e.note].filter(Boolean);return r.length>0?`布局意图：${r.join("；")}`:"布局意图：请优化父容器布局。"}function Dv(e){if(!e.currentMeasurements)return null;let t=null;if(e.measurementMode==="complete"&&e.pairFirstElement&&e.pairSecondElement&&e.currentMeasurements.pair){const n=e.pairFirstElement.getBoundingClientRect(),r=e.pairSecondElement.getBoundingClientRect();t={a:{x:n.x,y:n.y,width:n.width,height:n.height},b:{x:r.x,y:r.y,width:r.width,height:r.height},horizontalDistance:e.currentMeasurements.pair.horizontalDistance,verticalDistance:e.currentMeasurements.pair.verticalDistance}}return{size:e.currentMeasurements.size,pair:t}}function Ov(e){return dg(e.session.records)}function Ze(e){const t=e.getBoundingClientRect();return{x:Math.round(t.x),y:Math.round(t.y),width:Math.round(t.width),height:Math.round(t.height)}}function Hd(e){const[t]=e.composedPath();return t instanceof Element?t:null}function Bd(e){return e.composedPath().some(t=>t instanceof HTMLElement&&t.id.startsWith("web-visual-ai-editor-"))}
//# sourceMappingURL=index.js.map
