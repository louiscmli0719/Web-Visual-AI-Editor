const i="content/index.js";chrome.action.onClicked.addListener(async e=>{if(e.id)try{await chrome.scripting.executeScript({target:{tabId:e.id},files:[i]}),await chrome.tabs.sendMessage(e.id,{type:"WVAIE_TOGGLE_EDITOR"})}catch(t){console.warn("[Web Visual AI Editor] Failed to toggle editor",t)}});
//# sourceMappingURL=service-worker.js.map
